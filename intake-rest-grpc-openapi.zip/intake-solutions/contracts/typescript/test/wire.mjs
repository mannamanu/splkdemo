import assert from 'node:assert/strict';
import fs from 'node:fs';
const fixture = JSON.parse(fs.readFileSync(new URL('../../fixtures/app-context.json', import.meta.url), 'utf8'));
assert.equal(fixture.intakeRequest.transactionId, 'TX-1001');
assert.equal(fixture.tradingRequest.transactionId, fixture.intakeRequest.transactionId);
assert.equal(fixture.tradingResponse.authenticated, true);
assert.deepEqual(JSON.parse(JSON.stringify(fixture)), fixture);
console.log('Shared JSON wire fixture round-trip passed');
