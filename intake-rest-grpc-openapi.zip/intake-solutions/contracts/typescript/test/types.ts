import type { IntakeRequest, AppContextDto, TradingResponseDto, IntakeActivities } from '../src/index.js';
const request: IntakeRequest = { requestXML: '<IntakeRequest/>', transactionId: 'TX-1', ipaddress: '192.0.2.1', xForwardedFor: '' };
const response: TradingResponseDto = { accountId: 'A-1', authenticated: true, authorized: false };
const context: AppContextDto = { intakeRequest: request, requestId: 'R-1', accountId: 'A-1', xml: '<CanonicalRequest/>', json: null, tradingRequest: null, tradingResponse: response };
// @ts-expect-error transactionId is required
const incomplete: IntakeRequest = { requestXML: '', ipaddress: '', xForwardedFor: '' };
// @ts-expect-error wire models are immutable
request.transactionId = 'changed';
async function call(activities: IntakeActivities): Promise<AppContextDto> {
  return activities.callTradingService(await activities.processInboundXMLRequest(request));
}
void context; void incomplete; void call;
