import type { components } from './generated/schema.js';
export type IntakeRequest = components['schemas']['IntakeRequest'];
export type AppContextDto = components['schemas']['AppContextDto'];
export type TradingRequestDto = components['schemas']['TradingRequestDto'];
export type TradingResponseDto = components['schemas']['TradingResponseDto'];
export type OutboundRequest = components['schemas']['OutboundRequest'];
export type IntakeError = components['schemas']['IntakeError'];

/** Type-only signature for proxyActivities; not a registered Temporal implementation. */
export interface IntakeActivities {
  processInboundXMLRequest(request: IntakeRequest): Promise<AppContextDto>;
  callTradingService(context: AppContextDto): Promise<AppContextDto>;
  authAuthz(context: AppContextDto): Promise<AppContextDto>;
  mapXmlToJson(context: AppContextDto): Promise<AppContextDto>;
  processOutbound(request: OutboundRequest): Promise<string>;
}
