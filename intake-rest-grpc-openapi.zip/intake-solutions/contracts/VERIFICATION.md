# Contract checks

2026-10-16: npm test passed with pinned package-lock dependencies on Node24.19.0:
OpenAPI3.0 structure/external-reference validation (three specs), openapi-typescript7.10.1
readonly generation, TypeScript5.9.3 compilation and negative required/readonly checks,
both self-contained bundles and the JSON fixture round-trip.
Java shared-fixture tests passed in both Intake apps through Temporal's DataConverter.
Redocly2.64.1 telemetry/update checks are disabled by the scripts and config.
No publishing or deployed Node Temporal integration was performed.
