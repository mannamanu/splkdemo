# Shared Intake schemas and generated objects

One schema source serves both Intake applications and the TypeScript/Node Workflow service.
Version2.1.0 retains the version2 JSON wire shape and v2 task queues. No HTTP request or
Activity input field was renamed by this refactor.

| Path | Responsibility |
|---|---|
| schemas/*.yaml | Canonical OpenAPI3.0 DTO and XML envelope schema definitions |
| openapi.yaml | DTO-only generation input; no HTTP endpoints |
| templates/java-record/model.mustache | Small OpenAPI Generator Java-record template |
| typescript/src/generated/schema.ts | Generated readonly TypeScript definitions |
| typescript/src/index.ts | Friendly type exports and Activity method signature interface |
| fixtures/app-context.json | Shared JSON serialization fixture verified in Java and Node |
| ../intake-rest/openapi/openapi.yaml | Actual REST API paths referencing shared schemas |
| ../intake-grpc/openapi/openapi.yaml | HTTP health + gRPC documentation extension |

## Reference shared schema files

Both application specs use file references rather than duplicate definitions:

```yaml
components:
  schemas:
    IntakeRequest:
      $ref: ../../contracts/schemas/IntakeRequest.yaml
    AppContextDto:
      $ref: ../../contracts/schemas/AppContextDto.yaml
```

Inside AppContextDto.yaml, sibling model references are relative to that file:

```yaml
properties:
  intakeRequest:
    $ref: ./IntakeRequest.yaml
```

Keep XML-envelope and Temporal JSON casing distinct. IntakeErrorXml has Activity/Code/
Message/Retryable XML elements; IntakeError has activity/code/message/retryable JSON
properties. OutboundRequestXml similarly differs from the Temporal OutboundRequest DTO.
The XML XSDs in xml-assets still perform actual document validation; OpenAPI schemas do
not replace XSD/XSLT. Generated types do not perform runtime validation automatically.

## Generate Java records used by Intake

Requires JDK25/Maven3.9.11+. From the bundle root:

```bash
mvn -f intake-rest/pom.xml generate-sources
mvn -f intake-grpc/pom.xml generate-sources
```

Generation also runs automatically during compile/package/verify and Docker builds.
OpenAPI Generator7.17.0 resolves external references and generates six records under:

```
intake-rest/target/generated-sources/openapi/src/main/java/com/example/intake/contract/
```

The gRPC application has the corresponding target directory. The apps compile these
records directly; duplicate handwritten DTO classes have been removed from src/main/java.
Handwritten Activity interfaces/options and business logic remain unchanged. Maven adds
the generated source directory; IDE users should reload Maven after generate-sources.

```java
var request = new IntakeRequest(xml, "TX-1001", "192.0.2.10", "192.0.2.10");
AppContextDto context = activities.processInboundXMLRequest(request);
context = activities.callTradingService(context);
TradingResponseDto response = context.tradingResponse();
```

The custom record template preserves constructor/component ordering, JsonProperty wire
names and immutable AppContextDto helper methods. It is deliberately for the current
simple object/ref/string/boolean DTOs. New arrays, money/date fields, unions or enums
require reviewing/extending the template and both languages' tests; do not assume every
OpenAPI Generator feature is supported by this small custom template. Required booleans
remain primitive; nullability and JSON wire shapes are covered by the shared fixture.

Do not edit target/generated-sources. Edit schemas and, if needed, the template, then
regenerate. App Maven version2.1.0 packages the records into app-contracts.jar. Publish
one selected application's classifier artifact to your internal Maven registry for
Java consumers; do not put both duplicate contract artifacts on one classpath.

## Generate TypeScript types for Node workflows

Requires Node22.18+ and npm. Node24 was used for verification. From the bundle root:

```bash
cd contracts/typescript
npm ci
npm run generate
npm run build
npm test
```

package-lock.json pins the tool dependencies. openapi-typescript resolves the same shared
files and generates readonly interfaces/types. src/index.ts exports convenient names.
No backend or Temporal code is generated. Use object literals with generated types:

```typescript
import type { IntakeRequest, AppContextDto } from '@example/intake-contracts';

const request: IntakeRequest = {
  requestXML: '<IntakeRequest>...</IntakeRequest>',
  transactionId: 'TX-1001',
  ipaddress: '192.0.2.10',
  xForwardedFor: '192.0.2.10',
};
```

These are TypeScript types, not runtime constructors or validators. Keep validation in
Activities/API boundaries. Record schemas are JSON-compatible; no Java class names or
methods are required in TypeScript. Treat IP/forwarded metadata as untrusted.

To consume locally in a monorepo, build this package first, then add a dependency in your
Workflow service package.json using the correct relative path:

```json
{"dependencies":{"@example/intake-contracts":"file:../contracts/typescript"}}
```

Adjust the path for your layout. For independent repositories use your internal npm
registry (change the sample package scope, set private=false and configure your own
registry authentication before publishing). This sample remains private and is not
published. npm pack can produce a local tarball after npm run build; package files are
dist only. Imports should use import type so Workflow bundling does not pull generator,
HTTP clients or development tools into deterministic Workflow execution.

For plain Node.js with JSDoc tooling:

```javascript
/** @type {import('@example/intake-contracts').IntakeRequest} */
const request = { requestXML: '<IntakeRequest/>', transactionId: 'TX-1', ipaddress: '', xForwardedFor: '' };
```

## Temporal TypeScript integration

Use the generated DTO exports with the existing Node Workflow's proxyActivities:

```typescript
import { proxyActivities } from '@temporalio/workflow';
import type { IntakeActivities, IntakeRequest, AppContextDto } from '@example/intake-contracts';

const intake = proxyActivities<IntakeActivities>({
  taskQueue: 'intake-rest-v2-activities',
  startToCloseTimeout: '10s',
  scheduleToCloseTimeout: '30s',
  retry: { maximumAttempts: 2, nonRetryableErrorTypes: ['INTAKE_REJECTED'] },
});
const trading = proxyActivities<Pick<IntakeActivities, 'callTradingService'>>({
  taskQueue: 'intake-rest-v2-activities',
  startToCloseTimeout: '15s',
  scheduleToCloseTimeout: '60s',
  retry: { maximumAttempts: 3, nonRetryableErrorTypes: ['INTAKE_REJECTED'] },
});

// Helper inside your existing Quote Workflow, not a separate generated Workflow.
async function runIntakePrephase(request: IntakeRequest): Promise<AppContextDto> {
  let context = await intake.processInboundXMLRequest(request);
  context = await trading.callTradingService(context);
  context = await intake.authAuthz(context);
  return intake.mapXmlToJson(context);
}
```

For the gRPC app use intake-grpc-v2-activities instead. Quote then invokes its existing
other-service Activity using context.json, and calls intake.processOutbound with the
approved quote fields. No Quote application is generated here.

Both SDKs must use compatible JSON payload conversion (default json/plain for these
objects). If using encryption/custom codecs, configure both ends consistently. Do not
send class instances/prototypes, Java-specific serialization or bigint/Date objects as
these DTO fields. Fixture tests verify Java Temporal conversion and Node JSON structure;
a deployed TypeScript Temporal Workflow integration is not executed in this sample.

## Validate, bundle and automate

```bash
npm run validate
npm run bundle
```

Run these in contracts/typescript. Validation checks all three OpenAPI documents and
external refs. Bundles in dist/intake-rest.openapi.yaml and dist/intake-grpc.openapi.yaml
are self-contained for tools that cannot load multi-file specs. The gRPC document still
does not invent HTTP business endpoints: protobuf remains authoritative for native RPCs.

CLI scripts disable Redocly telemetry/update checks using its documented settings.
No telemetry opt-in is required to generate types. No network access is needed for local
schema resolution after dependencies are installed. Tool dependency installation still
requires your approved registry/network configuration.

Suggested CI order: npm ci; npm test; then mvn verify for each app. Check generated type
changes in code review, publish matching package versions and rebuild both consumers.
Keep backward-compatible optional fields where possible; required-field/type/meaning
changes require a new contract version and an explicit Workflow history migration.

## Running applications and Docker

Keep contracts alongside both app folders. From the root, Docker builds use:

```bash
docker build -f intake-rest/Dockerfile -t intake-rest:local .
docker build -f intake-grpc/Dockerfile -t intake-grpc:local .
```

Or run docker compose up --build -d from the selected app folder; Compose uses the
bundle root as its build context. Root .dockerignore excludes node_modules/target/reports.
Copying only one app folder without contracts will not build. Runtime JARs include the
app spec and shared schemas at /contracts/schemas/*.yaml, so Swagger external refs resolve
without a filesystem mount of contracts. XML XSD/XSL runtime mounts remain separate.

Executed single-file spec snapshots are also included in contracts/bundled for direct
import. Regenerate with npm run bundle after schema changes; dist is the command output.
