Read AGENTS.md, README.md and docs/QUOTE-INTEGRATION.md before implementation.
