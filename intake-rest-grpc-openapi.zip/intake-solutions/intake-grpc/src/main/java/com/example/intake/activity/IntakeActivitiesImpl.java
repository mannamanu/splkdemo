package com.example.intake.activity;
import com.example.intake.contract.*;
import com.example.intake.error.ActivityErrors;
import com.example.intake.xml.*;
import com.example.intake.trading.TradingClient;
import io.grpc.*;
import java.util.*;
import org.springframework.stereotype.Component;

@Component
public class IntakeActivitiesImpl implements IntakeActivities {
 private final XmlEngine xml;private final TradingClient trading;private final JsonMapping mapping;private final com.example.intake.trading.TradingRequestMapper tradingMapper;
 public IntakeActivitiesImpl(XmlEngine xml,TradingClient trading,JsonMapping mapping,com.example.intake.trading.TradingRequestMapper tradingMapper){this.xml=xml;this.trading=trading;this.mapping=mapping;this.tradingMapper=tradingMapper;}
 @Override public AppContextDto processInboundXMLRequest(IntakeRequest request){
  String step="processInboundXMLRequest";
  try{
   if(request==null||request.requestXML()==null||request.transactionId()==null||!request.transactionId().matches("[A-Za-z0-9_-]{1,64}")
     ||!validMetadata(request.ipaddress(),64)||!validMetadata(request.xForwardedFor(),1024))
    throw ActivityErrors.reject(step,"BAD_REQUEST","Invalid Intake request metadata");
   String input=request.requestXML();
   xml.validate("request",input);String transformed=xml.transform("inbound",input);var doc=xml.parse(transformed);
   return bounded(new AppContextDto(request,xml.text(doc,"RequestId"),xml.text(doc,"AccountId"),transformed,null,null,null),step);
  }catch(io.temporal.failure.ApplicationFailure error){throw error;}
  catch(XmlProblem error){
   String code=switch(error.kind()){case TOO_LARGE->"REQUEST_TOO_LARGE";case SCHEMA->"XSD_INVALID";case TRANSFORM->"INBOUND_TRANSFORM_FAILED";default->"XML_INVALID";};
   throw ActivityErrors.reject(step,code,"Invalid inbound XML request");
  }catch(Exception error){throw ActivityErrors.reject(step,"INBOUND_FAILED","Inbound processing failed");}
 }
 @Override public AppContextDto callTradingService(AppContextDto input){
  String step="callTradingService";
  try{
   var tradingRequest=tradingMapper.map(input);
   var result=trading.lookup(tradingRequest);
   if(result==null||!input.accountId().equals(result.accountId()))throw ActivityErrors.reject(step,"TRADING_INVALID","Trading account mismatch");
   return bounded(input.withTrading(tradingRequest,result),step);
  }catch(io.temporal.failure.ApplicationFailure error){throw error;}
  catch(StatusRuntimeException error){
   switch(error.getStatus().getCode()){
    case UNAVAILABLE->throw ActivityErrors.retry(step,"TRADING_UNAVAILABLE","Trading service unavailable");
    case DEADLINE_EXCEEDED->throw ActivityErrors.retry(step,"TRADING_TIMEOUT","Trading service timed out");
    default->throw ActivityErrors.reject(step,"TRADING_FAILED","Trading service rejected the request");
   }
  }catch(Exception error){throw ActivityErrors.reject(step,"TRADING_INVALID","Trading response invalid");}
 }
 @Override public AppContextDto authAuthz(AppContextDto input){
  String step="authAuthz";
  try{
   // Trusted Trading flags replace all auth inputs; client XML cannot assert them.
   var fields=new LinkedHashMap<String,String>();fields.put("Authenticated",Boolean.toString(input.authenticated()));fields.put("Authorized",Boolean.toString(input.authorized()));
   String decision=xml.transform("auth",xml.document("AuthContext",fields));var doc=xml.parse(decision);
   if(!"true".equals(xml.text(doc,"Authenticated")))throw ActivityErrors.reject(step,"AUTHENTICATION_FAILED","Authentication failed");
   if(!"true".equals(xml.text(doc,"Authorized")))throw ActivityErrors.reject(step,"AUTHORIZATION_DENIED","Authorization denied");
   return input;
  }catch(io.temporal.failure.ApplicationFailure error){throw error;}
  catch(Exception error){throw ActivityErrors.reject(step,"AUTH_TRANSFORM_FAILED","Authentication transformation failed");}
 }
 @Override public AppContextDto mapXmlToJson(AppContextDto input){
  String step="mapXmlToJson";
  try{
   if(!input.authenticated()||!input.authorized())throw ActivityErrors.reject(step,"AUTHORIZATION_DENIED","Authorization required");
   return bounded(input.withJson(mapping.map(input.xml())),step);
  }catch(io.temporal.failure.ApplicationFailure error){throw error;}
  catch(Exception error){throw ActivityErrors.reject(step,"JSON_MAPPING_FAILED","Unable to map XML to JSON");}
 }
 @Override public String processOutbound(OutboundRequest input){
  String step="processOutbound";
  try{
   if(input==null||!validId(input.requestId())||!validId(input.quoteId())||!"QUOTED".equals(input.status()))throw new IllegalArgumentException();
   var fields=new LinkedHashMap<String,String>();fields.put("RequestId",input.requestId());fields.put("QuoteId",input.quoteId());fields.put("Status",input.status());
   String output=xml.document("IntakeResponse",fields);xml.validate("response",output);return output;
  }catch(Exception error){throw ActivityErrors.reject(step,"OUTBOUND_INVALID","Invalid outbound quote information");}
 }
 private static AppContextDto bounded(AppContextDto context,String step){
  var payload=io.temporal.common.converter.DefaultDataConverter.STANDARD_INSTANCE.toPayload(context).orElseThrow();
  if(payload.getSerializedSize()>1048576)throw ActivityErrors.reject(step,"CONTEXT_TOO_LARGE","Serialized application context exceeds the safe payload budget");
  return context;
 }
 private static boolean validMetadata(String value,int max){return value!=null&&value.length()<=max&&value.chars().noneMatch(c->c<32||c==127);}
 private static boolean validId(String value){return value!=null&&value.matches("[A-Za-z0-9_-]{1,64}");}
}
