package com.example.intake.transport;
import com.example.intake.proto.intake.*;
import com.example.intake.error.ActivityErrors;
import com.example.intake.xml.XmlEngine;
import com.google.protobuf.ByteString;
import io.grpc.*;
import io.grpc.stub.StreamObserver;
import org.springframework.stereotype.Component;
import java.nio.*;
import java.nio.charset.*;
@Component
public class IntakeGrpcEndpoint extends IntakeGrpc.IntakeImplBase {
 public static final Context.Key<String> API_KEY=Context.key("intake-api-key");
 private final TransportFacade facade;
 public IntakeGrpcEndpoint(TransportFacade facade){this.facade=facade;}
 @Override public void processInbound(IntakeRequest request,StreamObserver<XmlResponse> observer){
  var dto=new com.example.intake.contract.IntakeRequest(request.getRequestXml(),request.getTransactionId(),request.getIpaddress(),request.getXForwardedFor());
  send(facade.inbound(dto,API_KEY.get()),observer);
 }
 @Override public void processOutbound(XmlRequest request,StreamObserver<XmlResponse> observer){execute(request,observer,true);}
 private void execute(XmlRequest request,StreamObserver<XmlResponse> observer,boolean outbound){
  TransportFacade.Result result;
  try{
   if(request.getXml().size()>XmlEngine.MAX)throw ActivityErrors.reject("transport","REQUEST_TOO_LARGE","XML request too large");
   String input=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(request.getXml().asReadOnlyByteBuffer()).toString();
   result=facade.outbound(input,API_KEY.get());
  }catch(CharacterCodingException error){result=facade.failure(ActivityErrors.reject("transport","XML_INVALID","UTF-8 XML required"));}
  catch(Exception error){result=facade.failure(error);}
  send(result,observer);
 }
 private void send(TransportFacade.Result result,StreamObserver<XmlResponse> observer){
  observer.onNext(XmlResponse.newBuilder().setXml(ByteString.copyFromUtf8(result.xml())).setHttpEquivalentStatus(result.status()).build());observer.onCompleted();
 }
 public static ServerInterceptor credentials(){
  return new ServerInterceptor(){
   @Override public <Q,R> ServerCall.Listener<Q> interceptCall(ServerCall<Q,R> call,Metadata headers,ServerCallHandler<Q,R> next){
    return Contexts.interceptCall(Context.current().withValue(API_KEY,headers.get(Metadata.Key.of("x-api-key",Metadata.ASCII_STRING_MARSHALLER))),call,headers,next);
   }
  };
 }
}
