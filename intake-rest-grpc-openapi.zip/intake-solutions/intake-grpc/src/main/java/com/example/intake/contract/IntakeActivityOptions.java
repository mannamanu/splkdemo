package com.example.intake.contract;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import java.time.Duration;
/** Called by the existing Quote Workflow when constructing Activity stubs. */
public final class IntakeActivityOptions {
 private IntakeActivityOptions() {}
 public static ActivityOptions forActivity(String queue,String activity) {
  boolean trading="callTradingService".equals(activity);
  return ActivityOptions.newBuilder().setTaskQueue(queue)
    .setStartToCloseTimeout(Duration.ofSeconds(trading?15:10))
    .setScheduleToCloseTimeout(Duration.ofSeconds(trading?60:30))
    .setRetryOptions(RetryOptions.newBuilder().setInitialInterval(Duration.ofSeconds(1))
      .setBackoffCoefficient(2).setMaximumInterval(Duration.ofSeconds(5)).setMaximumAttempts(trading?3:2)
      .setDoNotRetry("INTAKE_REJECTED").build()).build();
 }
}
