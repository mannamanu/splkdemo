package com.example.intake.xml;
public class XmlProblem extends RuntimeException {
 public enum Kind { MALFORMED, SCHEMA, TRANSFORM, MAPPING, TOO_LARGE }
 private final Kind kind;
 public XmlProblem(Kind kind){super(kind.name());this.kind=kind;}
 public Kind kind(){return kind;}
}
