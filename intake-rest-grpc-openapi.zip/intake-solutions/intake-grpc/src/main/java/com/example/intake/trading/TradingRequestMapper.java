package com.example.intake.trading;
import com.example.intake.contract.*;
import org.springframework.stereotype.Component;
@Component
public class TradingRequestMapper {
 public TradingRequestDto map(AppContextDto context){
  var inbound=context.intakeRequest();
  return new TradingRequestDto(context.requestId(),context.accountId(),inbound.transactionId(),inbound.ipaddress(),inbound.xForwardedFor());
 }
}
