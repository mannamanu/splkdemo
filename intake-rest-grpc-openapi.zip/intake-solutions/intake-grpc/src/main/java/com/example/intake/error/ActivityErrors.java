package com.example.intake.error;
import com.example.intake.contract.IntakeError;
import io.temporal.failure.ApplicationFailure;
/** Ordinary helper called from each Activity catch block; not a separate Activity. */
public final class ActivityErrors {
 private ActivityErrors(){}
 public static ApplicationFailure reject(String activity,String code,String message){
  return ApplicationFailure.newNonRetryableFailure(message,"INTAKE_REJECTED",new IntakeError(activity,code,message,false));
 }
 public static ApplicationFailure retry(String activity,String code,String message){
  return ApplicationFailure.newFailure(message,"INTAKE_TRANSIENT",new IntakeError(activity,code,message,true));
 }
}
