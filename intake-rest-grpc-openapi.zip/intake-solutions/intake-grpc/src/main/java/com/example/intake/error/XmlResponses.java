package com.example.intake.error;
import com.example.intake.contract.IntakeError;
import com.example.intake.xml.XmlEngine;
import io.temporal.failure.ApplicationFailure;
import java.util.*;
import org.springframework.stereotype.Component;
@Component
public class XmlResponses {
 private final XmlEngine xml;
 public XmlResponses(XmlEngine xml){this.xml=xml;}
 public IntakeError detail(Throwable failure){
  for(Throwable cause=failure;cause!=null;cause=cause.getCause()){
   if(cause instanceof ApplicationFailure app && ("INTAKE_REJECTED".equals(app.getType())||"INTAKE_TRANSIENT".equals(app.getType()))){
    try{if(app.getDetails().getSize()>0)return app.getDetails().get(0,IntakeError.class);}catch(RuntimeException ignored){break;}
   }
  }
  return new IntakeError("transport","INTERNAL_ERROR","Unable to process request",false);
 }
 public String error(Throwable failure){return error(detail(failure));}
 public String error(IntakeError error){
  var fields=new LinkedHashMap<String,String>();fields.put("Activity",error.activity());fields.put("Code",error.code());fields.put("Message",error.message());fields.put("Retryable",Boolean.toString(error.retryable()));
  String output=xml.document("IntakeError",fields);xml.validate("error",output);return output;
 }
 public int status(IntakeError error){
  return switch(error.code()){
   case "AUTHENTICATION_FAILED","TRANSPORT_UNAUTHENTICATED"->401;
   case "AUTHORIZATION_DENIED"->403;
   case "CONTEXT_TOO_LARGE","REQUEST_TOO_LARGE"->413;
   case "XSD_INVALID"->422;
   case "XML_INVALID","OUTBOUND_INVALID","BAD_REQUEST"->400;
   case "TRADING_UNAVAILABLE","TRADING_TIMEOUT"->503;
   case "TRADING_FAILED","TRADING_INVALID"->502;
   default->500;
  };
 }
}
