package com.example.intake.trading;
import com.example.intake.proto.trading.*;
import io.grpc.*;
import io.grpc.netty.shaded.io.grpc.netty.NettyServerBuilder;
import io.grpc.stub.StreamObserver;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Profile;
import org.springframework.beans.factory.annotation.Value;
import jakarta.annotation.*;
/** Local contract stub, not real authentication or trading logic. */
@Component @Profile("local")
public class LocalTradingMock {
 private Server server;private final int port;
 public LocalTradingMock(@Value("${trading.mock-port}") int port){this.port=port;}
 @PostConstruct public void start()throws Exception{
  server=NettyServerBuilder.forPort(port).addService(new TradingGrpc.TradingImplBase(){
   @Override public void lookup(TradingRequest request,StreamObserver<TradingReply> observer){
    String account=request.getAccountId();
    if("DOWN".equals(account)){observer.onError(Status.UNAVAILABLE.asRuntimeException());return;}
    observer.onNext(TradingReply.newBuilder().setAccountId(account).setAuthenticated(!"DENYAUTH".equals(account)).setAuthorized(!"DENYROLE".equals(account)).build());observer.onCompleted();
   }
  }).build().start();
 }
 @PreDestroy public void stop(){if(server!=null)server.shutdownNow();}
}
