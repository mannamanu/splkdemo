package com.example.intake.transport;
import com.example.intake.contract.*;
import com.example.intake.error.*;
import com.example.intake.xml.*;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
/** Direct-call adapter. Quote must schedule Activities separately for Temporal history. */
@Component
public class TransportFacade {
 public record Result(String xml,int status){}
 private final IntakeActivities activities;private final XmlResponses errors;private final XmlEngine xml;private final byte[] key;
 public TransportFacade(IntakeActivities activities,XmlResponses errors,XmlEngine xml,@Value("${intake.api-key}") String key){
  if(key==null||key.length()<16)throw new IllegalArgumentException("Configure an Intake API key of at least16 characters");
  this.activities=activities;this.errors=errors;this.xml=xml;this.key=key.getBytes(StandardCharsets.UTF_8);
 }
 public Result inbound(IntakeRequest input,String supplied){
  try{
   authorize(supplied);
   var state=activities.processInboundXMLRequest(input);state=activities.callTradingService(state);state=activities.authAuthz(state);state=activities.mapXmlToJson(state);
   var fields=new LinkedHashMap<String,String>();fields.put("RequestId",state.requestId());fields.put("Json",state.json());
   String result=xml.document("InboundResult",fields);xml.validate("inbound-result",result);return new Result(result,200);
  }catch(Exception failure){return failure(failure);}
 }
 public Result outbound(String input,String supplied){
  try{
   authorize(supplied);var doc=xml.validate("outbound-request",input);
   return new Result(activities.processOutbound(new OutboundRequest(xml.text(doc,"RequestId"),xml.text(doc,"QuoteId"),xml.text(doc,"Status"))),200);
  }catch(XmlProblem failure){return failure(ActivityErrors.reject("processOutbound","OUTBOUND_INVALID","Invalid outbound XML request"));}
  catch(Exception failure){return failure(failure);}
 }
 public Result failure(Throwable failure){var detail=errors.detail(failure);return new Result(errors.error(detail),errors.status(detail));}
 private void authorize(String supplied){
  if(supplied==null||!MessageDigest.isEqual(key,supplied.getBytes(StandardCharsets.UTF_8)))throw ActivityErrors.reject("transport","TRANSPORT_UNAUTHENTICATED","Valid service API key required");
 }
}
