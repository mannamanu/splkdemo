package com.example.intake.contract;
import io.temporal.activity.*;
@ActivityInterface
public interface IntakeActivities {
 @ActivityMethod(name="processInboundXMLRequest") AppContextDto processInboundXMLRequest(IntakeRequest request);
 @ActivityMethod(name="callTradingService") AppContextDto callTradingService(AppContextDto input);
 @ActivityMethod(name="authAuthz") AppContextDto authAuthz(AppContextDto input);
 @ActivityMethod(name="mapXmlToJson") AppContextDto mapXmlToJson(AppContextDto input);
 @ActivityMethod(name="processOutbound") String processOutbound(OutboundRequest input);
}
