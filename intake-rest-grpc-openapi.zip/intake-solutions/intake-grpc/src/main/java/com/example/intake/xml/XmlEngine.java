package com.example.intake.xml;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.*;
import javax.xml.validation.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;

@Component
public class XmlEngine {
 public static final int MAX=1048576;
 private final Map<String,Schema> schemas=new HashMap<>();
 private final Map<String,Templates> styles=new HashMap<>();
 public XmlEngine(@Value("${intake.assets-dir}") String directory){
  try{
   Path root=Path.of(directory).toRealPath();
   for(String file:List.of("request","response","error","inbound-result","outbound-request")){
    var f=SchemaFactory.newDefaultInstance();f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
    f.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD,"");f.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA,"");
    try(var in=Files.newInputStream(asset(root,file+".xsd"))){schemas.put(file,f.newSchema(new StreamSource(in)));}
   }
   for(String file:List.of("inbound","auth")){
    var f=factory();try(var in=Files.newInputStream(asset(root,file+".xsl"))){styles.put(file,f.newTemplates(new StreamSource(in)));}
   }
  }catch(Exception error){throw new IllegalStateException("Unable to compile configured Intake assets",error);}
 }
 private static Path asset(Path root,String name)throws Exception{
  Path path=root.resolve(name).toRealPath();if(!path.startsWith(root))throw new IllegalStateException("Invalid asset path");return path;
 }
 private static TransformerFactory factory()throws Exception{
  var f=TransformerFactory.newDefaultInstance();f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
  f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD,"");f.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET,"");
  f.setURIResolver((href,base)->{throw new TransformerException("External access denied");});return f;
 }
 public Document parse(String xml){
  if(xml==null || xml.getBytes(StandardCharsets.UTF_8).length>MAX)throw new XmlProblem(XmlProblem.Kind.TOO_LARGE);
  try{
   var f=DocumentBuilderFactory.newDefaultInstance();f.setNamespaceAware(true);
   f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
   f.setFeature("http://xml.org/sax/features/external-general-entities",false);f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
   f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD,"");f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA,"");
   f.setAttribute("http://www.oracle.com/xml/jaxp/properties/maxElementDepth",128);f.setXIncludeAware(false);f.setExpandEntityReferences(false);
   var builder=f.newDocumentBuilder();builder.setErrorHandler(new ErrorHandler(){public void warning(SAXParseException e)throws SAXException{throw e;}public void error(SAXParseException e)throws SAXException{throw e;}public void fatalError(SAXParseException e)throws SAXException{throw e;}});
   return builder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
  }catch(XmlProblem error){throw error;}catch(Exception error){throw new XmlProblem(XmlProblem.Kind.MALFORMED);}
 }
 public Document validate(String kind,String xml){
  var document=parse(xml);
  try{var validator=schemas.get(kind).newValidator();validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD,"");validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA,"");validator.validate(new DOMSource(document));return document;}
  catch(Exception error){throw new XmlProblem(XmlProblem.Kind.SCHEMA);}
 }
 public String transform(String name,String xml){
  try{var out=new LimitedOutput();styles.get(name).newTransformer().transform(new DOMSource(parse(xml)),new StreamResult(out));return out.toString(StandardCharsets.UTF_8);}
  catch(XmlProblem error){throw error;}catch(Exception error){throw new XmlProblem(XmlProblem.Kind.TRANSFORM);}
 }
 public String document(String root,Map<String,String> fields){
  var doc=parse("<"+root+"/>");fields.forEach((name,value)->{var element=doc.createElement(name);element.setTextContent(value);doc.getDocumentElement().appendChild(element);});return serialize(doc);
 }
 public String serialize(Document doc){
  try{var out=new LimitedOutput();factory().newTransformer().transform(new DOMSource(doc),new StreamResult(out));return out.toString(StandardCharsets.UTF_8);}
  catch(Exception error){throw new XmlProblem(XmlProblem.Kind.TRANSFORM);}
 }
 public String text(Document doc,String name){
  var nodes=doc.getDocumentElement().getElementsByTagName(name);if(nodes.getLength()!=1)throw new XmlProblem(XmlProblem.Kind.MAPPING);return nodes.item(0).getTextContent();
 }
 static final class LimitedOutput extends ByteArrayOutputStream {
  private void bound(int count){if(this.count+count>MAX)throw new XmlProblem(XmlProblem.Kind.TOO_LARGE);}
  @Override public synchronized void write(int b){bound(1);super.write(b);}
  @Override public synchronized void write(byte[] b,int off,int len){bound(len);super.write(b,off,len);}
 }
}
