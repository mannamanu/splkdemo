package com.example.intake.temporal;
import com.example.intake.contract.IntakeActivities;
import io.temporal.serviceclient.*;
import io.temporal.client.*;
import io.temporal.worker.*;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Component;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
@Component
@ConditionalOnProperty(name="temporal.enabled",havingValue="true")
public class IntakeWorker implements SmartLifecycle {
 private final WorkflowServiceStubs service;private final WorkerFactory factory;private boolean running;
 public IntakeWorker(IntakeActivities activities,@Value("${temporal.target}") String target,
  @Value("${temporal.namespace}") String namespace,@Value("${temporal.task-queue}") String queue,
  @Value("${temporal.tls}") boolean tls){
  service=WorkflowServiceStubs.newServiceStubs(WorkflowServiceStubsOptions.newBuilder().setTarget(target).setEnableHttps(tls).build());
  var client=WorkflowClient.newInstance(service,WorkflowClientOptions.newBuilder().setNamespace(namespace).build());
  factory=WorkerFactory.newInstance(client);var worker=factory.newWorker(queue,WorkerOptions.newBuilder().setMaxConcurrentActivityExecutionSize(8).build());
  worker.registerActivitiesImplementations(activities);
 }
 public void start(){service.connect(Duration.ofSeconds(15));factory.start();running=true;}
 public void stop(){factory.shutdown();factory.awaitTermination(15,TimeUnit.SECONDS);factory.shutdownNow();service.shutdown();running=false;}
 public boolean isRunning(){return running;}
}
