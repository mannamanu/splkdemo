package com.example.intake.activity;
import java.math.BigDecimal;
import com.example.intake.xml.XmlEngine;
import org.springframework.stereotype.Component;
import tools.jackson.databind.ObjectMapper;
@Component
public class JsonMapping {
 private final ObjectMapper mapper;private final XmlEngine xml;
 public JsonMapping(ObjectMapper mapper,XmlEngine xml){this.mapper=mapper;this.xml=xml;}
 public record BackendRequest(String requestId,String accountId,BigDecimal amount){}
 public String map(String document){
  var doc=xml.parse(document);
  return mapper.writeValueAsString(new BackendRequest(xml.text(doc,"RequestId"),xml.text(doc,"AccountId"),new BigDecimal(xml.text(doc,"Amount"))));
 }
}
