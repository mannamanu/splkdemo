package com.example.intake.transport;
import io.grpc.*;
import io.grpc.netty.shaded.io.grpc.netty.NettyServerBuilder;
import org.springframework.stereotype.Component;
import org.springframework.context.SmartLifecycle;
import org.springframework.beans.factory.annotation.Value;
import java.util.concurrent.*;
@Component
public class GrpcServer implements SmartLifecycle {
 private final IntakeGrpcEndpoint endpoint;private final int port;private Server server;private ExecutorService executor;
 public GrpcServer(IntakeGrpcEndpoint endpoint,@Value("${intake.port}") int port){this.endpoint=endpoint;this.port=port;}
 public void start(){
  try{executor=Executors.newFixedThreadPool(16);server=NettyServerBuilder.forPort(port).executor(executor).maxConcurrentCallsPerConnection(16).maxInboundMetadataSize(8192).maxInboundMessageSize(1048576+16384).addService(ServerInterceptors.intercept(endpoint,IntakeGrpcEndpoint.credentials())).build().start();}
  catch(Exception error){if(executor!=null)executor.shutdownNow();throw new IllegalStateException("Unable to start Intake gRPC",error);}
 }
 public void stop(){if(server!=null){server.shutdown();try{if(!server.awaitTermination(10,TimeUnit.SECONDS))server.shutdownNow();}catch(InterruptedException error){server.shutdownNow();Thread.currentThread().interrupt();}}if(executor!=null)executor.shutdownNow();}
 public boolean isRunning(){return server!=null&&!server.isShutdown();}
 public int boundPort(){return server.getPort();}
}
