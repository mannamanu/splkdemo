package com.example.intake.trading;
import com.example.intake.proto.trading.*;
import com.example.intake.contract.*;
import io.grpc.*;
import io.grpc.stub.MetadataUtils;
import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import jakarta.annotation.PreDestroy;
@Component
public class GrpcTradingClient implements TradingClient {
 private final ManagedChannel channel;
 private final TradingGrpc.TradingBlockingStub stub;
 private final int seconds;
 public GrpcTradingClient(@Value("${trading.target}") String target,@Value("${trading.tls}") boolean tls,
  @Value("${trading.token}") String token,@Value("${trading.deadline-seconds}") int seconds,Environment env){
  boolean local=java.util.Arrays.asList(env.getActiveProfiles()).contains("local");
  if(!tls&&!local)throw new IllegalArgumentException("Trading requires TLS outside local profile");
  if(seconds<1)throw new IllegalArgumentException("Trading deadline must be positive");
  var builder=ManagedChannelBuilder.forTarget(target).maxInboundMessageSize(65536);
  if(tls)builder.useTransportSecurity();else builder.usePlaintext();channel=builder.build();
  var headers=new Metadata();if(!token.isBlank())headers.put(Metadata.Key.of("authorization",Metadata.ASCII_STRING_MARSHALLER),"Bearer "+token);
  stub=TradingGrpc.newBlockingStub(channel).withInterceptors(MetadataUtils.newAttachHeadersInterceptor(headers));this.seconds=seconds;
 }
 public TradingResponseDto lookup(TradingRequestDto request){
  var reply=stub.withDeadlineAfter(seconds,TimeUnit.SECONDS).lookup(TradingRequest.newBuilder().setAccountId(request.accountId()).setRequestId(request.requestId()).setTransactionId(request.transactionId()).setIpaddress(request.ipaddress()).setXForwardedFor(request.xForwardedFor()).build());
  return new TradingResponseDto(reply.getAccountId(),reply.getAuthenticated(),reply.getAuthorized());
 }
 @PreDestroy public void close(){channel.shutdownNow();}
}
