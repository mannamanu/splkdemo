package com.example.intake.trading;
import com.example.intake.contract.*;
public interface TradingClient { TradingResponseDto lookup(TradingRequestDto request); }
