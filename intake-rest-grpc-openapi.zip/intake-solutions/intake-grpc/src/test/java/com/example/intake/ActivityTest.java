package com.example.intake;
import com.example.intake.activity.*;
import com.example.intake.contract.*;
import com.example.intake.error.*;
import com.example.intake.xml.*;
import com.example.intake.trading.*;
import io.temporal.failure.ApplicationFailure;
import io.grpc.Status;
import tools.jackson.databind.ObjectMapper;
import java.nio.file.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
class ActivityTest {
 final XmlEngine xml=new XmlEngine("./xml-assets");final TradingClient trading=mock(TradingClient.class);
 final JsonMapping mapping=new JsonMapping(new ObjectMapper(),xml);
 final IntakeActivitiesImpl activities=new IntakeActivitiesImpl(xml,trading,mapping,new TradingRequestMapper());
 IntakeRequest request(String xml){return new IntakeRequest(xml,"TX-1001","192.0.2.10","192.0.2.10, 198.51.100.20");}
 IntakeRequest input()throws Exception{return request(Files.readString(Path.of("samples/request.xml")));}
 AppContextDto authorized()throws Exception{var state=activities.processInboundXMLRequest(input());return state.withTrading(new TradingRequestMapper().map(state),new TradingResponseDto(state.accountId(),true,true));}
 void check(ApplicationFailure error,String step,String code,boolean retry){
  var detail=error.getDetails().get(0,IntakeError.class);assertEquals(step,detail.activity());assertEquals(code,detail.code());assertEquals(retry,detail.retryable());assertEquals(!retry,error.isNonRetryable());xml.validate("error",new XmlResponses(xml).error(error));
 }
 @Test void inboundSuccess()throws Exception{var state=activities.processInboundXMLRequest(input());assertEquals("REQ-1",state.requestId());assertEquals("ACCT-1",state.accountId());assertTrue(state.xml().contains("CanonicalRequest"));}
 @Test void malformedSchemaAndXxeAreNonRetryable()throws Exception{
  check(assertThrows(ApplicationFailure.class,()->activities.processInboundXMLRequest(request("broken"))),"processInboundXMLRequest","XML_INVALID",false);
  check(assertThrows(ApplicationFailure.class,()->activities.processInboundXMLRequest(request(input().requestXML().replace("250000.00","-1")))),"processInboundXMLRequest","XSD_INVALID",false);
  check(assertThrows(ApplicationFailure.class,()->activities.processInboundXMLRequest(request("<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///etc/passwd'>]><x>&e;</x>"))),"processInboundXMLRequest","XML_INVALID",false);
 }
 @Test void transformationFailureIsOwnedByInbound()throws Exception{
  var broken=mock(XmlEngine.class);when(broken.transform(eq("inbound"),anyString())).thenThrow(new XmlProblem(XmlProblem.Kind.TRANSFORM));
  check(assertThrows(ApplicationFailure.class,()->new IntakeActivitiesImpl(broken,trading,mapping,new TradingRequestMapper()).processInboundXMLRequest(request("<x/>"))),"processInboundXMLRequest","INBOUND_TRANSFORM_FAILED",false);
 }
 @Test void tradingSuccessAndMismatch()throws Exception{
  var state=authorized();when(trading.lookup(any())).thenReturn(new TradingResponseDto("ACCT-1",true,true));
  var enriched=activities.callTradingService(state);assertTrue(enriched.authorized());
  assertEquals(state.intakeRequest(),enriched.intakeRequest());assertEquals("TX-1001",enriched.tradingRequest().transactionId());
  assertEquals("192.0.2.10",enriched.tradingRequest().ipaddress());assertNotNull(enriched.tradingResponse());
  verify(trading).lookup(enriched.tradingRequest());when(trading.lookup(any())).thenReturn(new TradingResponseDto("WRONG",true,true));
  check(assertThrows(ApplicationFailure.class,()->activities.callTradingService(state)),"callTradingService","TRADING_INVALID",false);
 }
 @Test void tradingStatusClassification()throws Exception{
  var state=authorized();
  for(var status:new io.grpc.Status[]{Status.UNAVAILABLE,Status.DEADLINE_EXCEEDED,Status.PERMISSION_DENIED}){
   doThrow(status.withDescription("private secret").asRuntimeException()).when(trading).lookup(any());
   String code=status==Status.UNAVAILABLE?"TRADING_UNAVAILABLE":status==Status.DEADLINE_EXCEEDED?"TRADING_TIMEOUT":"TRADING_FAILED";
   check(assertThrows(ApplicationFailure.class,()->activities.callTradingService(state)),"callTradingService",code,status!=Status.PERMISSION_DENIED);
  }
 }
 @Test void authSuccessAndDenials()throws Exception{
  var state=authorized();assertEquals(state,activities.authAuthz(state));
  check(assertThrows(ApplicationFailure.class,()->activities.authAuthz(state.withTrading(state.tradingRequest(),new TradingResponseDto(state.accountId(),false,true)))),"authAuthz","AUTHENTICATION_FAILED",false);
  check(assertThrows(ApplicationFailure.class,()->activities.authAuthz(state.withTrading(state.tradingRequest(),new TradingResponseDto(state.accountId(),true,false)))),"authAuthz","AUTHORIZATION_DENIED",false);
 }
 @Test void authTransformationFailure()throws Exception{
  var broken=mock(XmlEngine.class);when(broken.document(anyString(),any())).thenThrow(new XmlProblem(XmlProblem.Kind.TRANSFORM));
  check(assertThrows(ApplicationFailure.class,()->new IntakeActivitiesImpl(broken,trading,mapping,new TradingRequestMapper()).authAuthz(authorized())),"authAuthz","AUTH_TRANSFORM_FAILED",false);
 }
 @Test void mappingSuccessAndFailure()throws Exception{
  var state=authorized();assertTrue(activities.mapXmlToJson(state).json().contains("250000.00"));
  var broken=mock(JsonMapping.class);when(broken.map(anyString())).thenThrow(new IllegalArgumentException("private XML"));
  check(assertThrows(ApplicationFailure.class,()->new IntakeActivitiesImpl(xml,trading,broken,new TradingRequestMapper()).mapXmlToJson(state)),"mapXmlToJson","JSON_MAPPING_FAILED",false);
 }
 @Test void outboundSuccessAndFailure(){
  xml.validate("response",activities.processOutbound(new OutboundRequest("REQ-1","Q-1","QUOTED")));
  check(assertThrows(ApplicationFailure.class,()->activities.processOutbound(new OutboundRequest("REQ-1","Q-1","INVALID"))),"processOutbound","OUTBOUND_INVALID",false);
 }
 @Test void boundsDepthAssets(){
  assertThrows(XmlProblem.class,()->xml.parse("<x>".repeat(150)+"</x>".repeat(150)));
  check(assertThrows(ApplicationFailure.class,()->activities.processInboundXMLRequest(request("x".repeat(XmlEngine.MAX+1)))),"processInboundXMLRequest","REQUEST_TOO_LARGE",false);
  assertThrows(IllegalStateException.class,()->new XmlEngine("missing-assets"));
 }

 @Test void invalidMetadataIsClassifiedInsideInbound()throws Exception{
  check(assertThrows(ApplicationFailure.class,()->activities.processInboundXMLRequest(new IntakeRequest(input().requestXML(),"bad transaction!","192.0.2.10",""))),"processInboundXMLRequest","BAD_REQUEST",false);
  check(assertThrows(ApplicationFailure.class,()->activities.processInboundXMLRequest(new IntakeRequest(input().requestXML(),"TX-1","ip\r\nspoof",""))),"processInboundXMLRequest","BAD_REQUEST",false);
 }
 @Test void contextAndNewRequestRoundTripThroughTemporalConverter()throws Exception{
  var context=authorized();var converter=io.temporal.common.converter.DefaultDataConverter.STANDARD_INSTANCE;
  var payload=converter.toPayload(context).orElseThrow();
  var decoded=converter.fromPayload(payload,AppContextDto.class,AppContextDto.class);
  assertEquals(context,decoded);assertEquals("TX-1001",decoded.intakeRequest().transactionId());
  assertEquals(context.intakeRequest(),activities.mapXmlToJson(context).intakeRequest());
 }

 @Test void oversizedSerializedContextIsRejectedBeforeTemporalCompletion()throws Exception{
  String sample=input().requestXML();String padded=" ".repeat(XmlEngine.MAX-sample.length())+sample;
  check(assertThrows(ApplicationFailure.class,()->activities.processInboundXMLRequest(request(padded))),"processInboundXMLRequest","CONTEXT_TOO_LARGE",false);
 }
}
