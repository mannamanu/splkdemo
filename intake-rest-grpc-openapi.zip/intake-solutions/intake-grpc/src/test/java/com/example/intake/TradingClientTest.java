package com.example.intake;
import com.example.intake.trading.*;
import com.example.intake.contract.TradingRequestDto;
import com.example.intake.proto.trading.*;
import io.grpc.*;
import io.grpc.netty.shaded.io.grpc.netty.NettyServerBuilder;
import io.grpc.stub.StreamObserver;
import org.springframework.mock.env.MockEnvironment;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class TradingClientTest {
 @Test void actualGrpcStubUsesContractAndDeadline()throws Exception{
  var server=NettyServerBuilder.forPort(0).addService(new TradingGrpc.TradingImplBase(){
   public void lookup(TradingRequest request,StreamObserver<TradingReply> observer){
    assertNotNull(Context.current().getDeadline());assertEquals("TX-1",request.getTransactionId());assertEquals("192.0.2.10",request.getIpaddress());observer.onNext(TradingReply.newBuilder().setAccountId(request.getAccountId()).setAuthenticated(true).setAuthorized(true).build());observer.onCompleted();
   }
  }).build().start();
  var env=new MockEnvironment();env.setActiveProfiles("local");
  var client=new GrpcTradingClient("localhost:"+server.getPort(),false,"",2,env);
  try{assertTrue(client.lookup(new TradingRequestDto("REQ-1","ACCT-1","TX-1","192.0.2.10","192.0.2.10")).authenticated());}finally{client.close();server.shutdownNow();}
 }
}
