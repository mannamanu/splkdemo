package com.example.intake;
import com.example.intake.activity.*;
import com.example.intake.contract.*;
import com.example.intake.trading.*;
import com.example.intake.xml.*;
import com.example.intake.error.*;
import io.temporal.testing.TestWorkflowEnvironment;
import io.temporal.workflow.*;
import io.temporal.client.*;
import io.temporal.api.enums.v1.EventType;
import tools.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
class TemporalIntegrationTest {
 // Test-only Quote surrogate, never packaged in application sources.
 @WorkflowInterface public interface Harness {@WorkflowMethod String execute(IntakeRequest request);}
 public static class HarnessImpl implements Harness {
  public String execute(IntakeRequest request){
   var a=stub("processInboundXMLRequest");var state=a.processInboundXMLRequest(request);
   state=stub("callTradingService").callTradingService(state);state=stub("authAuthz").authAuthz(state);state=stub("mapXmlToJson").mapXmlToJson(state);
   if(!"TX-TEMPORAL".equals(state.tradingRequest().transactionId()) || state.tradingResponse()==null)throw new IllegalStateException("Context not preserved");
   if(state.json()==null)throw new IllegalStateException("Missing JSON");
   // External Quote/RateQuote behavior intentionally not implemented in this test.
   return stub("processOutbound").processOutbound(new OutboundRequest(state.requestId(),"Q-TEST","QUOTED"));
  }
  private IntakeActivities stub(String step){return Workflow.newActivityStub(IntakeActivities.class,IntakeActivityOptions.forActivity("intake-test",step));}
 }
 @Test void sameHistorySequentialActivitiesAndRetry()throws Exception{
  try(var env=TestWorkflowEnvironment.newInstance()){
   var trading=mock(TradingClient.class);when(trading.lookup(any())).thenThrow(io.grpc.Status.UNAVAILABLE.asRuntimeException()).thenReturn(new TradingResponseDto("ACCT-1",true,true));
   var xml=new XmlEngine("./xml-assets");var activities=new IntakeActivitiesImpl(xml,trading,new JsonMapping(new ObjectMapper(),xml),new TradingRequestMapper());
   var worker=env.newWorker("intake-test");worker.registerWorkflowImplementationTypes(HarnessImpl.class);worker.registerActivitiesImplementations(activities);env.start();
   var workflow=env.getWorkflowClient().newWorkflowStub(Harness.class,WorkflowOptions.newBuilder().setWorkflowId("sequential").setTaskQueue("intake-test").build());
   xml.validate("response",workflow.execute(new IntakeRequest(Files.readString(Path.of("samples/request.xml")),"TX-TEMPORAL","192.0.2.1","")));
   var history=env.getWorkflowClient().fetchHistory("sequential").getHistory();
   var names=history.getEventsList().stream().filter(e->e.getEventType()==EventType.EVENT_TYPE_ACTIVITY_TASK_SCHEDULED).map(e->e.getActivityTaskScheduledEventAttributes().getActivityType().getName()).toList();
   assertEquals(List.of("processInboundXMLRequest","callTradingService","authAuthz","mapXmlToJson","processOutbound"),names);
   verify(trading,times(2)).lookup(any());
  }
 }
 @Test void denialStopsLaterActivitiesAndRetainsXmlError()throws Exception{
  try(var env=TestWorkflowEnvironment.newInstance()){
   var trading=mock(TradingClient.class);when(trading.lookup(any())).thenReturn(new TradingResponseDto("ACCT-1",false,false));
   var xml=new XmlEngine("./xml-assets");var activities=spy(new IntakeActivitiesImpl(xml,trading,new JsonMapping(new ObjectMapper(),xml),new TradingRequestMapper()));
   var worker=env.newWorker("intake-test");worker.registerWorkflowImplementationTypes(HarnessImpl.class);worker.registerActivitiesImplementations(activities);env.start();
   var workflow=env.getWorkflowClient().newWorkflowStub(Harness.class,WorkflowOptions.newBuilder().setWorkflowId("rejected").setTaskQueue("intake-test").build());
   var failure=assertThrows(WorkflowFailedException.class,()->workflow.execute(new IntakeRequest(Files.readString(Path.of("samples/request.xml")),"TX-TEMPORAL","192.0.2.1","")));
   var responses=new XmlResponses(xml);assertEquals("authAuthz",responses.detail(failure).activity());assertEquals("AUTHENTICATION_FAILED",responses.detail(failure).code());
   xml.validate("error",responses.error(failure));verify(activities,never()).mapXmlToJson(any());verify(activities,never()).processOutbound(any());verify(trading,times(1)).lookup(any());
  }
 }
}
