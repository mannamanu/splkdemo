package com.example.intake;
import com.example.intake.xml.XmlEngine;
import com.example.intake.transport.GrpcServer;
import com.example.intake.proto.intake.*;
import com.google.protobuf.ByteString;
import io.grpc.*;
import io.grpc.stub.MetadataUtils;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,properties={"spring.profiles.active=local","intake.port=0","trading.mock-port=19092","trading.target=localhost:19092"})
class TransportTest {
 @Autowired org.springframework.core.env.Environment env;
 @Autowired GrpcServer server;@Autowired XmlEngine xml;
 @Test void grpcReturnsXmlForSuccessDenialAndOutbound()throws Exception{
  var channel=ManagedChannelBuilder.forAddress("localhost",server.boundPort()).usePlaintext().build();
  try{
   var headers=new Metadata();headers.put(Metadata.Key.of("x-api-key",Metadata.ASCII_STRING_MARSHALLER),"local-intake-key-123456");
   var stub=IntakeGrpc.newBlockingStub(channel).withInterceptors(MetadataUtils.newAttachHeadersInterceptor(headers)).withDeadlineAfter(10,TimeUnit.SECONDS);
   var success=stub.processInbound(inbound("request"));assertEquals(200,success.getHttpEquivalentStatus());xml.validate("inbound-result",success.getXml().toStringUtf8());
   var denied=stub.processInbound(inbound("auth-denied"));assertEquals(401,denied.getHttpEquivalentStatus());xml.validate("error",denied.getXml().toStringUtf8());
   var out=stub.processOutbound(request("outbound"));assertEquals(200,out.getHttpEquivalentStatus());xml.validate("response",out.getXml().toStringUtf8());
   var unauthenticated=IntakeGrpc.newBlockingStub(channel).withDeadlineAfter(10,TimeUnit.SECONDS).processInbound(inbound("request"));assertEquals(401,unauthenticated.getHttpEquivalentStatus());xml.validate("error",unauthenticated.getXml().toStringUtf8());
  }finally{channel.shutdownNow();}
 }
 private IntakeRequest inbound(String name)throws Exception{return IntakeRequest.newBuilder().setRequestXml(Files.readString(Path.of("samples/"+name+".xml"))).setTransactionId("TX-1001").setIpaddress("192.0.2.10").setXForwardedFor("192.0.2.10").build();}
 private XmlRequest request(String name)throws Exception{return XmlRequest.newBuilder().setXml(ByteString.copyFrom(Files.readAllBytes(Path.of("samples/"+name+".xml")))).build();}

 @Test void openApiDocumentsHttpSurfaceAndGrpcExtension()throws Exception{
  var url=java.net.URI.create("http://localhost:"+env.getProperty("local.server.port")+"/openapi.yaml");
  var result=java.net.http.HttpClient.newHttpClient().send(java.net.http.HttpRequest.newBuilder(url).GET().build(),java.net.http.HttpResponse.BodyHandlers.ofString());
  assertEquals(200,result.statusCode());assertTrue(result.body().contains("x-grpc-service"));assertTrue(result.body().contains("AppContextDto"));
  var schemaUrl=java.net.URI.create("http://localhost:"+env.getProperty("local.server.port")+"/contracts/schemas/IntakeRequest.yaml");
  var schema=java.net.http.HttpClient.newHttpClient().send(java.net.http.HttpRequest.newBuilder(schemaUrl).GET().build(),java.net.http.HttpResponse.BodyHandlers.ofString());
  assertEquals(200,schema.statusCode());assertTrue(schema.body().contains("requestXML"));
 }
}
