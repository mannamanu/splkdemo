package com.example.intake;
import com.example.intake.contract.*;
import io.temporal.common.converter.DefaultDataConverter;
import tools.jackson.databind.ObjectMapper;
import java.nio.file.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class SharedContractTest {
 @Test void generatedRecordsPreserveSharedJsonWireFixture()throws Exception{
  var mapper=new ObjectMapper();String fixture=Files.readString(Path.of("../contracts/fixtures/app-context.json"));
  var context=mapper.readValue(fixture,AppContextDto.class);
  assertEquals("TX-1001",context.intakeRequest().transactionId());assertTrue(context.authenticated());
  assertEquals(mapper.readTree(fixture),mapper.readTree(mapper.writeValueAsString(context)));
  var converter=DefaultDataConverter.STANDARD_INSTANCE;var payload=converter.toPayload(context).orElseThrow();
  assertEquals(mapper.readTree(fixture),mapper.readTree(payload.getData().toStringUtf8()));
  assertEquals(context,converter.fromPayload(payload,AppContextDto.class,AppContextDto.class));
 }
}
