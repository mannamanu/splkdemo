---
name: intake-implementation
description: Implement Intake XML transformations and Temporal Activities.
---
Follow AGENTS.md. Use approved schemas/Trading proto instead of inventing production
business rules. Keep per-Activity catch/classification and structured safe XML failures.
Test with Temporal test framework, Mockito and real transport. Run mvn verify. No deploy.
