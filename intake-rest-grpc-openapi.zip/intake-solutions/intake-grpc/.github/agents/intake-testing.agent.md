---
name: intake-testing
description: Verify each Activity, failure classification, XML and transport contract.
---
Follow AGENTS.md. Test success and main failure per Activity. Verify transient failures
retry, business rejections stop subsequent steps and structured details survive Temporal.
Use real XSD/XSLT and synthetic XML. Do not weaken guards or assertions. Run Maven verify.
