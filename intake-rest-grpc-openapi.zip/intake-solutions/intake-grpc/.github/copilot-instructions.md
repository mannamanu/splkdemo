Follow AGENTS.md. Keep per-Activity errors and secure XML processing. Run Maven verify.
