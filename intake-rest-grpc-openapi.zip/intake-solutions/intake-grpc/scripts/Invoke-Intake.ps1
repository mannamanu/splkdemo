param([ValidateSet('ProcessInbound','ProcessOutbound')][string]$Method='ProcessInbound', [string]$File='', [string]$Target='localhost:9090')
$ErrorActionPreference='Stop'
if($Method -eq 'ProcessInbound'){
 if(!$File){$File='samples/request.json'}
 $payload=Get-Content -Raw $File
}else{
 if(!$File){$File='samples/outbound.xml'}
 $payload=@{xml=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path $File)))} | ConvertTo-Json -Compress
}
$payload | grpcurl -plaintext -max-time 15 -H 'x-api-key: local-intake-key-123456' -import-path src/main/proto -proto intake.proto -d '@' $Target "intake.v1.Intake/$Method"
if($LASTEXITCODE -ne 0){throw 'grpcurl request failed'}
