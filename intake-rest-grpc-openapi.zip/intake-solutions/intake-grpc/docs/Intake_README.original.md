## Objective

You are a senior backend engineer working in a Spring Boot / Temporal codebase. Generate the complete Intake service implementation for **[intake_service_name]**, built on **Java 25, Spring Boot, and Maven**, using **Temporal** for workflow orchestration and **XML / XSD / XSL** for message handling and transformation. The service must be generated in the transport style **[transport_style]**, which will be either `gRPC` or `REST`. Generate only the variant that matches the chosen value, not both.

The hardest constraint: **failures must be handled inside each Temporal activity**, not by a centralized REST-style exception handler. The final response returned to the caller is always **XML**, whether the outcome is success or failure.

## Architecture Context

Two services are involved. Only the Intake service is being generated; the quoteWorkflow service is existing and is referenced only for integration points.

### quoteWorkflow Service (existing, not generated)
- Uses Temporal; the workflow **starts here**.
- Triggers a call to the Intake service.
- After the Intake service completes its four activities and returns JSON, quoteWorkflow takes that JSON and triggers another activity in a different, separate service.
- Once that is complete, quoteWorkflow triggers the Intake service's final activity, `processOutbound`.

### Intake Service (to be generated)
Implement these **four Temporal activities**, executed in this order:

1. **processInboundXMLRequest** — receives the inbound XML request, validates it against the XSD, and applies an XSL transformation.
2. **callTradingService** — calls the Trading service over **gRPC**.
3. **authAuthz** — performs authentication/authorization using an **XML transformation** (XSL).
4. **mapXmlToJson** — maps the resulting XML into JSON.

After `mapXmlToJson` completes, the Intake service's part of this phase is done. The JSON is returned to quoteWorkflow.

Later, quoteWorkflow invokes the Intake service's final activity:

5. **processOutbound** — produces the final outbound response.

## Legacy Behavior vs. New Requirement

- **Old application:** The Intake service used a `GlobalExceptionHandler` that returned an error response when any step failed. This was a REST API call.
- **New implementation:** Do **not** rely on a global exception handler for step failures. Handle failures **within each activity** that is triggered, so each activity owns its own error handling and failure result.

For each activity:
- Catch and classify failures specific to that activity (for example XSD validation or transformation errors, gRPC status errors from the Trading service, authorization denials, and JSON mapping errors).
- Distinguish **retryable** failures (for example transient gRPC `UNAVAILABLE` or timeouts) from **non-retryable** failures (for example schema validation errors or authorization denials). Use Temporal's `ApplicationFailure` and the activity's retry options accordingly.
- Produce a structured failure that identifies the failing activity, an error code, and a message, so the workflow can propagate it.
- Make sure the failure ultimately surfaces to the caller as an **XML error response** (see Output Requirements).

## Technical Requirements

- **Language/Build:** Java 25, Maven, Spring Boot.
- **Orchestration:** Temporal Java SDK. Define the activity interface(s) and implementations, the worker configuration, and the activity options (timeouts, retry policy) per activity.
- **XML handling:** Provide the XSD for request validation and the XSL stylesheets for the inbound transformation and the authAuthz transformation. Use JAXP/`TransformerFactory` with secure processing enabled (disable external entities/DTDs to prevent XXE).
- **gRPC client:** Include the `.proto` for the Trading service call and the generated-stub client used by `callTradingService`, with a deadline set on each call.
- **Transport layer (only the one selected via [transport_style]):**
  - If `gRPC`: define the `.proto` service for the Intake service's inbound entry point, the Spring Boot gRPC service implementation, and the Maven dependencies/plugins needed.
  - If `REST`: define a `@RestController` for the Intake service's inbound entry point that accepts XML and returns XML, with `produces`/`consumes` set to `application/xml`.
- **Project structure:** Provide a `pom.xml`, a package layout, configuration (`application.yml`), and all source files, XSD, XSL, and proto files needed for the service to compile and run.

## Output Requirements

- The **final response is always XML**, for both success and failure.
- Define a consistent XML error response structure (backed by an XSD) that includes at minimum: the failing activity name, an error code, and a human-readable message.
- Success responses from `processOutbound` must also be valid XML and conform to a defined XSD.

## Scope Constraints

- Generate only the Intake service for the selected transport. Do not generate the quoteWorkflow service or the "other service" activity; stub or reference them only as needed for the Intake interfaces to make sense.
- Do not introduce a `GlobalExceptionHandler` as the primary failure mechanism. A minimal fallback at the transport boundary is acceptable only to guarantee the XML error format for failures that escape an activity, and it must not replace per-activity handling.
- Match idiomatic Spring Boot and Temporal patterns; do not add extra abstraction layers, frameworks, or design patterns the task does not need.
- Include unit tests for each activity's success path and its main failure paths (invalid XML, gRPC failure, authorization denial, mapping failure), using Temporal's test framework where appropriate.

## Deliverable

Provide all files in full, each labeled with its path (for example `src/main/java/.../ProcessInboundActivityImpl.java`), so they can be copied directly into the project. Briefly note any assumptions you had to make about the Trading service contract or the XML schema where the details were not provided, rather than inventing detailed business rules.