# Quote Workflow integration (reference only)

Quote Workflow and the other service are not generated. These are integration snippets
for the existing Quote codebase, not a deployed additional Workflow in Intake.

## Preferred Temporal worker path

Both variants implement the same IntakeActivities interface. Quote and Intake must use
the same namespace, DataConverter and compatible contract DTOs. Choose one task queue
and configure it consistently. Default queue differs between the two sample applications.

The five explicit Activity names are the stable wire contract:
processInboundXMLRequest(IntakeRequest) -> callTradingService(AppContextDto) -> authAuthz -> mapXmlToJson ->
(existing external Quote/RateQuote activity) -> processOutbound.

Quote must construct an Activity stub using options for the relevant step, for example:

```java
private IntakeActivities intake(String step) {
    return Workflow.newActivityStub(
        IntakeActivities.class,
        IntakeActivityOptions.forActivity("intake-rest-v2-activities", step));
}

// Inside the existing Quote Workflow method:
var intakeRequest = new IntakeRequest(inputXml, transactionId, ipaddress, xForwardedFor);
AppContextDto state = intake("processInboundXMLRequest").processInboundXMLRequest(intakeRequest);
state = intake("callTradingService").callTradingService(state);
state = intake("authAuthz").authAuthz(state);
state = intake("mapXmlToJson").mapXmlToJson(state);

// Existing Quote implementation consumes state.json() and invokes its other service.
// Merge/correlate that response in Quote, then adapt it to OutboundRequest:
return intake("processOutbound").processOutbound(
    new OutboundRequest(state.requestId(), quoteIdFromOtherService, "QUOTED"));
```

Use intake-grpc-v2-activities instead if selecting the gRPC application. Do not start both
variants on the same queue with different business mappings. A successful normal method
return marks an Activity Completed. A rejected Activity fails with ApplicationFailure;
later sequential steps are not scheduled. Transient Trading failures retry (max3 attempts,
5sec gRPC deadline,15sec StartToClose,60sec ScheduleToClose). Other steps use10sec attempt,
30sec overall,max2, but explicitly rejected failures never retry. Options belong to the
calling Quote Workflow, not the Activity implementation; use the supplied factory.

To keep all five steps in the SAME Quote history, use these Activity calls. No HTTP/gRPC
Intake API call is needed on this path. Temporal schedules tasks; the Intake worker polls
and reports completion/failure. Trading is still a real gRPC call within its Activity.

## Structured failure -> final XML

Every Activity catches/classifies its own errors. Expected/permanent errors use
ApplicationFailure type INTAKE_REJECTED (non-retryable); transient Trading failures use
INTAKE_TRANSIENT. Both contain an IntakeError record with activity/code/message/retryable.
No original exception cause/message or request XML is put into error details.

Let the failure propagate to Quote's API client call (or catch and construct an explicit
failure result in Quote). At the actual caller response boundary, extract the details:

```java
IntakeError detail = null;
for (Throwable cause = workflowFailure; cause != null; cause = cause.getCause()) {
    if (cause instanceof ApplicationFailure app
            && ("INTAKE_REJECTED".equals(app.getType())
                || "INTAKE_TRANSIENT".equals(app.getType()))
            && app.getDetails().getSize() > 0) {
        detail = app.getDetails().get(0, IntakeError.class);
        break;
    }
}
// Render safe detail into IntakeError XML conforming to xml-assets/error.xsd.
// Preserve your existing final XML transport contract; never return exception.toString().
```

Intake's XmlResponses demonstrates safe DOM-based rendering/escaping and XSD validation.
When rendering in Quote, use your existing XML renderer or reuse this code with the same
error XSD. Fallback when missing/unreadable details to a generic XML error. Retryable in
XML describes the failure category, not a promise of endless retries or safe client retry.
Do not automatically retry the whole Workflow after a business rejection. Restrict the
DTO/status/code values that the public API accepts. Failed credential checks typically
map401, denied roles403, invalid schemas422 and Trading outages503.

Final XML cannot be guaranteed by Intake alone if Quote owns the client's connection:
Quote must render the propagated failure as XML. Direct Intake transport APIs already do.
If Quote responds202 immediately, use a status endpoint/callback for the eventual XML.

## Direct transport compatibility path

The application's inbound/outbound REST or gRPC endpoints call the same implementations
synchronously for compatibility and local testing. Those calls do NOT create Temporal
Activity records or apply Temporal retries. Inbound accepts IntakeRequest (REST JSON/native protobuf) and returns an XML InboundResult envelope
with JSON text; when Quote schedules mapXmlToJson directly it receives state.json().
Outbound is a separate call with the quote information and returns final XML.

Do not wrap the entire inbound HTTP/gRPC call in one Quote Activity and expect four
nested Activity records. If your existing Quote insists on invoking a single transport
endpoint while retaining individual Activities, redesign that handoff explicitly (for
example Quote message passing); this sample does not secretly start another Workflow.

## Contract sharing

Run mvn package. The additional *-contracts.jar contains contract DTOs/interfaces/options
only. Publish it to your internal Maven registry and depend on classifier contracts in
Quote (plus matching Temporal SDK). Do not depend on the executable Spring Boot JAR.
Both variants' contract packages are identical; publish/select one canonical artifact.

```xml
<dependency>
  <groupId>com.example</groupId>
  <artifactId>intake-rest</artifactId>
  <version>2.1.0</version>
  <classifier>contracts</classifier>
</dependency>
```

Intake source has no Workflow implementation. TemporalIntegrationTest contains only a
test-scope surrogate to prove ordering/retry/error payload serialization. It is excluded
from application/contract JARs. Temporal persists Activity inputs/results/failures; use
approved encrypted payload conversion and size-conscious references for real borrower
data. Neither sample sends API keys or Trading bearer tokens in Activity arguments.

Shared schema generation and TypeScript Workflow examples: ../../contracts/README.md.
