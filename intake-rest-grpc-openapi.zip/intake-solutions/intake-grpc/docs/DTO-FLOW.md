# Version 2 DTO flow

```mermaid
flowchart TD
 R["IntakeRequest: XML and metadata"] --> P["processInboundXMLRequest"]
 P --> C["AppContextDto: original request, IDs, transformed XML"]
 C --> T["callTradingService: map TradingRequestDto and call gRPC"]
 T --> E["AppContextDto: add Trading request and response"]
 E --> A["authAuthz: evaluate trusted Trading flags"]
 A --> J["mapXmlToJson: add JSON, preserve context"]
```

## Fields

| DTO | Fields |
|---|---|
| IntakeRequest | requestXML, transactionId, ipaddress, xForwardedFor |
| AppContextDto | intakeRequest, requestId, accountId, xml, json, tradingRequest, tradingResponse |
| TradingRequestDto | requestId, accountId, transactionId, ipaddress, xForwardedFor |
| TradingResponseDto | accountId, authenticated, authorized |

Request/account IDs come from validated XML. Correlation/network metadata comes from the
IntakeRequest. The mapper is explicit; replace illustrative Trading fields/proto with the
approved contract. Trading reply accountId must match the context accountId. No request
metadata can grant authentication/authorization. No credentials are stored in context.
Metadata rejects missing required strings, control characters and excessive lengths.

Records are immutable. callTradingService returns context.withTrading(mappedRequest,response);
mapXmlToJson returns context.withJson(json). Earlier Activity snapshots cannot be mutated.
No cross-request global context, ThreadLocal, shared payload map or mutable singleton state.
Temporal serialization includes these fields; apply your sensitive-data retention and
payload encryption policy. The error path continues to use safe IntakeError details.

## Contracts and history migration

This changes processInboundXMLRequest from String -> IntakeState to
IntakeRequest -> AppContextDto, and subsequent Activity signatures to AppContextDto.
That is a breaking Temporal payload contract change. Activity names are unchanged for
business observability; new v2 queues distinguish workers. Deploy matching Quote contract
version2.0.0 for new executions. Keep old workflow/worker builds for old runs, or implement
Temporal Workflow versioning/patching. A simple rolling replacement on old queues can
break deserialization/replay. Do not reset old runs blindly into the new implementation.

Native ProcessInbound protobuf now takes IntakeRequest with request_xml, transaction_id,
ipaddress, x_forwarded_for; protobuf JSON names are requestXML, transactionId, ipaddress,
xForwardedFor. Regenerate callers. ProcessOutbound retains XmlRequest (bytes XML).
Trading protobuf adds transaction_id, ipaddress, x_forwarded_for on new field numbers;
existing Trading servers may ignore them until upgraded. Verify the real backend contract.

## OpenAPI

REST spec describes JSON IntakeRequest plus legacy XML inbound, XML outbound, all common
XML errors and HTTP health endpoints. Common context/Trading schemas document the internal
Temporal contract; they are not public request bodies for arbitrary context injection.

The gRPC app spec exposes only real HTTP health paths and common DTO schemas. The
x-grpc-service extension documents RPC names and proto location; Swagger UI cannot execute
native gRPC. Use grpcurl/generated clients against9090. No phantom HTTP endpoints exist.
