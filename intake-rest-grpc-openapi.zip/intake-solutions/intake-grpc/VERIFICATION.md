# Shared-schema generation verification — 2.1.0

Executed 2026-10-16 with Corretto25.0.4, Maven3.9.11, Node24.19.0.

- Clean Maven verify passed: 19 tests, zero failures/errors/skips.
- OpenAPI Generator7.17.0 generated the six Java records from shared external schemas;
  the application compiles those generated records, with no duplicate handwritten DTOs.
- Java Temporal conversion and Jackson serialization match contracts/fixtures/app-context.json.
- Existing Activity/Trading/transport/Temporal-order/retry/error tests passed.
- OpenAPI and externally referenced schema URLs tested through real HTTP servers.
- Executable/contract JAR contents checked for generated records and packaged schema assets.
- Shared Node package passed OpenAPI validation, TypeScript generation/build/type checks,
  immutable/required-field type checks, JSON fixture round-trip and both spec bundles.
- Bundled specs checked: all refs internal; checked-in external refs resolve locally.
- JaCoCo (generated protobuf only excluded): 86.47% lines, 64.54% branches.
- ZIP integrity/source/spec/lockfile/report contents checked.

Node tool scripts use documented Redocly telemetry-off and update-check-off settings.
No telemetry authorization is required for the final local checks. Package installations
used approved registry/proxy/CA settings; TLS verification was not disabled.

Not executed: Docker runtime, actual TypeScript Temporal Workflow deployment/interoperability,
real Quote/Trading/IdP/Temporal Cloud/AWS, registry publication, Windows helper or load tests.
The shared JSON fixture verifies wire structure; no deployed cross-language Workflow is claimed.

HTML/XML coverage reports in verification/jacoco; future builds regenerate target/site/jacoco.
