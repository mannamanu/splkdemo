package com.example.intake;
import com.example.intake.xml.XmlEngine;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,properties={"spring.profiles.active=local","trading.mock-port=19091","trading.target=localhost:19091"})
class TransportTest {
 @Autowired Environment env;@Autowired XmlEngine xml;final HttpClient client=HttpClient.newHttpClient();
 HttpResponse<String> post(String path,String body,String key,String type)throws Exception{
  return client.send(HttpRequest.newBuilder(URI.create("http://localhost:"+env.getProperty("local.server.port")+path)).header("Content-Type",type).header("X-API-Key",key).POST(HttpRequest.BodyPublishers.ofString(body)).build(),HttpResponse.BodyHandlers.ofString());
 }
 @Test void inboundOutboundAndDenialAlwaysXml()throws Exception{
  var success=post("/api/v1/intake/inbound",Files.readString(Path.of("samples/request.xml")),"local-intake-key-123456","application/xml");assertEquals(200,success.statusCode());xml.validate("inbound-result",success.body());assertTrue(success.body().contains("250000.00"));
  var denied=post("/api/v1/intake/inbound",Files.readString(Path.of("samples/auth-denied.xml")),"local-intake-key-123456","application/xml");assertEquals(401,denied.statusCode());xml.validate("error",denied.body());assertTrue(denied.body().contains("authAuthz"));
  var out=post("/api/v1/intake/outbound",Files.readString(Path.of("samples/outbound.xml")),"local-intake-key-123456","application/xml");assertEquals(200,out.statusCode());xml.validate("response",out.body());
 }
 @Test void transportAuthenticationAndFrameworkFallbackAreXml()throws Exception{
  var denied=post("/api/v1/intake/inbound","<x/>","wrong","application/xml");assertEquals(401,denied.statusCode());xml.validate("error",denied.body());
  var unsupported=post("/api/v1/intake/inbound","{}","local-intake-key-123456","text/plain");assertEquals(415,unsupported.statusCode());xml.validate("error",unsupported.body());
 }

 @Test void jsonDtoInboundAndInvalidMetadata()throws Exception{
  var json=Files.readString(Path.of("samples/request.json"));
  var result=post("/api/v1/intake/inbound",json,"local-intake-key-123456","application/json");assertEquals(200,result.statusCode());xml.validate("inbound-result",result.body());
  var invalid=post("/api/v1/intake/inbound",json.replace("TX-1001","invalid id!"),"local-intake-key-123456","application/json");assertEquals(400,invalid.statusCode());xml.validate("error",invalid.body());
 }
 @Test void openApiAndSwaggerAreServed()throws Exception{
  for(String path:new String[]{"/openapi.yaml","/swagger-ui/index.html","/contracts/schemas/IntakeRequest.yaml","/contracts/schemas/AppContextDto.yaml"}){
   var result=client.send(HttpRequest.newBuilder(URI.create("http://localhost:"+env.getProperty("local.server.port")+path)).GET().build(),HttpResponse.BodyHandlers.ofString());
   assertEquals(200,result.statusCode());if(path.equals("/openapi.yaml")){assertTrue(result.body().contains("AppContextDto"));assertTrue(result.body().contains("../../contracts/schemas/IntakeRequest.yaml"));}
  }
 }
}
