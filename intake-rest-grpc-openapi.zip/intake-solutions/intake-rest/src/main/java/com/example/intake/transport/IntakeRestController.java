package com.example.intake.transport;
import com.example.intake.error.ActivityErrors;
import com.example.intake.xml.XmlEngine;
import com.example.intake.contract.IntakeRequest;
import tools.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.nio.*;
import java.nio.charset.*;
@RestController
@RequestMapping("/api/v1/intake")
public class IntakeRestController {
 private final TransportFacade facade;private final ObjectMapper mapper;
 private static final int MAX_HTTP_BODY=7*XmlEngine.MAX;
 public IntakeRestController(TransportFacade facade,ObjectMapper mapper){this.facade=facade;this.mapper=mapper;}
 @PostMapping(value="/inbound",consumes="application/xml",produces="application/xml")
 public ResponseEntity<String> inbound(HttpServletRequest request){return execute(request,false);}
 @PostMapping(value="/inbound",consumes="application/json",produces="application/xml")
 public ResponseEntity<String> inboundDto(HttpServletRequest request){return execute(request,false);}
 @PostMapping(value="/outbound",consumes="application/xml",produces="application/xml")
 public ResponseEntity<String> outbound(HttpServletRequest request){return execute(request,true);}
 private ResponseEntity<String> execute(HttpServletRequest request,boolean outbound){
  TransportFacade.Result result;
  try{
   if(request.getContentLengthLong()>MAX_HTTP_BODY)throw ActivityErrors.reject("transport","REQUEST_TOO_LARGE","XML request too large");
   byte[] body=request.getInputStream().readNBytes(MAX_HTTP_BODY+1);
   if(body.length>MAX_HTTP_BODY)throw ActivityErrors.reject("transport","REQUEST_TOO_LARGE","XML request too large");
   String input=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(body)).toString();
   if(outbound)result=facade.outbound(input,request.getHeader("X-API-Key"));
   else if(request.getContentType()!=null&&request.getContentType().toLowerCase(java.util.Locale.ROOT).startsWith("application/json")){
    IntakeRequest dto;
    try{dto=mapper.readValue(input,IntakeRequest.class);}catch(Exception error){throw ActivityErrors.reject("transport","BAD_REQUEST","Invalid IntakeRequest JSON");}
    result=facade.inbound(dto,request.getHeader("X-API-Key"));
   }else{
    String transaction=request.getHeader("X-Transaction-ID");
    if(transaction==null)transaction="legacy-"+java.util.UUID.randomUUID();
    String ip=request.getHeader("X-Client-IP");if(ip==null)ip=request.getRemoteAddr();
    String forwarded=request.getHeader("X-Forwarded-For");if(forwarded==null)forwarded="";
    result=facade.inbound(new IntakeRequest(input,transaction,ip,forwarded),request.getHeader("X-API-Key"));
   }
  }catch(CharacterCodingException error){result=facade.failure(ActivityErrors.reject("transport","XML_INVALID","UTF-8 XML required"));}
  catch(Exception error){result=facade.failure(error);}
  return ResponseEntity.status(result.status()).contentType(MediaType.APPLICATION_XML).cacheControl(CacheControl.noStore()).body(result.xml());
 }
}
