package com.example.intake.transport;
import com.example.intake.error.*;
import com.example.intake.contract.IntakeError;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
/** Framework-only XML fallback; business failure classification remains in Activities. */
@RestControllerAdvice
public class XmlTransportFallback extends ResponseEntityExceptionHandler {
 private final XmlResponses responses;
 public XmlTransportFallback(XmlResponses responses){this.responses=responses;}
 @Override protected ResponseEntity<Object> handleExceptionInternal(Exception error,Object body,HttpHeaders headers,HttpStatusCode status,WebRequest request){
  var safe=new HttpHeaders();safe.putAll(headers);safe.setContentType(MediaType.APPLICATION_XML);safe.setCacheControl("no-store");
  return new ResponseEntity<>(responses.error(new IntakeError("transport","BAD_REQUEST","Invalid HTTP request",false)),safe,status);
 }
 @ExceptionHandler(Exception.class) public ResponseEntity<String> fallback(Exception error){
  return ResponseEntity.internalServerError().contentType(MediaType.APPLICATION_XML).cacheControl(CacheControl.noStore()).body(responses.error(error));
 }
}
