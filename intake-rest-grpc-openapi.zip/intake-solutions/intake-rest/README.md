# intake-rest

Java25 / Spring Boot4.0.8 / Maven application implementing the attached
Intake_README.md in **REST transport**. Only Intake is generated. Trading
uses gRPC in both variants. No Quote Workflow or other business service is deployed.

## What is implemented

Five Temporal Activities: processInboundXMLRequest, callTradingService, authAuthz,
mapXmlToJson, processOutbound. Each implementation owns catch/classification. Safe
structured IntakeError details cross Temporal in ApplicationFailure. There is no global
business exception handler. Permanent failures never retry; Trading UNAVAILABLE and
DEADLINE_EXCEEDED are retryable. IntakeActivityOptions supplies per-step caller options.

Request/error/success XSDs, inbound/auth XSLT, Trading proto/stub, worker lifecycle,
transport entry points, unit/Mockito/XML/real transport tests and Temporal test harness.
Schemas and Templates warm once at startup; mutable parsers/validators/transformers are
request-local. Bounded1MiB XML/depth128; Trading reply64KiB/deadline5sec. Secure JAXP
blocks DOCTYPE/entities/XInclude/external schemas/stylesheets. No arbitrary file paths.

## Architecture distinction

**The preferred Quote-owned Workflow calls Intake Activities through Temporal.** Intake
polls the configured queue; Quote schedules the five steps and receives JSON after
mapXmlToJson, then schedules processOutbound after its other service returns. Its client
response is final XML; Quote must render propagated Activity failures as XML too.

**Direct REST entry points are a separate compatibility/testing path.** They run
the pre-phase synchronously, returning XML containing the intermediate JSON. The outbound
entry returns final XML later. They do not schedule Temporal work or retry independently.
See docs/QUOTE-INTEGRATION.md for precise integration code and the contracts JAR.
No second Workflow is silently started in Intake.

## Assumptions — replace before real integration

No official schemas, Trading proto, identity-provider contract or detailed business rules
were provided. Bundled XML is a deliberately small synthetic request, not official MISMO
or DU. Trading.Lookup(accountId,requestId) is an illustrative read-only lookup returning
trusted authenticated/authorized flags, and auth.xsl maps those flags into a decision.
XSLT does not verify passwords, JWT signatures or certificates. Real authentication must
be performed by your approved identity/trading provider. Never trust flags from caller XML.
The outbound example has RequestId/QuoteId/Status only; replace with your actual merged
quote contract and XSD. No invented financial/pricing rules are included.

## Prerequisites and run

Extract the whole intake-solutions bundle, keeping contracts as a sibling of both applications. For native: Amazon Corretto JDK25 and Maven3.9.11+.
Check java --version and mvn --version use25. Install grpcurl for gRPC examples. Docker
Desktop/Engine + Compose v2 can build/run without a host Java installation. Dependencies
and base images require network access through approved Maven/registry settings.

```bash
cd intake-rest
mvn -B -ntp verify
java -jar target/app.jar --spring.profiles.active=local
```

Local profile disables the Temporal worker and starts an in-process **real gRPC** Trading
mock on9091. Intake REST and health on8080.
Mock accounts DENYAUTH, DENYROLE and DOWN exercise auth denial, role denial and unavailable
Trading. They are demonstration behavior only, absent without the local profile.

```bash
docker compose up --build -d
docker compose logs -f --tail=100
docker compose down
```

Docker builds/tests with JDK25 and runs on Amazon Corretto25 as user10001. One container
per variant, with local Trading mock and read-only xml-assets bind mount. No Temporal is
required for direct local API tests. Run one variant at a time or change published ports.
To clone after you publish a repo, use your real URL (no remote repo was created here):

```bash
git clone https://github.com/YOUR-ORG/intake-solutions.git
cd intake-solutions/intake-rest
```

## API examples

REST calls (use curl.exe on Windows):

```bash
curl -i http://localhost:8080/api/v1/intake/inbound \
  -H 'Content-Type: application/xml' -H 'X-API-Key: local-intake-key-123456' \
  --data-binary @samples/request.xml
curl -i http://localhost:8080/api/v1/intake/outbound \
  -H 'Content-Type: application/xml' -H 'X-API-Key: local-intake-key-123456' \
  --data-binary @samples/outbound.xml
```

Replace request.xml with auth-denied.xml or role-denied.xml for XML401/403 responses.
Responses have application/xml and Cache-Control:no-store. Unsupported content types,
missing routes and method mismatches use a minimal XML framework fallback, not business
rule classification. Only UTF-8 XML is accepted. XML declaration must match UTF-8.


Inbound success is a schema-validated InboundResult XML containing RequestId and Json.
Outbound success is IntakeResponse XML. Errors conform to error.xsd, for example:

```xml
<IntakeError><Activity>authAuthz</Activity><Code>AUTHORIZATION_DENIED</Code>
<Message>Authorization denied</Message><Retryable>false</Retryable></IntakeError>
```

## Enable the actual Temporal worker

Keep the local profile for a local Trading mock, and explicitly override its disabled
worker setting. Start your existing local Temporal server first (or supply its endpoint):

```bash
java -jar target/app.jar --spring.profiles.active=local \
  --temporal.enabled=true --temporal.target=localhost:7233
```

Temporal namespace default and task queue intake-rest-v2-activities. Quote must use the same
namespace/queue/contracts/options. Connectors poll outbound; no inbound HTTP callback from
Temporal. Workers register only Activities. Polling by itself will not create Workflow
executions. The existing Quote Workflow must schedule them. No Quote app is generated.

Outside local mode configure INTAKE_API_KEY (16+chars), TRADING_TARGET, TRADING_TLS=true,
TRADING_TOKEN if required, TEMPORAL_TARGET, TEMPORAL_NAMESPACE and INTAKE_TASK_QUEUE.
The sample worker supports local/private Temporal and server-authenticated TLS via
TEMPORAL_TLS=true. Temporal Cloud API-key/mTLS credential wiring is **not included**;
add your approved connection credentials before targeting a secured cluster. Protect
Temporal namespace access; trusted Workflow callers can supply Activity DTOs directly.
Production configs fail if Trading is plaintext or the Intake API key is missing.

## XML assets and errors

XML_ASSETS_DIR defaults to ./xml-assets relative to working directory. Containers use
/app/xml-assets. Parent-folder mount is possible; keep it read-only and accessible by
user10001. No hot reload: restart after changes. Fail startup on missing/invalid assets.
Imports/includes are denied; approved real schema bundles need an allowlisted local
resolver and tests rather than enabling unrestricted external access.

Business errors are classified inside each Activity. ActivityErrors is an ordinary
helper, not another Activity. Structured failures preserve activity/code/message/retryable.
Retryable refers to the category; exhausted Temporal retries still finish failed. No
payload/token/exception text is used in public messages. Error details/inputs/results
are persisted by Temporal; apply encryption/retention policy for real sensitive data.

The final caller error format depends on Quote's response boundary when using Temporal.
Do not assume Intake can write to the HTTP connection owned by Quote. See integration doc.
Transport-level TLS/framing failures occurring before dispatch may not contain XML.

## Health, tests, coverage and agents

```bash
curl http://localhost:8080/actuator/health/liveness
curl http://localhost:8080/actuator/health/readiness
mvn -B -ntp verify
```

Health is lifecycle-based, status-only, and not an end-to-end Trading check. Source tests
cover each Activity success/main failures, Trading gRPC classification/deadline, actual
transport XML envelopes, and test-only Temporal ordering/retries/skip behavior. JaCoCo
HTML/XML at target/site/jacoco. See VERIFICATION.md for executed tests and limits.

Open the root in VS Code Copilot: select intake-implementation or intake-testing from
Chat's agent picker. AGENTS.md and .github/copilot-instructions.md provide shared rules;
CLAUDE.md provides Claude entry instructions. Attach approved schema/Trading proto and
synthetic fixtures; ask for the smallest change plus tests and Maven verify. No AI runtime
or API keys are added. Review changes before committing/deployment.

## Deployment notes

No AWS resources are deployed. For AWS, publish the image to ECR and deploy as an ECS
service/worker with outbound Temporal/Trading connectivity and secret injection. REST
needs an HTTPS ingress on8080; gRPC needs HTTP/2 ingress to9090. Both expose health8080.
Limit ingress, terminate TLS, rotate service credentials and configure cluster auth.
Terraform/cloud provisioning is outside this attachment's Intake-only implementation.

## Version 2: request, context and OpenAPI

See docs/DTO-FLOW.md for fields, metadata validation, request mapping and migration.
IntakeRequest.java is a Java record DTO with exactly requestXML, transactionId, ipaddress,
xForwardedFor. transactionId is required (1–64 letters/digits/_/-); both IP metadata strings
are required but may be empty. They are opaque bounded metadata, not authenticated identity.

AppContextDto.java is the immutable Activity result/input. It contains intakeRequest,
requestId, accountId, xml (canonical transformed XML), json, tradingRequest and tradingResponse.
TradingRequestMapper constructs the Trading request within callTradingService. Both the
mapped request and trusted Trading response are saved in the context. Subsequent steps
preserve them. Authentication booleans are derived from tradingResponse, not client input.
The full business field list was unspecified; extend the typed records with approved fields.

XML input remains bounded1MiB. Because the context contains original+transformed XML, its
serialized default-Temporal payload is independently capped at1MiB (CONTEXT_TOO_LARGE/413).
Large documents should move to approved external object references rather than duplicating
megabytes in every Activity history event. If replacing DataConverter, review the budget.

OpenAPI3.0.3 source: openapi/openapi.yaml (copied to static resources during Maven build).
Live specification: http://localhost:8080/openapi.yaml
Swagger UI: http://localhost:8080/swagger-ui/index.html (enabled by local profile).
Swagger uses the checked-in spec, not inferred HttpServletRequest body shapes. The static
spec is served by the application; UI is disabled outside local unless API_DOCS_ENABLED=true.
Native gRPC calls are described by intake.proto, not callable through OpenAPI/Swagger UI.
The gRPC app OpenAPI covers HTTP health, common DTO schemas, and an x-grpc-service extension
for documentation only. No HTTP-to-gRPC gateway or REST business controller was added.

New contracts artifact version2.0.0 and default v2 task queues require Quote integration
changes. Keep old workers/contracts for old executions. Version/patch Quote Workflow code
or drain in-flight runs; changing a queue alone does not make old Workflow replay compatible.
See docs/DTO-FLOW.md and docs/QUOTE-INTEGRATION.md.

REST typed inbound example (responses remain application/xml):

```bash
curl -i http://localhost:8080/api/v1/intake/inbound \
  -H 'Content-Type: application/json' -H 'X-API-Key: local-intake-key-123456' \
  --data-binary @samples/request.json
```

The same endpoint still accepts raw application/xml for compatibility. X-Transaction-ID,
X-Client-IP and X-Forwarded-For populate IntakeRequest metadata in that mode. A missing
transaction header generates a legacy-* UUID at the HTTP boundary. JSON field metadata
is used as submitted (after validation); proxies must sanitize/inject metadata if it will
be trusted for auditing. HTTP JSON body cap7MiB allows JSON escaping of1MiB XML; the decoded
XML/context budgets still apply. Outbound XML contract is unchanged.

## Version 2.1: shared schemas and generated models

Reusable definitions moved to ../contracts/schemas. This application's openapi/openapi.yaml
references them; Maven packages shared files under static/contracts/schemas for Swagger.
The six Temporal wire records are now generated automatically from ../contracts/openapi.yaml
using OpenAPI Generator and the record template. Do not recreate handwritten DTO duplicates.

Generate Java: `mvn generate-sources`. Node types: run `npm ci && npm test` from
../contracts/typescript. See ../contracts/README.md for Java/TypeScript usage, Node Workflow
proxyActivities integration, publishing, validation and single-file spec bundles.

Keep the contracts sibling folder when building or using Compose. This refactor retains
the version2 JSON shape and v2 task queues; use new Maven/npm package version2.1.0. Source
models compile from target/generated-sources/openapi; generated Java DTO code is packaged
in the contracts classifier JAR. Rebuild Java consumers when updating dependencies.
