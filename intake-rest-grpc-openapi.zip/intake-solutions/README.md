# Intake implementations

Two independently deployed Maven applications sharing the contracts folder generated from Intake_README.md:
- intake-rest: XML REST entry points; Trading uses gRPC.
- intake-grpc: protobuf Intake entry points containing XML; Trading uses gRPC.

Choose one. Both register the same five Activity names; do not run both against the
same production task queue unless intentionally sharing equivalent implementations.
Each application README explains direct transport calls versus Quote-owned Temporal
Activity scheduling. No Quote service or other business service is generated.

## Start

Extract the bundle, then select one:

```bash
cd intake-rest
# Or cd intake-grpc
mvn -B -ntp verify
java -jar target/app.jar --spring.profiles.active=local
```

Or `docker compose up --build -d` in the selected application directory. Local mode
includes a Trading gRPC mock, disables Temporal polling, and permits direct transport
smoke tests with the documented local key. Enable the worker explicitly to integrate
with the existing Quote Workflow and Temporal server.

## Requirement map

| Requirement | Files in each application |
|---|---|
| Five stable Temporal Activity contracts | contract/IntakeActivities.java |
| Each Activity catches/classifies its errors | activity/IntakeActivitiesImpl.java |
| Timeouts/retries per step | contract/IntakeActivityOptions.java |
| Worker polls Intake task queue | temporal/IntakeWorker.java |
| Trading gRPC proto/client/deadline | src/main/proto/trading.proto; trading/GrpcTradingClient.java |
| XML validation, XSLT, secure JAXP | xml/XmlEngine.java; xml-assets/ |
| Error/success XML schemas | xml-assets/error.xsd; xml-assets/response.xsd |
| JSON mapping | activity/JsonMapping.java |
| REST entry (REST variant only) | transport/IntakeRestController.java |
| gRPC entry (gRPC variant only) | src/main/proto/intake.proto; transport/IntakeGrpcEndpoint.java |
| Quote consumer reference and XML error rendering | docs/QUOTE-INTEGRATION.md |
| Full sources/build instructions | pom.xml; src/; README.md |
| Unit, transport and Temporal tests | src/test/java/ |
| Executed coverage reports | verification/jacoco/index.html |

All Java paths above are under src/main/java/com/example/intake unless shown otherwise.
The included original README records the supplied requirements. The two apps are
alternatives, not an Intake REST app forwarding to an Intake gRPC app.


## Version 2 update

Both applications now use IntakeRequest -> AppContextDto -> enriched AppContextDto, with
an explicit TradingRequestMapper and stored Trading request/response. See each app's
docs/DTO-FLOW.md. OpenAPI specs live in each openapi/openapi.yaml. Swagger UI is enabled
locally. Native gRPC still uses protobuf, not an HTTP API implied by OpenAPI.

Use v2 contract artifacts and queues for new Quote executions; migrate Workflow code
with versioning or drain old runs. The previous String/IntakeState contract is incompatible.


## Version 2.1 — shared schema generation

Both specs now reference contracts/schemas/*.yaml. Java DTO records are generated during
Maven generate-sources/compile/verify; Node workflow types are generated with
contracts/typescript (`npm ci && npm test`). See contracts/README.md for the full commands,
examples, package consumption and external-ref/bundle details. Keep the complete bundle
layout; apps require their sibling contracts folder for source generation/Docker builds.
