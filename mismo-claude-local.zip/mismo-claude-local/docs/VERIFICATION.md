# Verification — PostgreSQL revision

## Checks completed for this revision

- Docker Compose 2.39.2 successfully parsed/interpolated the full configuration using `.env.example` (`config --quiet` and JSON output); no Docker daemon is needed for this check.
- Verified the PostgreSQL driver, both database names, matching credentials, persistent volume path, private database port, and health-gated PostgreSQL -> Temporal -> orchestrator startup graph in the resolved configuration.
- Confirmed registry availability of `postgres:16.6`, `temporalio/auto-setup:1.28.0`, and `temporalio/ui:2.39.0`.
- Parsed every Maven POM and the sample XML; Bash syntax-checked every supplied shell script.
- Byte-compared all application/test Java resources, Maven POMs and the Dockerfile against the previously delivered codebase: they are unchanged. This revision changes deployment, documentation and operational scripts.
- Verified the final archive contains the complete four-module Maven source, configuration, sample and scripts, with no build outputs or real `.env` secrets.

## Previous application verification retained

The unchanged baseline compiled and packaged for Java 25 (class major version 69), and all 15 tests passed using Maven 3.9.11 and Java 25 with Surefire in-process (`-DforkCount=0`) because downloaded JDK files were truncated between execution steps in that environment. That environment workaround is not part of the delivered POM or Dockerfile.

The previous three-service process-level smoke test passed against Temporal's SQLite development server on JDK 17 with a temporary build override. It was not a PostgreSQL integration test and is not evidence that this new container stack has been executed.

## Not executed here

A Docker runtime/daemon is unavailable. PostgreSQL container startup, automatic schema initialization, SQL visibility, and workflow persistence across PostgreSQL/Temporal restarts have not been executed in this environment. AWS deployment has not been executed.

To verify on your Docker host, start the stack and run:

```bash
bash scripts/verify-postgres.sh
bash scripts/smoke-test.sh
```

Optionally, on an idle local stack, run `bash scripts/verify-persistence.sh`. That last script stops and restarts the database/server/worker/UI; it does not remove volumes.
