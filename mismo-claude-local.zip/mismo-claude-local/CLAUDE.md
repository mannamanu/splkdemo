# MISMO local project

This is a reference implementation for Claude Code to review, run, modify, or regenerate locally. It was prepared in ChatGPT; it has not been generated or verified by Claude. Follow the user's requested scope.

## Stack and layout
- Java 25, Maven, Spring Boot 4.0.8, Temporal Java SDK 1.39.0.
- `common`: bounded, namespace-aware XML parsing, JSON conversion, HTTP helpers and API-key filter.
- `orchestrator-service`: HTTP API and embedded Temporal worker.
- `auth-service`: demo enabled-account list and XML/account-header match.
- `order-service`: XML-to-JSON tree conversion.
- `compose.yaml`: PostgreSQL 16.6, Temporal auto-setup 1.28.0, UI 2.39.0, and three services.
- PostgreSQL stores Temporal history and SQL visibility in separate databases. No application JDBC connection is needed.

## Behavior to preserve
- POST `/api/orders` accepts `application/xml`; validates account before transforming; returns XML synchronously.
- Header keys: `X-Api-Key`, `X-Account-Id`, `Idempotency-Key`.
- HTTP result wait is 40 seconds after start RPC; workflow deadline is 45 seconds.
- All network/database work belongs in activities or services, not workflow code.
- XML parsing must reject external entities/DOCTYPE and preserve namespaces/repeated elements.
- Duplicate protection currently hashes account + key + exact XML. This is content-addressed deduplication, not key-only conflict detection.
- Auth is a demo eligibility check, not proof of account ownership. Response XML and the JSON mapping are examples, not validated MISMO contracts.

## Local commands
- Read `START-HERE.md`, `README.md`, `docs/POSTGRES.md` and `docs/VERIFICATION.md`.
- Create `.env` from `.env.example` only if `.env` does not already exist.
- `docker compose config --quiet`
- `docker compose up --build -d`
- `docker compose ps`
- `bash scripts/verify-postgres.sh`
- `bash scripts/smoke-test.sh`
- Host build with JDK 25/Maven: `mvn -B -ntp verify`.
- `scripts/verify-persistence.sh` intentionally stops/restarts services; run only when requested on an idle local stack.

## Changes and reporting
- Read existing monorepo instructions and neighboring services before integrating. Retain their parent POM, package and configuration conventions; avoid replacing the monorepo root files.
- Keep secrets out of tracked files and output. Demo keys live only in `.env.example`; real secrets belong in local `.env` or deployed secret injection.
- Keep existing database volumes. Do not run `down -v`, prune volumes or delete history to fix a startup error.
- Do not claim unexecuted checks passed. Report build, tests, Compose validation and actual container execution separately.
- Describe remaining demo account/MISMO limitations rather than calling the sample production-ready.
