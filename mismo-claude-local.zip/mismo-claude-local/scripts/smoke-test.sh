#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${API_KEY:=local-client-key-change-me}"
base="${BASE_URL:-http://localhost:8080}"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
ready=false
for attempt in {1..60}; do
  if curl -fsS "$base/actuator/health/readiness" > /dev/null 2>&1; then ready=true; break; fi
  sleep 2
done
if [ "$ready" != true ]; then printf 'Orchestrator did not become ready\n' >&2; exit 1; fi
key="smoke-$(date +%s)"
call() {
  curl -sS --max-time 55 -D "$tmp/headers" -o "$tmp/body" -w '%{http_code}'     "$base/api/orders" -H 'Content-Type: application/xml'     -H "X-Api-Key: $API_KEY" -H "X-Account-Id: $1"     -H "Idempotency-Key: $key" --data-binary "@$2"
}
status=$(call ACC1001 samples/request.xml)
test "$status" = 200
grep -q '<Status>SUCCESS</Status>' "$tmp/body"
cp "$tmp/body" "$tmp/first"
grep -i '^X-Workflow-Id:' "$tmp/headers" > "$tmp/id1"
status=$(call ACC1001 samples/request.xml)
test "$status" = 200
cmp "$tmp/body" "$tmp/first"
grep -i '^X-Workflow-Id:' "$tmp/headers" > "$tmp/id2"
cmp "$tmp/id1" "$tmp/id2"
status=$(call ACC1002 samples/request.xml)
test "$status" = 403
printf '<MESSAGE>' > "$tmp/invalid.xml"
status=$(call ACC1001 "$tmp/invalid.xml")
test "$status" = 400
status=$(curl -sS -o "$tmp/body" -w '%{http_code}' "$base/api/orders" -H 'Content-Type: application/xml' --data-binary @samples/request.xml)
test "$status" = 401
printf 'PASS: success, duplicate replay, account mismatch, malformed XML, missing credential\n'
