#!/usr/bin/env bash
# LOCAL TEST ONLY: briefly stops the orchestrator, UI, Temporal and PostgreSQL.
# No volumes are deleted. Run only when no other requests are in flight.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${API_KEY:=local-client-key-change-me}"
base="${BASE_URL:-http://localhost:8080}"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
key="persist-$(date +%s)-$RANDOM"
call() {
  curl -fsS --max-time 55 -D "$tmp/$1.headers" -o "$tmp/$1.xml"     "$base/api/orders" -H 'Content-Type: application/xml'     -H "X-Api-Key: $API_KEY" -H 'X-Account-Id: ACC1001'     -H "Idempotency-Key: $key" --data-binary @samples/request.xml
  grep -q '<Status>SUCCESS</Status>' "$tmp/$1.xml"
  grep -i '^X-Workflow-Id:' "$tmp/$1.headers" > "$tmp/$1.id"
}
call before
# Stop the worker too, so the check cannot rely on its in-memory workflow cache.
docker compose stop orchestrator-service temporal-ui temporal postgres
docker compose up -d postgres temporal temporal-ui orchestrator-service
ready=false
for attempt in {1..90}; do
  if curl -fsS "$base/actuator/health/readiness" > /dev/null 2>&1; then ready=true; break; fi
  sleep 2
done
if [ "$ready" != true ]; then printf 'Orchestrator did not become ready\n' >&2; exit 1; fi
call after
cmp "$tmp/before.id" "$tmp/after.id"
cmp "$tmp/before.xml" "$tmp/after.xml"
printf 'PASS: identical workflow ID and persisted result after PostgreSQL, Temporal and worker restart\n'
