#!/usr/bin/env bash
# Read-only infrastructure checks; does not restart or delete anything.
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose exec -T postgres sh -ec '
  export PGPASSWORD="$POSTGRES_PASSWORD"
  psql -h 127.0.0.1 -U temporal -d temporal -v ON_ERROR_STOP=1 -c "SELECT curr_version FROM schema_version;"
  psql -h 127.0.0.1 -U temporal -d temporal_visibility -v ON_ERROR_STOP=1 -c "SELECT curr_version FROM schema_version;"
'
docker compose exec -T temporal temporal operator cluster health --address temporal:7233
docker compose exec -T temporal temporal operator namespace describe --address temporal:7233 --namespace default
printf 'PASS: PostgreSQL history and visibility schemas, Temporal health, default namespace\n'
