# PostgreSQL revision

- Replaced the SQLite CLI development server with Temporal Server backed by PostgreSQL.
- Added history and visibility schema initialization, a persistent PostgreSQL volume, namespace readiness checks, and a separate Temporal UI.
- Added a PostgreSQL password setting, database verification and optional restart/persistence scripts.
- Preserved the complete Spring Boot / Java 25 / Maven service implementation and API contract.
- Added cutover, SQL inspection, backup, troubleshooting, and AWS RDS/Temporal Cloud guidance.
- Existing SQLite history is not migrated or deleted by this package.
