package com.example.mismo.orchestrator;
import io.temporal.activity.*;
@ActivityInterface
public interface OrderActivities {
 @ActivityMethod void validate(String xml,String account);
 @ActivityMethod String transform(String xml);
}
