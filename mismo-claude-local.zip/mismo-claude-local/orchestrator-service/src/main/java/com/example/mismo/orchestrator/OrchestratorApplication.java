package com.example.mismo.orchestrator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication(scanBasePackages="com.example.mismo")
public class OrchestratorApplication {public static void main(String[] args){SpringApplication.run(OrchestratorApplication.class,args);}}
