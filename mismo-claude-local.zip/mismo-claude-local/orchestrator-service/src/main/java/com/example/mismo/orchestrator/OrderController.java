package com.example.mismo.orchestrator;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.time.Duration;
import java.util.HexFormat;
import java.util.concurrent.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import io.temporal.api.enums.v1.WorkflowIdReusePolicy;
import io.temporal.client.*;
import com.example.mismo.common.*;
@RestController
public class OrderController {
 private final WorkflowClient client;private final String queue;
 public OrderController(WorkflowClient client,@Value("${temporal.task-queue}")String queue){this.client=client;this.queue=queue;}
 @PostMapping(value="/api/orders",consumes="application/xml",produces="application/xml")
 public ResponseEntity<String> order(@RequestHeader("X-Account-Id")String account,@RequestHeader("Idempotency-Key")String key,HttpServletRequest request)throws IOException{
  if(!account.matches("[A-Za-z0-9_-]{1,64}")||!key.matches("[A-Za-z0-9_-]{1,100}"))throw new IllegalArgumentException("Invalid account or idempotency key");
  String xml=HttpSupport.read(request);Xml.parse(xml);
  String id="order-"+hash(account+"\n"+key+"\n"+xml);
  var typed=client.newWorkflowStub(OrderWorkflow.class,WorkflowOptions.newBuilder().setWorkflowId(id).setTaskQueue(queue)
   .setWorkflowExecutionTimeout(Duration.ofSeconds(45)).setWorkflowIdReusePolicy(WorkflowIdReusePolicy.WORKFLOW_ID_REUSE_POLICY_REJECT_DUPLICATE).build());
  try{
   try{WorkflowClient.start(typed::process,xml,account);}catch(WorkflowExecutionAlreadyStarted ignored){}
   var result=client.newUntypedWorkflowStub(id).getResult(40,TimeUnit.SECONDS,OrderWorkflow.Outcome.class);
   return ResponseEntity.status(result.status()).contentType(MediaType.APPLICATION_XML).header("X-Workflow-Id",id).body(result.xml());
  }catch(TimeoutException e){return reply(504,id,"WAIT_TIMEOUT","Workflow may still be running. Retry with identical headers and body.");}
   catch(WorkflowFailedException e){return reply(502,id,"WORKFLOW_FAILED","Workflow failed. Inspect Temporal using the workflow ID.");}
   catch(WorkflowServiceException|io.grpc.StatusRuntimeException e){return reply(503,id,"TEMPORAL_UNAVAILABLE","Retry with identical headers and body.");}
 }
 private ResponseEntity<String> reply(int status,String id,String code,String message){return ResponseEntity.status(status).contentType(MediaType.APPLICATION_XML).header("X-Workflow-Id",id).body(Xml.response(code,message));}
 private static String hash(String value){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
}
