package com.example.mismo.orchestrator;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import io.temporal.failure.ApplicationFailure;
@Component
public class HttpOrderActivities implements OrderActivities {
 private final HttpClient client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
 private final String authUrl,orderUrl,key;
 public HttpOrderActivities(@Value("${downstream.auth-url}")String authUrl,@Value("${downstream.order-url}")String orderUrl,@Value("${downstream.api-key}")String key){this.authUrl=authUrl;this.orderUrl=orderUrl;this.key=key;}
 public void validate(String xml,String account){call(authUrl+"/internal/auth/validate",xml,account);}
 public String transform(String xml){return call(orderUrl+"/internal/orders/transform",xml,null);}
 private String call(String url,String xml,String account){
  try{
   var b=HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(5)).header("Content-Type","application/xml").header("X-Api-Key",key);
   if(account!=null)b.header("X-Account-Id",account);
   var r=client.send(b.POST(HttpRequest.BodyPublishers.ofString(xml,StandardCharsets.UTF_8)).build(),HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
   if(r.statusCode()==403)throw ApplicationFailure.newNonRetryableFailure("Account denied","ACCOUNT_DENIED");
   if(r.statusCode()==400||r.statusCode()==413)throw ApplicationFailure.newNonRetryableFailure("Invalid XML","INVALID_XML");
   if(r.statusCode()>=400 && r.statusCode()<500 && r.statusCode()!=429)throw ApplicationFailure.newNonRetryableFailure("Downstream request rejected","DOWNSTREAM_REJECTED");
   if(r.statusCode()!=200)throw ApplicationFailure.newFailure("Downstream unavailable","DOWNSTREAM_UNAVAILABLE");
   if(r.body().length()>1048576)throw ApplicationFailure.newNonRetryableFailure("Transformed payload too large","INVALID_XML");
   return r.body();
  }catch(InterruptedException e){Thread.currentThread().interrupt();throw ApplicationFailure.newFailure("HTTP call interrupted","DOWNSTREAM_UNAVAILABLE");}
   catch(java.io.IOException e){throw ApplicationFailure.newFailure("HTTP transport failure","DOWNSTREAM_UNAVAILABLE");}
 }
}
