package com.example.mismo.orchestrator;
import io.temporal.client.*;
import io.temporal.serviceclient.*;
import io.temporal.worker.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
@Configuration
public class TemporalConfiguration {
 @Bean(destroyMethod="shutdown") WorkflowServiceStubs temporalService(@Value("${temporal.target}")String target,@Value("${temporal.tls}")boolean tls,@Value("${temporal.api-key}")String key){
  if(!key.isBlank()&&!tls)throw new IllegalArgumentException("Temporal API key requires TLS");
  var b=WorkflowServiceStubsOptions.newBuilder().setTarget(target).setEnableHttps(tls);
  if(!key.isBlank())b.addApiKey(()->key);
  return WorkflowServiceStubs.newServiceStubs(b.build());
 }
 @Bean WorkflowClient workflowClient(WorkflowServiceStubs service,@Value("${temporal.namespace}")String namespace){return WorkflowClient.newInstance(service,WorkflowClientOptions.newBuilder().setNamespace(namespace).build());}
 @Bean(initMethod="start",destroyMethod="shutdown") WorkerFactory workerFactory(WorkflowClient client,HttpOrderActivities activities,@Value("${temporal.task-queue}")String queue){
  var factory=WorkerFactory.newInstance(client);var worker=factory.newWorker(queue);
  worker.registerWorkflowImplementationTypes(OrderWorkflowImpl.class);worker.registerActivitiesImplementations(activities);return factory;
 }
}
