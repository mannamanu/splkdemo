package com.example.mismo.orchestrator;
import io.temporal.workflow.*;
@WorkflowInterface
public interface OrderWorkflow {
 @WorkflowMethod Outcome process(String xml,String account);
 record Outcome(int status,String xml){}
}
