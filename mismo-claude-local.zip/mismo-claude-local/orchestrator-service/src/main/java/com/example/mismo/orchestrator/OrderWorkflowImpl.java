package com.example.mismo.orchestrator;
import java.time.Duration;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.failure.*;
import io.temporal.workflow.Workflow;
import com.example.mismo.common.Xml;
public class OrderWorkflowImpl implements OrderWorkflow {
 private final OrderActivities activities=Workflow.newActivityStub(OrderActivities.class,
  ActivityOptions.newBuilder().setStartToCloseTimeout(Duration.ofSeconds(8)).setScheduleToCloseTimeout(Duration.ofSeconds(18))
   .setRetryOptions(RetryOptions.newBuilder().setInitialInterval(Duration.ofSeconds(1)).setMaximumInterval(Duration.ofSeconds(2)).setMaximumAttempts(3).build()).build());
 @Override public Outcome process(String xml,String account){
  try{
   activities.validate(xml,account);
   return new Outcome(200,Xml.success(activities.transform(xml)));
  }catch(ActivityFailure e){
   Throwable c=e.getCause();
   if(c instanceof ApplicationFailure a){
    if("ACCOUNT_DENIED".equals(a.getType()))return new Outcome(403,Xml.response("ACCOUNT_DENIED","Account is not authorized"));
    if("INVALID_XML".equals(a.getType()))return new Outcome(400,Xml.response("INVALID_XML","XML could not be processed"));
   }
   return new Outcome(502,Xml.response("DOWNSTREAM_FAILURE","A dependent service could not complete the request"));
  }
 }
}
