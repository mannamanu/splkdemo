package com.example.mismo.orchestrator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.atomic.AtomicInteger;
import io.temporal.testing.TestWorkflowEnvironment;
import io.temporal.client.WorkflowOptions;
import io.temporal.failure.ApplicationFailure;
class OrderWorkflowTest {
 private OrderWorkflow.Outcome run(OrderActivities activities){
  try(var env=TestWorkflowEnvironment.newInstance()){
   var worker=env.newWorker("test");worker.registerWorkflowImplementationTypes(OrderWorkflowImpl.class);worker.registerActivitiesImplementations(activities);env.start();
   return env.getWorkflowClient().newWorkflowStub(OrderWorkflow.class,WorkflowOptions.newBuilder().setTaskQueue("test").build()).process("<test/>","ACC1001");
  }
 }
 @Test void validatesBeforeTransforming(){
  var validated=new AtomicInteger();
  var result=run(new OrderActivities(){public void validate(String x,String a){validated.incrementAndGet();}public String transform(String x){assertEquals(1,validated.get());return "{\"id\":\"001\"}";}});
  assertEquals(200,result.status());assertTrue(result.xml().contains("<Status>SUCCESS</Status>"));
 }
 @Test void denialDoesNotRetryOrTransform(){
  var attempts=new AtomicInteger();var transforms=new AtomicInteger();
  var result=run(new OrderActivities(){public void validate(String x,String a){attempts.incrementAndGet();throw ApplicationFailure.newNonRetryableFailure("denied","ACCOUNT_DENIED");}public String transform(String x){transforms.incrementAndGet();return "{}";}});
  assertEquals(403,result.status());assertEquals(1,attempts.get());assertEquals(0,transforms.get());
 }
 @Test void transientFailureIsRetried(){
  var attempts=new AtomicInteger();
  var result=run(new OrderActivities(){public void validate(String x,String a){}public String transform(String x){if(attempts.incrementAndGet()<3)throw ApplicationFailure.newFailure("retry","UNAVAILABLE");return "{}";}});
  assertEquals(200,result.status());assertEquals(3,attempts.get());
 }
 @Test void retriesAreBounded(){
  var attempts=new AtomicInteger();
  var result=run(new OrderActivities(){public void validate(String x,String a){}public String transform(String x){attempts.incrementAndGet();throw ApplicationFailure.newFailure("retry","UNAVAILABLE");}});
  assertEquals(502,result.status());assertEquals(3,attempts.get());
 }
}
