package com.example.mismo.orchestrator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.mock.web.MockHttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;
import io.temporal.testing.TestWorkflowEnvironment;
import com.example.mismo.common.Xml;
class OrderControllerTest {
 private MockHttpServletRequest request(){var r=new MockHttpServletRequest();r.setContent(("<MESSAGE xmlns='"+Xml.MISMO_NS+"'/>").getBytes(StandardCharsets.UTF_8));return r;}
 @Test void returnsSameResultForIdenticalRetry()throws Exception{
  var transforms=new AtomicInteger();
  try(var env=TestWorkflowEnvironment.newInstance()){
   var w=env.newWorker("test");w.registerWorkflowImplementationTypes(OrderWorkflowImpl.class);
   w.registerActivitiesImplementations(new OrderActivities(){public void validate(String x,String a){}public String transform(String x){transforms.incrementAndGet();return "{}";}});
   env.start();var controller=new OrderController(env.getWorkflowClient(),"test");
   var first=controller.order("ACC1001","test-key",request());
   var second=controller.order("ACC1001","test-key",request());
   assertEquals(200,first.getStatusCode().value());assertEquals(first.getBody(),second.getBody());
   assertEquals(first.getHeaders().getFirst("X-Workflow-Id"),second.getHeaders().getFirst("X-Workflow-Id"));
   assertEquals(1,transforms.get());
  }
 }
}
