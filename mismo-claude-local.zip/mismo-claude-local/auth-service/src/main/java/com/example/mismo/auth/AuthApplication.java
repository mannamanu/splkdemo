package com.example.mismo.auth;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication(scanBasePackages="com.example.mismo")
public class AuthApplication {public static void main(String[] args){SpringApplication.run(AuthApplication.class,args);}}
