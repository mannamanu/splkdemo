package com.example.mismo.auth;
import java.io.IOException;
import java.util.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.mismo.common.*;
@RestController
public class AuthController {
 private final Set<String> accounts;
 public AuthController(@Value("${app.valid-accounts}")String accounts){this.accounts=new HashSet<>(Arrays.asList(accounts.split(",")));}
 @PostMapping(value="/internal/auth/validate",consumes="application/xml",produces="application/xml")
 public ResponseEntity<String> validate(@RequestHeader("X-Account-Id")String claimed,HttpServletRequest request)throws IOException{
  String embedded=Xml.account(Xml.parse(HttpSupport.read(request)));
  if(!embedded.equals(claimed)||!accounts.contains(embedded))return HttpSupport.reply(403,"ACCOUNT_DENIED","Account is not authorized");
  return HttpSupport.reply(200,"VALID","Account is authorized");
 }
}
