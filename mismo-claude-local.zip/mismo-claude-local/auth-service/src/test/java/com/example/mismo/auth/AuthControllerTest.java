package com.example.mismo.auth;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import static org.junit.jupiter.api.Assertions.*;
import com.example.mismo.common.Xml;
import java.nio.charset.StandardCharsets;
class AuthControllerTest {
 private MockHttpServletRequest request(String account){var r=new MockHttpServletRequest();r.setContent(("<MESSAGE xmlns='"+Xml.MISMO_NS+"' xmlns:a='"+Xml.ACCOUNT_NS+"'><a:AccountIdentifier>"+account+"</a:AccountIdentifier></MESSAGE>").getBytes(StandardCharsets.UTF_8));return r;}
 @Test void acceptsEnabledMatchingAccount()throws Exception{assertEquals(200,new AuthController("ACC1001").validate("ACC1001",request("ACC1001")).getStatusCode().value());}
 @Test void rejectsUnknownAccount()throws Exception{assertEquals(403,new AuthController("ACC1001").validate("ACC9999",request("ACC9999")).getStatusCode().value());}
 @Test void rejectsHeaderMismatch()throws Exception{assertEquals(403,new AuthController("ACC1001").validate("ACC1002",request("ACC1001")).getStatusCode().value());}
}
