# Task: Claude generates a separate implementation

Use the current project's API behavior and infrastructure as reference, but write a separate implementation under `claude-generated/`. If that path already exists, inspect it and preserve existing work. Do not overwrite the reference project.

Use Spring Boot, Java 25, Maven and Temporal. Build three services:
1. OrchestratorService accepts MISMO XML through a synchronous HTTP request, starts/reconnects to a durable workflow, waits with a bounded timeout and returns XML.
2. AuthService validates that the XML account matches an authorized account. Keep demo eligibility separate from real caller identity; clearly mark demo behavior until my actual auth contract is supplied.
3. OrderService transforms XML to JSON with namespace, repeated-element, attribute and string-value preservation.

Call auth before transformation. Put remote calls in activities. Include bounded retries, explicit timeouts, duplicate-request semantics, XML parser protections, body limits, XML error responses, health checks and meaningful tests. Clearly document generic MISMO/JSON/response mappings until real schemas are available.

Use PostgreSQL-backed Temporal with both history and visibility databases, schema initialization, namespace readiness, a separate UI and persistent Docker volumes. Include Dockerfiles/Compose and AWS hosting configuration guidance. Use an independent Compose project name and non-conflicting host ports if the reference is running. Do not add JDBC to services solely to store Temporal history; Temporal owns that connection.

Read applicable monorepo instructions first if working inside an existing repo. Build/test the generated code and validate/run Compose when Docker is available. Report executed checks accurately. Do not deploy AWS resources. Supply a README with exact setup, request examples, credentials configuration and remaining assumptions.
