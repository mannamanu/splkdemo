# Task: run and inspect the reference locally

Read CLAUDE.md, START-HERE.md, README.md, docs/POSTGRES.md and docs/VERIFICATION.md. Inspect the actual code/configuration rather than trusting the README alone.

Check Docker/Compose availability and whether ports 8080, 7233 and 8233 are already used. Preserve existing .env files and database volumes. If .env is absent, copy .env.example. Build and start the local stack. Inspect health and startup logs. Verify the PostgreSQL history/visibility schemas and run the smoke test using the configured demo client key without printing secrets. Use Git Bash/WSL for shell scripts on Windows, or run equivalent checks with PowerShell.

Fix concrete build/configuration defects you encounter and rerun affected checks. Do not change the technology stack or silently replace PostgreSQL with SQLite. Summarize the actual commands/checks that passed, failures, local endpoints, and remaining demo limitations. Do not run the disruptive persistence test unless I specifically request it.
