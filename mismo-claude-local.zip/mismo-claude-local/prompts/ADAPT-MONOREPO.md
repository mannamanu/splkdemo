# Paste at your monorepo root; replace REFERENCE_DIRECTORY with the actual path

Read this monorepo's CLAUDE.md and other applicable instructions, root pom.xml, module structure, and one representative existing Spring Boot service. Use REFERENCE_DIRECTORY as the functional reference for the MISMO Temporal/PostgreSQL project.

Create a separate implementation following the existing monorepo conventions: parent POM/dependency management, package names, modules, shared libraries, profiles, logging, testing and deployment layout. Inspect existing work and preserve unrelated changes. Do not overwrite this repository's root CLAUDE.md or replace its root POM with the reference POM. Add necessary modules/dependencies minimally. If the monorepo's Java baseline conflicts with Java 25, explain the specific conflict before changing its shared baseline.

Implement OrchestratorService, AuthService and OrderService with the synchronous XML contract, Temporal activities and PostgreSQL persistence described in the reference. Keep HTTP/database I/O outside workflow code. Include local Docker setup and tests. Use an isolated Compose project name and avoid occupied host ports. Clearly identify demo auth/MISMO mapping assumptions.

Complete the implementation, build/test it, validate/run containers when available, and summarize changed files, executed checks, exact local start commands and unresolved blockers. Do not delete database volumes or deploy anything to AWS.
