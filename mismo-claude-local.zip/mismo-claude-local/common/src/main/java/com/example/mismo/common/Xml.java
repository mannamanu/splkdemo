package com.example.mismo.common;
import java.io.*;
import java.nio.charset.StandardCharsets;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import org.xml.sax.*;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.*;

public final class Xml {
 public static final int MAX_BYTES=131072;
 public static final String MISMO_NS="http://www.mismo.org/residential/2009/schemas";
 public static final String ACCOUNT_NS="urn:example:account";
 private static final JsonMapper JSON=JsonMapper.builder().build();
 private Xml(){}
 public static Document parse(String xml) {
  if(xml==null || xml.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES) throw new IllegalArgumentException("XML exceeds 128 KiB");
  try {
   var f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);f.setXIncludeAware(false);f.setExpandEntityReferences(false);
   f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
   f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
   f.setFeature("http://xml.org/sax/features/external-general-entities",false);
   f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
   f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD,"");f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA,"");
   f.setAttribute("http://www.oracle.com/xml/jaxp/properties/maxElementDepth","100");
   var b=f.newDocumentBuilder();
   b.setErrorHandler(new org.xml.sax.helpers.DefaultHandler(){
    public void error(SAXParseException e)throws SAXException{throw e;}
    public void fatalError(SAXParseException e)throws SAXException{throw e;}
   });
   var d=b.parse(new InputSource(new StringReader(xml)));
   var root=d.getDocumentElement();
   if(!"MESSAGE".equals(root.getLocalName()) || !MISMO_NS.equals(root.getNamespaceURI())) throw new IllegalArgumentException("Expected MISMO MESSAGE root and namespace");
   return d;
  }catch(IllegalArgumentException e){throw e;}catch(Exception e){throw new IllegalArgumentException("Malformed or unsafe XML");}
 }
 public static String account(Document d){
  var nodes=d.getElementsByTagNameNS(ACCOUNT_NS,"AccountIdentifier");
  if(nodes.getLength()!=1)throw new IllegalArgumentException("Exactly one demo account identifier is required");
  var n=nodes.item(0);
  for(Node c=n.getFirstChild();c!=null;c=c.getNextSibling())if(c instanceof Element)throw new IllegalArgumentException("Account must contain text only");
  var a=n.getTextContent().trim();
  if(!a.matches("[A-Za-z0-9_-]{1,64}"))throw new IllegalArgumentException("Invalid account identifier");
  return a;
 }
 public static String toJson(Document d){
  String result=JSON.writeValueAsString(element(d.getDocumentElement()));
  if(result.getBytes(StandardCharsets.UTF_8).length>524288)throw new IllegalArgumentException("Transformed payload exceeds 512 KiB");
  return result;
 }
 private static ObjectNode element(Element e){
  var result=JSON.createObjectNode();result.put("name",e.getLocalName());result.put("namespace",e.getNamespaceURI());result.put("qualifiedName",e.getTagName());
  var attrs=result.putArray("attributes");
  for(int i=0;i<e.getAttributes().getLength();i++){
   var a=e.getAttributes().item(i);var v=attrs.addObject();v.put("name",a.getNodeName());v.put("namespace",a.getNamespaceURI());v.put("value",a.getNodeValue());
  }
  var children=result.putArray("content");
  for(Node c=e.getFirstChild();c!=null;c=c.getNextSibling()){
   if(c instanceof Element child)children.add(element(child));
   else if(c.getNodeType()==Node.TEXT_NODE || c.getNodeType()==Node.CDATA_SECTION_NODE)children.addObject().put("text",c.getNodeValue());
  }
  return result;
 }
 public static String escape(String s){return s==null?"":s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
 public static String response(String code,String message){return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><OrderResponse><Status>"+escape(code)+"</Status><Message>"+escape(message)+"</Message></OrderResponse>";}
 public static String success(String json){return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><OrderResponse><Status>SUCCESS</Status><TransformedPayload format=\"json\">"+escape(json)+"</TransformedPayload></OrderResponse>";}
}
