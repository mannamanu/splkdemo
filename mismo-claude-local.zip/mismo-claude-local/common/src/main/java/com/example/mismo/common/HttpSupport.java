package com.example.mismo.common;
import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
@RestControllerAdvice
public class HttpSupport {
 public static String read(HttpServletRequest r)throws IOException{
  byte[] bytes=r.getInputStream().readNBytes(Xml.MAX_BYTES+1);
  if(bytes.length>Xml.MAX_BYTES)throw new ResponseStatusException(HttpStatus.PAYLOAD_TOO_LARGE);
  try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();}
  catch(CharacterCodingException e){throw new IllegalArgumentException("Request must be UTF-8");}
 }
 @ExceptionHandler(IllegalArgumentException.class)
 public ResponseEntity<String> invalid(IllegalArgumentException e){return reply(400,"INVALID_XML",e.getMessage());}
 @ExceptionHandler(ResponseStatusException.class)
 public ResponseEntity<String> status(ResponseStatusException e){return reply(e.getStatusCode().value(),"REQUEST_REJECTED","Request rejected");}
 @ExceptionHandler(org.springframework.web.bind.MissingRequestHeaderException.class)
 public ResponseEntity<String> header(Exception e){return reply(400,"MISSING_HEADER","Required request header missing");}
 @ExceptionHandler(org.springframework.web.HttpMediaTypeNotSupportedException.class)
 public ResponseEntity<String> media(Exception e){return reply(415,"UNSUPPORTED_MEDIA_TYPE","Use application/xml");}
 @ExceptionHandler(Exception.class)
 public ResponseEntity<String> other(Exception e){return reply(500,"INTERNAL_ERROR","Request could not be completed");}
 public static ResponseEntity<String> reply(int status,String code,String message){return ResponseEntity.status(status).contentType(MediaType.APPLICATION_XML).body(Xml.response(code,message));}
}
