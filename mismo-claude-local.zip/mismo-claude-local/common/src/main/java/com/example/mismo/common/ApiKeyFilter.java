package com.example.mismo.common;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
@Component
public class ApiKeyFilter extends OncePerRequestFilter {
 private final byte[] key;
 public ApiKeyFilter(@Value("${app.api-key}")String key){
  if(key.length()<16)throw new IllegalArgumentException("API key must be at least 16 characters");
  this.key=key.getBytes(StandardCharsets.UTF_8);
 }
 @Override protected boolean shouldNotFilter(HttpServletRequest r){return r.getRequestURI().startsWith("/actuator/health");}
 @Override protected void doFilterInternal(HttpServletRequest r,HttpServletResponse s,FilterChain chain)throws ServletException,IOException{
  String supplied=r.getHeader("X-Api-Key");
  if(supplied==null || !MessageDigest.isEqual(key,supplied.getBytes(StandardCharsets.UTF_8))){
   s.setStatus(401);s.setContentType("application/xml");s.getWriter().write(Xml.response("UNAUTHORIZED","Invalid service credential"));return;
  }
  chain.doFilter(r,s);
 }
}
