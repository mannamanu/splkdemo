package com.example.mismo.common;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import tools.jackson.databind.json.JsonMapper;
class XmlTest {
 private String wrap(String s){return "<MESSAGE xmlns='"+Xml.MISMO_NS+"' xmlns:a='"+Xml.ACCOUNT_NS+"'>"+s+"</MESSAGE>";}
 @Test void rejectsExternalEntity(){assertThrows(IllegalArgumentException.class,()->Xml.parse("<!DOCTYPE MESSAGE [<!ENTITY x SYSTEM 'file:///etc/passwd'>]>"+wrap("&x;")));}
 @Test void rejectsMalformed(){assertThrows(IllegalArgumentException.class,()->Xml.parse("<MESSAGE>"));}
 @Test void rejectsWrongNamespace(){assertThrows(IllegalArgumentException.class,()->Xml.parse("<MESSAGE/>"));}
 @Test void rejectsOversize(){assertThrows(IllegalArgumentException.class,()->Xml.parse(wrap("x".repeat(Xml.MAX_BYTES)))) ;}
 @Test void rejectsDuplicateAccounts(){assertThrows(IllegalArgumentException.class,()->Xml.account(Xml.parse(wrap("<a:AccountIdentifier>A</a:AccountIdentifier><a:AccountIdentifier>B</a:AccountIdentifier>"))));}
 @Test void retainsOrderNamespacesAttributesAndLeadingZeros(){
  var json=JsonMapper.builder().build().readTree(Xml.toJson(Xml.parse(wrap("<LOAN id='001'>before<a:Amount>01</a:Amount>after</LOAN><LOAN id='002'/>"))));
  assertEquals(Xml.MISMO_NS,json.get("namespace").asText());
  var children=json.get("content");assertEquals(2,children.size());
  assertEquals("001",children.get(0).get("attributes").get(0).get("value").asText());
  assertEquals("before",children.get(0).get("content").get(0).get("text").asText());
  assertEquals(Xml.ACCOUNT_NS,children.get(0).get("content").get(1).get("namespace").asText());
  assertEquals("01",children.get(0).get("content").get(1).get("content").get(0).get("text").asText());
 }
 @Test void escapesResponse(){assertTrue(Xml.success("{\"x\":\"<&\"}").contains("&lt;&amp;"));}
}
