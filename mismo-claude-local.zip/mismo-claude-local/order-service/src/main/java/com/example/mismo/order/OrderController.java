package com.example.mismo.order;
import java.io.IOException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;
import com.example.mismo.common.*;
@RestController
public class OrderController {
 @PostMapping(value="/internal/orders/transform",consumes="application/xml",produces="application/json")
 public String transform(HttpServletRequest request)throws IOException{return Xml.toJson(Xml.parse(HttpSupport.read(request)));}
}
