# Architecture and extension points

One executable JAR starts embedded Tomcat (8080) and a managed Netty gRPC server
(9090). Both invoke TransformationService; no orchestration server, worker, database
or downstream service is required.

```mermaid
flowchart TD
 H[HTTP controller] --> S[TransformationService]
 G[gRPC adapter] --> S
 S --> C[Optional tenant-scoped result cache]
 S --> E[Secure JAXP engine]
 E --> A[Compiled XSD and XSLT caches]
```

Transform: authenticate -> bound input -> reserve processing slot -> optional result
cache lookup -> hardened XML parse -> input XSD validation -> XSLT transformation ->
bounded output -> output XSD validation -> bytes. Invalid results are never cached.
Validate performs input parsing/schema validation without transformation/result caching.
The GET profiles endpoint lists the server-owned profile identifier.

Schemas and Templates are immutable/thread-safe reusable artifacts. DocumentBuilder,
Validator, Transformer and DOM instances are request-local. Caffeine loads are atomic
per key. The result cache returns defensive byte-array copies. Its weight includes
output bytes plus an approximate key/entry overhead; it is not a strict JVM heap cap.
JVM/container limits and load testing are still required.

Only order-v1 is implemented. To add real MISMO/DU profiles, provide the actual XSDs
and mappings, add versioned classpath resources and replace the fixed XmlArtifacts
selection with an explicit profile registry. Never interpret profile as a file path.
Bundled XSD imports/XSLT includes are currently denied; if required, implement a
classpath-only allowlisted resolver and add tests. Do not enable broad external access.

Processing limits protect the supplied trusted, small stylesheet. Java XSLT does not
provide a safe hard thread-cancellation mechanism. A gRPC deadline cancels the RPC
but does not guarantee immediate interruption of already-running CPU work. Do not
accept user-supplied stylesheets; isolate compute if future mappings require hard
execution limits or large documents. HTTP body reads are capped even without Content-Length.
Tomcat connection/thread bounds and a shared semaphore limit accepted processing.
External gateway rate limits are an additional production control, not implemented here.

Auth: production JWT signature, issuer, audience, expiry and tenant/subject checks;
required scope xml:transform. HTTP uses Spring Security, gRPC uses the same decoder
and policy via an interceptor. Tenant comes from a verified tenant_id claim or subject,
never an untrusted request header. Local mode requires the explicit local profile.

HTTP health endpoints are unauthenticated status-only; metrics require JWT scope in
production. gRPC health Check is unauthenticated for internal ALB probes, and returns
UNAVAILABLE when Spring readiness refuses traffic (ALB checks gRPC status, not the
message body). No gRPC reflection or health Watch implementation is enabled.

AWS starter: one ECS task exposes two target groups behind one HTTPS ALB. HTTP paths
use the 8080 target group; /xml.v1.TransformationService/* uses GRPC/HTTP2 on 9090.
Route 53 aliases the ALB. TLS ends at the ALB; backend traffic is plaintext within
private subnets/security groups. End-to-end TLS/mTLS, WAF, autoscaling, alarms, audit
retention and workload sizing require platform-specific production configuration.
