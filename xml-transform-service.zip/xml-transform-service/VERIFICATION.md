# Verification

Executed 2026-10-02.

Passed:
- Maven 3.9.11 `verify` on JDK25: 31 tests, zero failures/errors/skips; executable
  Spring Boot JAR packaged. A final offline verify also passed with cached dependencies.
- Mockito tests for service/cache isolation and failure behavior, HTTP controller and
  gRPC adapter contracts; real JAXP validation/transformation and concurrent use tests.
- Prohibited DOCTYPE/external entity and excessive-depth rejection, input/output limits,
  invalid XSD input and unknown profile rejection.
- RSA-signed JWT tests for signature, issuer, audience and expiry requirements; HTTP
  and gRPC authentication/authorization integration tests on real local sockets.
- HTTP/gRPC transformation parity using the same sample XML.
- gRPC readiness tests verify nonzero status when refusing traffic, important for ALB.
- Packaged JAR started separately: HTTP liveness/readiness/Prometheus returned 200,
  transform returned expected normalized XML/no-store, invalid sample returned 422.
- XML/XSD/XSLT source syntax checked; Terraform 1.14 syntax parsing/format check passed.
- Both PowerShell helpers parsed successfully with PowerShell7.5.3 on Linux.
- ZIP integrity/source contents checked.

Not executed:
- Docker image build/Compose container execution (no Docker runtime in this environment).
  The same Maven application build was verified natively; Docker adds its own toolchain,
  base-image package installation and container-network considerations.
- Terraform provider-backed validation/plan/apply, real ECR publication, ACM/Route53/ALB
  routing, or live IdP JWKS fetching. No AWS or IdP account credentials were supplied.
- PowerShell helpers against native Windows, real grpcurl or AWS CLI.
- Load/soak tests, dependency vulnerability audit, production capacity or compliance review.

The runtime needed a temporary Maven proxy/trusted-CA configuration to download
artifacts. Those environment-specific settings are NOT packaged and certificate
verification was not disabled. Use your own approved build network configuration.

This is source for an enterprise-oriented starter, not a statement that an unconfigured
AWS deployment is production-ready. See README.md and infra/README.md before running.
