package com.example.xml.core;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.cache.CaffeineCacheMetrics;
import javax.xml.XMLConstants;
import javax.xml.transform.Templates;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
@Component
public class XmlArtifacts {
 public static final String PROFILE = "order-v1";
 private final Cache<String, Schema> schemas = Caffeine.newBuilder().maximumSize(4).recordStats().build();
 private final Cache<String, Templates> stylesheets = Caffeine.newBuilder().maximumSize(2).recordStats().build();
 public XmlArtifacts(MeterRegistry metrics) {
  CaffeineCacheMetrics.monitor(metrics, schemas, "xml.schemas");
  CaffeineCacheMetrics.monitor(metrics, stylesheets, "xml.stylesheets");
  // Fail startup if a server-owned asset cannot compile.
  input(); output(); stylesheet();
 }
 public void requireProfile(String profile) {
  if (!PROFILE.equals(profile)) throw new ServiceFailure(ServiceFailure.Code.UNKNOWN_PROFILE, "Unknown transformation profile");
 }
 public Schema input() { return schema("xml/order-input.xsd"); }
 public Schema output() { return schema("xml/order-output.xsd"); }
 private Schema schema(String path) {
  return schemas.get(path, key -> {
   try (var in = new ClassPathResource(key).getInputStream()) {
    var f = SchemaFactory.newDefaultInstance();
    f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
    f.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
    f.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
    return f.newSchema(new StreamSource(in));
   } catch (Exception e) { throw new IllegalStateException("Unable to compile bundled XSD: " + key, e); }
  });
 }
 public Templates stylesheet() {
  return stylesheets.get("xml/order-to-normalized.xsl", key -> {
   try (var in = new ClassPathResource(key).getInputStream()) {
    var f = TransformerFactory.newDefaultInstance();
    f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
    f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
    f.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
    f.setURIResolver((href, base) -> { throw new javax.xml.transform.TransformerException("External resources prohibited"); });
    return f.newTemplates(new StreamSource(in));
   } catch (Exception e) { throw new IllegalStateException("Unable to compile bundled XSLT", e); }
  });
 }
}
