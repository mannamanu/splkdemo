package com.example.xml.http;
import com.example.xml.core.ServiceFailure;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestControllerAdvice
public class ApiErrors {
 @ExceptionHandler(ServiceFailure.class)
 public ResponseEntity<ProblemDetail> failure(ServiceFailure error) {
  HttpStatus status = switch (error.code()) {
   case BAD_XML -> HttpStatus.BAD_REQUEST;
   case SCHEMA_INVALID -> HttpStatus.UNPROCESSABLE_ENTITY;
   case UNKNOWN_PROFILE -> HttpStatus.NOT_FOUND;
   case TOO_LARGE -> HttpStatus.PAYLOAD_TOO_LARGE;
   case BUSY -> HttpStatus.SERVICE_UNAVAILABLE;
   case INTERNAL -> HttpStatus.INTERNAL_SERVER_ERROR;
  };
  var body = ProblemDetail.forStatusAndDetail(status, error.getMessage());
  body.setProperty("code", error.code().name());
  var builder = ResponseEntity.status(status).cacheControl(CacheControl.noStore());
  if (error.code() == ServiceFailure.Code.BUSY) builder.header("Retry-After", "1");
  return builder.body(body);
 }
}
