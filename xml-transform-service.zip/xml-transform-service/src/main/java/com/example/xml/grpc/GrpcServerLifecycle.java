package com.example.xml.grpc;
import com.example.xml.security.TokenPolicy;
import io.grpc.Server;
import io.grpc.ServerInterceptors;
import io.grpc.netty.shaded.io.grpc.netty.NettyServerBuilder;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;
@Component
public class GrpcServerLifecycle implements SmartLifecycle {
 private final TransformationGrpcEndpoint endpoint;
 private final TokenPolicy policy;
 private final int port, maxInput;
 private final GrpcReadiness health;
 private Server server;
 private ExecutorService executor;
 public GrpcServerLifecycle(TransformationGrpcEndpoint endpoint, TokenPolicy policy, GrpcReadiness health,
   @Value("${app.grpc.port}") int port, @Value("${app.max-input-bytes}") int maxInput) {
  this.health=health; this.endpoint=endpoint; this.policy=policy; this.port=port; this.maxInput=maxInput;
 }
 public void start() {
  try {
   executor = Executors.newVirtualThreadPerTaskExecutor();
   server = NettyServerBuilder.forPort(port).executor(executor)
     .maxInboundMessageSize(maxInput + 16384).maxInboundMetadataSize(16384).maxConcurrentCallsPerConnection(32)
     .addService(ServerInterceptors.intercept(endpoint, new GrpcAuthentication(policy)))
     .addService(health).build().start();
  } catch (Exception e) { if(executor!=null) executor.shutdownNow(); throw new IllegalStateException("gRPC failed to start", e); }
 }
 public void stop() {
  if (server != null) {
   server.shutdown();
   try { if (!server.awaitTermination(20, TimeUnit.SECONDS)) server.shutdownNow(); }
   catch (InterruptedException e) { server.shutdownNow(); Thread.currentThread().interrupt(); }
  }
  if (executor != null) executor.shutdownNow();
 }
 public boolean isRunning() { return server != null && !server.isShutdown(); }
 public int boundPort() { return server.getPort(); }
 public int getPhase() { return Integer.MAX_VALUE-100; }
}
