package com.example.xml.grpc;
import com.example.xml.core.*;
import com.example.xml.proto.*;
import com.google.protobuf.ByteString;
import io.grpc.Context;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;
import org.springframework.stereotype.Component;
@Component
public class TransformationGrpcEndpoint extends TransformationServiceGrpc.TransformationServiceImplBase {
 private final TransformationService service;
 public TransformationGrpcEndpoint(TransformationService service) { this.service=service; }
 public void transform(XmlRequest request, StreamObserver<TransformReply> observer) {
  invoke(observer, () -> TransformReply.newBuilder().setProfile(request.getProfile())
    .setXml(ByteString.copyFrom(service.transform(GrpcAuthentication.TENANT.get(), request.getProfile(), request.getXml().toByteArray()))).build());
 }
 public void validate(XmlRequest request, StreamObserver<ValidateReply> observer) {
  invoke(observer, () -> { service.validate(request.getProfile(), request.getXml().toByteArray()); return ValidateReply.newBuilder().setValid(true).setProfile(request.getProfile()).build(); });
 }
 private <T> void invoke(StreamObserver<T> observer, java.util.function.Supplier<T> work) {
  if (Context.current().isCancelled()) { observer.onError(Status.CANCELLED.asRuntimeException()); return; }
  try { var response=work.get(); observer.onNext(response); observer.onCompleted(); }
  catch (ServiceFailure e) {
   Status status = switch(e.code()) {
    case BAD_XML, SCHEMA_INVALID -> Status.INVALID_ARGUMENT;
    case UNKNOWN_PROFILE -> Status.NOT_FOUND;
    case TOO_LARGE, BUSY -> Status.RESOURCE_EXHAUSTED;
    case INTERNAL -> Status.INTERNAL;
   };
   observer.onError(status.withDescription(e.getMessage()).asRuntimeException());
  } catch (Exception e) { observer.onError(Status.INTERNAL.withDescription("Request failed").asRuntimeException()); }
 }
}
