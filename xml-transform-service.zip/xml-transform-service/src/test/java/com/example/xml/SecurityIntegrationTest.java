package com.example.xml;
import com.example.xml.grpc.GrpcServerLifecycle;
import com.example.xml.proto.*;
import io.grpc.*;
import io.grpc.stub.MetadataUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.security.oauth2.jwt.*;
import java.net.URI;
import java.net.http.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,properties={"app.grpc.port=0","app.security.mode=jwt","app.security.issuer=https://issuer.example","app.security.jwk-set-uri=https://issuer.example/jwks"})
class SecurityIntegrationTest {
 @TestConfiguration static class TestTokens {
  @Bean @Primary JwtDecoder testDecoder() {
   return token -> {
    if(!token.equals("allowed") && !token.equals("no-scope")) throw new JwtException("Invalid test token");
    return Jwt.withTokenValue(token).header("alg","RS256").subject("user").claim("scope",token.equals("allowed") ? "xml:transform" : "read").build();
   };
  }
 }
 @Autowired Environment env;
 @Autowired GrpcServerLifecycle grpc;
 @Test void httpRequiresTokenAndScope() throws Exception {
  var url=URI.create("http://localhost:"+env.getProperty("local.server.port")+"/api/v1/profiles");
  var client=HttpClient.newHttpClient();
  assertEquals(401,client.send(HttpRequest.newBuilder(url).GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
  assertEquals(403,client.send(HttpRequest.newBuilder(url).header("Authorization","Bearer no-scope").GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
  assertEquals(200,client.send(HttpRequest.newBuilder(url).header("Authorization","Bearer allowed").GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
 }
 @Test void grpcRequiresTokenAndScope() {
  var channel=ManagedChannelBuilder.forAddress("localhost",grpc.boundPort()).usePlaintext().build();
  try {
   var stub=TransformationServiceGrpc.newBlockingStub(channel).withDeadlineAfter(5,java.util.concurrent.TimeUnit.SECONDS);
   assertEquals(Status.Code.UNAUTHENTICATED,assertThrows(StatusRuntimeException.class,()->stub.validate(XmlRequest.getDefaultInstance())).getStatus().getCode());
   var metadata=new Metadata();metadata.put(Metadata.Key.of("authorization",Metadata.ASCII_STRING_MARSHALLER),"Bearer no-scope");
   var forbidden=stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
   assertEquals(Status.Code.PERMISSION_DENIED,assertThrows(StatusRuntimeException.class,()->forbidden.validate(XmlRequest.getDefaultInstance())).getStatus().getCode());
  } finally {channel.shutdownNow();}
 }
}
