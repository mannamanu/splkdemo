param([Parameter(Mandatory=$true)][string]$JdkHome)
$ErrorActionPreference = 'Stop'
$java = Join-Path $JdkHome 'bin/java.exe'
$javac = Join-Path $JdkHome 'bin/javac.exe'
if (!(Test-Path $java) -or !(Test-Path $javac)) { throw 'Provide a complete JDK installation, not a JRE.' }
$version = & $java --version
if ($LASTEXITCODE -ne 0 -or ($version -join "`n") -notmatch '(?m)^(openjdk|java) 25(?:[. +]|$)') {
    throw 'The selected directory must contain JDK 25.'
}
$env:JAVA_HOME = (Resolve-Path $JdkHome).Path
$env:PATH = "$(Join-Path $env:JAVA_HOME 'bin');$env:PATH"
Write-Host "Using JDK 25 in this session: $env:JAVA_HOME"
& $java --version
