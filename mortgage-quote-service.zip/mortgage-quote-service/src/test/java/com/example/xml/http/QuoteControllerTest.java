package com.example.xml.http;
import com.example.xml.core.*;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
class QuoteControllerTest {
 @Test void rejectsOversizeMissingKeyAndUnsafeKey() throws Exception {
  var service=mock(QuoteService.class);var registry=mock(ProfileRegistry.class);
  var mvc=MockMvcBuilders.standaloneSetup(new QuoteController(service,registry,20)).setControllerAdvice(new ApiErrors()).addFilters(new CorrelationFilter()).build();
  mvc.perform(post("/api/v1/quotes/p").contentType("application/xml").header("Idempotency-Key","id").content(new byte[21])).andExpect(status().isPayloadTooLarge());
  mvc.perform(post("/api/v1/quotes/p").contentType("application/xml").content("<x/>")).andExpect(status().isBadRequest());
  mvc.perform(post("/api/v1/quotes/p").contentType("application/xml").header("Idempotency-Key","bad!").content("<x/>")).andExpect(status().isBadRequest());
  verifyNoInteractions(service);
 }
 @Test void unexpectedIsSafeAndBackendErrorsMapped() throws Exception {
  var service=mock(QuoteService.class);var registry=mock(ProfileRegistry.class);
  var mvc=MockMvcBuilders.standaloneSetup(new QuoteController(service,registry,100)).setControllerAdvice(new ApiErrors()).addFilters(new CorrelationFilter()).build();
  when(service.quote(anyString(),any(),anyString(),anyString(),anyString())).thenThrow(new IllegalStateException("private account"));
  mvc.perform(post("/api/v1/quotes/p").contentType("application/xml").header("Idempotency-Key","id").content("<x/>")).andExpect(status().isInternalServerError()).andExpect(jsonPath("$.detail").value("Request failed"));
  doThrow(new ServiceFailure(ServiceFailure.Code.BACKEND_INVALID,"secret")).when(service).quote(anyString(),any(),anyString(),anyString(),anyString());
  mvc.perform(post("/api/v1/quotes/p").contentType("application/xml").header("Idempotency-Key","id").content("<x/>")).andExpect(status().isBadGateway()).andExpect(jsonPath("$.code").value("BACKEND_INVALID"));
 }
}
