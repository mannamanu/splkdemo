package com.example.xml.core;
import com.sun.net.httpserver.HttpServer;
import java.net.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import org.springframework.mock.env.MockEnvironment;
import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class HttpQuoteBackendTest {
 final QuoteModels.BackendRequest request=new QuoteModels.BackendRequest("t","p","APP-1",BigDecimal.TEN,"USD",360);
 @Test void validatesResponsesAndBoundsBody() throws Exception {
  for(String body:new String[]{"broken","{\"applicationId\":\"wrong\"}","x".repeat(300)}) {
   var server=HttpServer.create(new InetSocketAddress("localhost",0),0);
   server.createContext("/",exchange->{byte[] bytes=body.getBytes(StandardCharsets.UTF_8);exchange.getResponseHeaders().add("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);exchange.getResponseBody().write(bytes);exchange.close();});server.start();
   try {
    var env=new MockEnvironment();env.setActiveProfiles("local");
    var backend=new HttpQuoteBackend(new ObjectMapper(),env,"http://localhost:"+server.getAddress().getPort()+"/","",1,2,200);
    assertEquals(ServiceFailure.Code.BACKEND_INVALID,assertThrows(ServiceFailure.class,()->backend.quote(request,"id","c")).code());
   }finally{server.stop(0);}
  }
 }
 @Test void unavailableAndHttpsRequired() throws Exception {
  var env=new MockEnvironment();
  assertThrows(IllegalArgumentException.class,()->new HttpQuoteBackend(new ObjectMapper(),env,"http://localhost:1/","",1,1,200));
  env.setActiveProfiles("local");
  var server=HttpServer.create(new InetSocketAddress("localhost",0),0);
  server.createContext("/",exchange->{exchange.sendResponseHeaders(500,-1);exchange.close();});server.start();
  try {
   var backend=new HttpQuoteBackend(new ObjectMapper(),env,"http://localhost:"+server.getAddress().getPort()+"/","",1,1,200);
   assertEquals(ServiceFailure.Code.BACKEND_UNAVAILABLE,assertThrows(ServiceFailure.class,()->backend.quote(request,"id","c")).code());
  }finally{server.stop(0);}
 }

 @Test void completeBodyTimeoutIsEnforced() throws Exception {
  var env=new MockEnvironment();env.setActiveProfiles("local");
  var server=HttpServer.create(new InetSocketAddress("localhost",0),0);
  server.createContext("/",exchange->{
   exchange.getResponseHeaders().add("Content-Type","application/json");exchange.sendResponseHeaders(200,100);
   try {Thread.sleep(1500);} catch(InterruptedException error){Thread.currentThread().interrupt();}
   exchange.close();
  });server.start();
  try {
   var backend=new HttpQuoteBackend(new ObjectMapper(),env,"http://localhost:"+server.getAddress().getPort()+"/","",1,1,200);
   assertEquals(ServiceFailure.Code.BACKEND_UNAVAILABLE,assertThrows(ServiceFailure.class,()->backend.quote(request,"id","c")).code());
  }finally{server.stop(0);}
 }
}
