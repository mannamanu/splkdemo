package com.example.xml.core;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
import static org.junit.jupiter.api.Assertions.*;
class QuoteServiceTest {
 @Test void cachesNormalizationButAlwaysFetchesQuoteAndScopesTenant() {
  var profiles=mock(ProfileRegistry.class);var xml=mock(QuoteXml.class);var backend=mock(QuoteBackend.class);
  var p=new ProfileRegistry.Profile("p",null,null,null,null);when(profiles.get("p")).thenReturn(p);
  var loan=new QuoteModels.Loan("APP-1",new BigDecimal("100"),"USD",360);when(xml.normalize(eq(p),any())).thenReturn(loan);
  var quote=new QuoteModels.Quote("APP-1","Q-1",BigDecimal.ONE,BigDecimal.TEN,"QUOTED");when(backend.quote(any(),anyString(),anyString())).thenReturn(quote);
  when(xml.response(eq(p),any(),eq(quote))).thenReturn("<x/>".getBytes());
  var service=new QuoteService(profiles,xml,backend,new SimpleMeterRegistry(),true,2);
  for(String tenant:new String[]{"a","a","b"})service.quote("p","input".getBytes(),tenant,"id","correlation");
  verify(xml,times(2)).normalize(eq(p),any());verify(backend,times(3)).quote(any(),anyString(),anyString());
  var keys=org.mockito.ArgumentCaptor.forClass(String.class);verify(backend,times(3)).quote(any(),keys.capture(),anyString());
  assertEquals(keys.getAllValues().get(0),keys.getAllValues().get(1));assertNotEquals(keys.getAllValues().get(0),keys.getAllValues().get(2));
 }
 @Test void mappingFailureStopsBackendAndReleasesSlot() {
  var profiles=mock(ProfileRegistry.class);var xml=mock(QuoteXml.class);var backend=mock(QuoteBackend.class);
  when(profiles.get("p")).thenThrow(new ServiceFailure(ServiceFailure.Code.UNKNOWN_PROFILE,"private"));
  var metrics=new SimpleMeterRegistry();var service=new QuoteService(profiles,xml,backend,metrics,false,1);
  for(int i=0;i<2;i++)assertEquals(ServiceFailure.Code.UNKNOWN_PROFILE,assertThrows(ServiceFailure.class,()->service.quote("p",new byte[0],"t","id","c")).code());
  verifyNoInteractions(backend);assertEquals(2,metrics.get("xml.requests.failed").counter().count());
 }
}
