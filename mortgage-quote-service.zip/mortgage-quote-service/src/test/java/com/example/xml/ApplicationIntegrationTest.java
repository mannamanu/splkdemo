package com.example.xml;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicReference;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,properties={"spring.profiles.active=local"})
class ApplicationIntegrationTest {
 static final HttpServer backend;
 static final AtomicReference<String> received=new AtomicReference<>();
 static {
  try {
   backend=HttpServer.create(new InetSocketAddress("localhost",0),0);
   backend.createContext("/quotes",exchange->{
    received.set(new String(exchange.getRequestBody().readAllBytes(),StandardCharsets.UTF_8));
    byte[] json="{\"applicationId\":\"APP-1\",\"quoteId\":\"Q-123\",\"interestRate\":6.25,\"monthlyPayment\":1539.29,\"status\":\"QUOTED\"}".getBytes(StandardCharsets.UTF_8);
    exchange.getResponseHeaders().add("Content-Type","application/json");exchange.sendResponseHeaders(200,json.length);
    exchange.getResponseBody().write(json);exchange.close();
   });backend.start();
  }catch(Exception error){throw new ExceptionInInitializerError(error);}
 }
 @DynamicPropertySource static void properties(DynamicPropertyRegistry registry) {
  registry.add("app.backend.url",()->"http://localhost:"+backend.getAddress().getPort()+"/quotes");
 }
 @AfterAll static void cleanup(){backend.stop(0);}
 @Autowired Environment env;
 final HttpClient client=HttpClient.newHttpClient();
 URI uri(String path){return URI.create("http://localhost:"+env.getProperty("local.server.port")+path);}
 @Test void allProfilesCallJsonBackendAndReturnQuoteXml() throws Exception {
  for(String profile:new String[]{"mismo-3.4-sample","mismo-3.5-sample","du-1.0-sample"}) {
   var response=client.send(HttpRequest.newBuilder(uri("/api/v1/quotes/"+profile)).header("Content-Type","application/xml")
    .header("Idempotency-Key","test-123").header("X-Correlation-ID","quote-test")
    .POST(HttpRequest.BodyPublishers.ofFile(Path.of("samples/"+profile+".xml"))).build(),HttpResponse.BodyHandlers.ofString());
   assertEquals(200,response.statusCode(),response.body());assertTrue(response.body().contains("Q-123"));assertTrue(response.body().contains("APP-1"));
   assertTrue(received.get().contains("\"loanAmount\":250000.00"));assertTrue(received.get().contains("\"profile\":\""+profile+"\""));
   assertEquals("quote-test",response.headers().firstValue("X-Correlation-ID").orElseThrow());
  }
 }
 @Test void swaggerDescribesXmlAndIdempotency() throws Exception {
  var response=client.send(HttpRequest.newBuilder(uri("/v3/api-docs")).GET().build(),HttpResponse.BodyHandlers.ofString());
  assertEquals(200,response.statusCode());assertTrue(response.body().contains("application/xml"));assertTrue(response.body().contains("Idempotency-Key"));
  assertEquals(200,client.send(HttpRequest.newBuilder(uri("/swagger-ui/index.html")).GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
 }
 @Test void healthMetricsAndUnknownProfile() throws Exception {
  for(String path:new String[]{"/actuator/health/liveness","/actuator/health/readiness","/actuator/prometheus"})
   assertEquals(200,client.send(HttpRequest.newBuilder(uri(path)).GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
  var response=client.send(HttpRequest.newBuilder(uri("/api/v1/quotes/unknown")).header("Content-Type","application/xml")
   .header("Idempotency-Key","test").POST(HttpRequest.BodyPublishers.ofString("<x/>" )).build(),HttpResponse.BodyHandlers.ofString());
  assertEquals(404,response.statusCode());assertTrue(response.body().contains("UNKNOWN_PROFILE"));
 }
}
