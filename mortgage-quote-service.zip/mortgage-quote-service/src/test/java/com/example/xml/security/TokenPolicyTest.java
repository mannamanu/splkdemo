package com.example.xml.security;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.jwt.*;
import static org.junit.jupiter.api.Assertions.*;
class TokenPolicyTest {
 @Test void tenantClaimDrivesCachePartition() {
  assertEquals("tenant-a", TokenPolicy.tenant(Jwt.withTokenValue("test").header("alg","RS256").subject("user").claim("tenant_id","tenant-a").build()));
 }
 @Test void subjectIsFallback() {
  assertEquals("user", TokenPolicy.tenant(Jwt.withTokenValue("test").header("alg","RS256").subject("user").build()));
 }
 @Test void missingIdentityRejected() {
  assertThrows(JwtException.class, () -> TokenPolicy.tenant(Jwt.withTokenValue("test").header("alg","RS256").claim("scope","xml:transform").build()));
 }
 @Test void anonymousModeRequiresExplicitLocalProfile() {
  var env=new org.springframework.mock.env.MockEnvironment();
  assertThrows(IllegalStateException.class,()->new SecurityConfiguration().jwtDecoder("none","","","aud",env));
 }
}
