package com.example.xml.core;
import java.nio.file.*;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class QuoteXmlTest {
 final ProfileRegistry registry=new ProfileRegistry("./xml-assets");final QuoteXml xml=new QuoteXml(2097152);
 @Test void profilesValidateAndRoundTripWithQuote() throws Exception {
  for(String id:registry.ids()) {
   byte[] input=Files.readAllBytes(Path.of("samples/"+id+".xml"));var p=registry.get(id);
   var loan=xml.normalize(p,input);assertEquals("APP-1",loan.applicationId());assertEquals(360,loan.termMonths());
   byte[] output=xml.response(p,input,new QuoteModels.Quote("APP-1","Q-1",new BigDecimal("6.25"),new BigDecimal("1000.00"),"QUOTED"));
   assertTrue(new String(output,java.nio.charset.StandardCharsets.UTF_8).contains("Q-1"));
  }
 }
 @Test void malformedAndEntitiesRejected() {
  for(String input:new String[]{"broken","<!DOCTYPE x [<!ENTITY a SYSTEM 'file:///etc/passwd'>]><x>&a;</x>"})
   assertEquals(ServiceFailure.Code.BAD_XML,assertThrows(ServiceFailure.class,()->xml.normalize(registry.get("du-1.0-sample"),input.getBytes())).code());
 }
 @Test void wrongVersionAndNegativeAmountRejected() throws Exception {
  String sample=Files.readString(Path.of("samples/mismo-3.4-sample.xml"));
  for(String invalid:new String[]{sample.replace("3.4", "3.5"),sample.replace("250000.00","-1.00")})
   assertEquals(ServiceFailure.Code.SCHEMA_INVALID,assertThrows(ServiceFailure.class,()->xml.normalize(registry.get("mismo-3.4-sample"),invalid.getBytes())).code());
 }
 @Test void unknownAndMissingAssetsFail() {
  assertThrows(ServiceFailure.class,()->registry.get("../secret"));assertThrows(IllegalStateException.class,()->new ProfileRegistry("missing-assets"));
 }
 @Test void depthAndOutputLimit() {
  String input="<x>".repeat(150)+"</x>".repeat(150);
  assertThrows(ServiceFailure.class,()->SecureXml.parse(input.getBytes()));
  var out=new QuoteXml.LimitedOutput(2);out.write(1);assertThrows(IllegalStateException.class,()->out.write(new byte[3],0,3));
 }
}
