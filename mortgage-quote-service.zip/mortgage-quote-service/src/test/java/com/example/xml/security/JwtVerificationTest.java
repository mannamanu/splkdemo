package com.example.xml.security;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.*;
import java.security.*;
import java.security.interfaces.*;
import java.time.Instant;
import java.util.Date;
import org.junit.jupiter.api.Test;
import org.springframework.security.oauth2.jwt.*;
import static org.junit.jupiter.api.Assertions.*;
class JwtVerificationTest {
 @Test void signatureIssuerAudienceAndExpiryAreChecked() throws Exception {
  var generator=KeyPairGenerator.getInstance("RSA");generator.initialize(2048);var pair=generator.generateKeyPair();
  var decoder=NimbusJwtDecoder.withPublicKey((RSAPublicKey)pair.getPublic()).build();
  decoder.setJwtValidator(SecurityConfiguration.validators("https://issuer.example", "xml-transform-api"));
  String valid=token(pair,"https://issuer.example","xml-transform-api",Instant.now().plusSeconds(300));
  assertEquals("tenant-a",TokenPolicy.tenant(decoder.decode(valid)));
  assertThrows(JwtException.class,()->decoder.decode(token(pair,"https://wrong.example","xml-transform-api",Instant.now().plusSeconds(300))));
  assertThrows(JwtException.class,()->decoder.decode(token(pair,"https://issuer.example","wrong",Instant.now().plusSeconds(300))));
  assertThrows(JwtException.class,()->decoder.decode(token(pair,"https://issuer.example","xml-transform-api",Instant.now().minusSeconds(300))));
  assertThrows(JwtException.class,()->decoder.decode(token(pair,"https://issuer.example","xml-transform-api",null)));
  var other=generator.generateKeyPair();
  assertThrows(JwtException.class,()->decoder.decode(token(other,"https://issuer.example","xml-transform-api",Instant.now().plusSeconds(300))));
 }
 private String token(KeyPair pair,String issuer,String audience,Instant expires) throws Exception {
  var claims=new JWTClaimsSet.Builder().issuer(issuer).audience(audience).subject("user").claim("tenant_id","tenant-a").claim("scope","xml:transform");
  if(expires!=null) claims.expirationTime(Date.from(expires));
  var signed=new SignedJWT(new JWSHeader(JWSAlgorithm.RS256),claims.build());
  signed.sign(new RSASSASigner((RSAPrivateKey)pair.getPrivate()));return signed.serialize();
 }
}
