package com.example.xml.core;

import java.nio.file.*;
import java.util.*;
import javax.xml.XMLConstants;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ProfileRegistry {
 public record Profile(String id, Schema input, Schema output, Templates request, Templates response) {}
 private final Map<String, Profile> profiles;
 public ProfileRegistry(@Value("${app.xml-assets-dir}") String directory) {
  try {
   Path root=Path.of(directory).toRealPath();
   var loaded=new LinkedHashMap<String, Profile>();
   for(String id: List.of("mismo-3.4-sample", "mismo-3.5-sample", "du-1.0-sample")) {
    loaded.put(id, new Profile(id, schema(asset(root,id,"input.xsd")), schema(asset(root,id,"output.xsd")),
      templates(asset(root,id,"request.xsl")), templates(asset(root,id,"response.xsl"))));
   }
   profiles=Collections.unmodifiableMap(loaded);
  } catch(Exception error) { throw new IllegalStateException("Unable to compile configured XML profiles", error); }
 }
 private static Path asset(Path root,String id,String file) throws Exception {
  Path path=root.resolve(id).resolve(file).toRealPath();
  if(!path.startsWith(root)) throw new IllegalStateException("Asset outside configured directory");
  return path;
 }
 private static Schema schema(Path path) throws Exception {
  var factory=SchemaFactory.newDefaultInstance();
  factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
  factory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, ""); factory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
  try(var in=Files.newInputStream(path)) { return factory.newSchema(new StreamSource(in)); }
 }
 private static Templates templates(Path path) throws Exception {
  var factory=TransformerFactory.newDefaultInstance(); factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
  factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
  factory.setURIResolver((href,base)->{throw new TransformerException("External resource denied");});
  try(var in=Files.newInputStream(path)) { return factory.newTemplates(new StreamSource(in)); }
 }
 public Set<String> ids() { return profiles.keySet(); }
 public Profile get(String id) {
  var profile=profiles.get(id);
  if(profile==null) throw new ServiceFailure(ServiceFailure.Code.UNKNOWN_PROFILE,"Unknown profile");
  return profile;
 }
}
