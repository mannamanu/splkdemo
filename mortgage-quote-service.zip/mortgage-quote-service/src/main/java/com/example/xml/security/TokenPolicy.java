package com.example.xml.security;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtException;
public class TokenPolicy {
 public static final String SCOPE = "xml:transform";
 private final boolean local;
 public TokenPolicy(boolean local) { this.local = local; }
 public boolean local() { return local; }
 public static String tenant(Jwt jwt) {
  String tenant = jwt.getClaimAsString("tenant_id");
  String key = tenant != null && !tenant.isBlank() ? tenant : jwt.getSubject();
  if (key == null || key.isBlank() || key.length() > 256) throw new JwtException("Tenant or subject required");
  return key;
 }
}
