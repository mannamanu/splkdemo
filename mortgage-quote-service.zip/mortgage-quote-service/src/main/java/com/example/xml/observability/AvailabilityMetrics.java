package com.example.xml.observability;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.availability.*;
import org.springframework.stereotype.Component;

/** Numeric application states for scraping; not a synthetic end-to-end health check. */
@Component
public class AvailabilityMetrics {
 public AvailabilityMetrics(ApplicationAvailability availability, MeterRegistry registry) {
  Gauge.builder("xml.application.ready", availability,
    a -> a.getReadinessState() == ReadinessState.ACCEPTING_TRAFFIC ? 1 : 0)
    .description("1 while Spring accepts traffic; 0 otherwise").register(registry);
  Gauge.builder("xml.application.live", availability,
    a -> a.getLivenessState() == LivenessState.CORRECT ? 1 : 0)
    .description("1 while Spring liveness is correct; 0 otherwise").register(registry);
 }
}
