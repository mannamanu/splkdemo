package com.example.xml.core;
import java.math.BigDecimal;
public final class QuoteModels {
 private QuoteModels() {}
 public record Loan(String applicationId, BigDecimal loanAmount, String currency, int termMonths) {}
 public record BackendRequest(String tenant, String profile, String applicationId, BigDecimal loanAmount, String currency, int termMonths) {}
 public record Quote(String applicationId, String quoteId, BigDecimal interestRate, BigDecimal monthlyPayment, String status) {}
}
