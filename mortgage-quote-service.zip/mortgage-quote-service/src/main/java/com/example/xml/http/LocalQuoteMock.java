package com.example.xml.http;
import com.example.xml.core.QuoteModels;
import java.math.*;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.*;

/** Local-only demonstration backend. Not underwriting or mortgage pricing logic. */
@RestController
@Profile("local")
public class LocalQuoteMock {
 @PostMapping("/mock/quotes")
 public QuoteModels.Quote quote(@RequestBody QuoteModels.BackendRequest request,
   @RequestHeader("Idempotency-Key") String key) {
  BigDecimal payment=request.loanAmount().divide(BigDecimal.valueOf(request.termMonths()),2,RoundingMode.HALF_UP);
  return new QuoteModels.Quote(request.applicationId(),"DEMO-"+key.substring(0,16),new BigDecimal("6.25"),payment,"QUOTED");
 }
}
