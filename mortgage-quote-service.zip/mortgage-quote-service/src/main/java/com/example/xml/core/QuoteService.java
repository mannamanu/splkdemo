package com.example.xml.core;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.concurrent.Semaphore;
import java.time.Duration;
import java.nio.charset.StandardCharsets;
import com.github.benmanes.caffeine.cache.*;
import io.micrometer.core.instrument.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class QuoteService {
 private record Key(String tenant,String profile,String digest) {}
 private final ProfileRegistry profiles;
 private final QuoteXml xml;
 private final QuoteBackend backend;
 private final MeterRegistry metrics;
 private final Semaphore slots;
 private final boolean enabled;
 private final Cache<Key,QuoteModels.Loan> cache;
 public QuoteService(ProfileRegistry profiles,QuoteXml xml,QuoteBackend backend,MeterRegistry metrics,
   @Value("${app.cache.results-enabled}") boolean enabled,@Value("${app.max-concurrent-operations}") int concurrent) {
  this.profiles=profiles;this.xml=xml;this.backend=backend;this.metrics=metrics;this.enabled=enabled;
  if(concurrent<1) throw new IllegalArgumentException("Concurrency must be positive");
  slots=new Semaphore(concurrent);cache=Caffeine.newBuilder().maximumSize(256).expireAfterWrite(Duration.ofSeconds(60)).recordStats().build();
  io.micrometer.core.instrument.binder.cache.CaffeineCacheMetrics.monitor(metrics,cache,"xml.normalized");
  Gauge.builder("xml.processing.available",slots,Semaphore::availablePermits).register(metrics);
 }
 public byte[] quote(String profile,byte[] input,String tenant,String idempotency,String correlation) {
  if(!slots.tryAcquire()) {metrics.counter("xml.requests.rejected","reason","busy").increment();throw new ServiceFailure(ServiceFailure.Code.BUSY,"Busy");}
  long start=System.nanoTime();
  try {
   var selected=profiles.get(profile);var key=new Key(tenant,profile,digest(input));
   var loan=enabled ? cache.get(key,unused->xml.normalize(selected,input)) : xml.normalize(selected,input);
   var request=new QuoteModels.BackendRequest(tenant,profile,loan.applicationId(),loan.loanAmount(),loan.currency(),loan.termMonths());
   // Scope the supplied idempotency label by tenant/profile/payload; backend must enforce deduplication.
   String scoped=digest((tenant+"\0"+profile+"\0"+idempotency+"\0"+key.digest()).getBytes(StandardCharsets.UTF_8));
   var quote=backend.quote(request,scoped,correlation);
   return xml.response(selected,input,quote);
  } catch(ServiceFailure error) {metrics.counter("xml.requests.failed","code",error.code().name()).increment();throw error;}
  catch(RuntimeException error) {metrics.counter("xml.requests.failed","code","INTERNAL").increment();throw error;}
  finally {slots.release();metrics.timer("xml.operation","operation","quote").record(System.nanoTime()-start,java.util.concurrent.TimeUnit.NANOSECONDS);}
 }
 private static String digest(byte[] bytes) {
  try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}
  catch(Exception error){throw new IllegalStateException(error);}
 }
}
