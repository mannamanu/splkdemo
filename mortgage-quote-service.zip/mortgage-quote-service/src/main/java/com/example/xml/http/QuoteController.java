package com.example.xml.http;
import com.example.xml.core.*;
import com.example.xml.security.TokenPolicy;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class QuoteController {
 private final QuoteService service;
 private final ProfileRegistry profiles;
 private final int max;
 public QuoteController(QuoteService service,ProfileRegistry profiles,@Value("${app.max-input-bytes}") int max) {
  this.service=service;this.profiles=profiles;this.max=max;
 }
 @GetMapping("/profiles") public Map<String,Object> profiles(){return Map.of("profiles",profiles.ids(),"sampleContracts",true);}
 @PostMapping(value="/quotes/{profile}",consumes={"application/xml","text/xml"},produces="application/xml")
 public ResponseEntity<byte[]> quote(@PathVariable String profile,HttpServletRequest request,Authentication authentication,
   @RequestHeader("Idempotency-Key") String idempotency) throws IOException {
  if(!idempotency.matches("[A-Za-z0-9_-]{1,64}")) throw new ServiceFailure(ServiceFailure.Code.BAD_XML,"Invalid idempotency key");
  if(request.getContentLengthLong()>max) throw new ServiceFailure(ServiceFailure.Code.TOO_LARGE,"Too large");
  byte[] input=request.getInputStream().readNBytes(max+1);
  if(input.length>max) throw new ServiceFailure(ServiceFailure.Code.TOO_LARGE,"Too large");
  String tenant=authentication instanceof JwtAuthenticationToken jwt ? TokenPolicy.tenant(jwt.getToken()) : "local";
  return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).cacheControl(CacheControl.noStore())
   .body(service.quote(profile,input,tenant,idempotency,CorrelationFilter.id(request)));
 }
}
