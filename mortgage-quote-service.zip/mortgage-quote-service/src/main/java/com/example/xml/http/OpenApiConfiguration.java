package com.example.xml.http;
import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.*;
import io.swagger.v3.oas.models.media.*;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;

@Configuration
public class OpenApiConfiguration {
 @Bean OpenAPI api(@Value("${app.security.mode}") String mode) {
  var api=new OpenAPI().info(new Info().title("Mortgage quote XML API").version("1.0.0")
    .description("Sample MISMO-shaped and DU-shaped contracts; replace with approved schemas/mappings."));
  if("jwt".equals(mode)) api.components(new Components().addSecuritySchemes("bearerAuth",
    new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
    .addSecurityItem(new SecurityRequirement().addList("bearerAuth"));
  return api;
 }
 @Bean OperationCustomizer xmlBody() {
  return (operation,method)->{
   if(method.getBeanType()==QuoteController.class && method.getMethod().getName().equals("quote")) {
    operation.setSummary("Validate XML, request a JSON quote and return enriched XML");
    operation.setRequestBody(new io.swagger.v3.oas.models.parameters.RequestBody().required(true)
      .content(new Content().addMediaType("application/xml",new MediaType().schema(new StringSchema()).example(
       "<MESSAGE xmlns=\"urn:sample:mismo:3.4\" version=\"3.4\"><ApplicationId>APP-1</ApplicationId><LoanAmount>250000.00</LoanAmount><Currency>USD</Currency><TermMonths>360</TermMonths></MESSAGE>"))));
    operation.getResponses().get("200").setContent(new Content().addMediaType("application/xml",new MediaType().schema(new StringSchema())));
   }
   return operation;
  };
 }
}
