package com.example.xml.core;

import java.io.*;
import java.math.BigDecimal;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import org.springframework.stereotype.Component;

@Component
public class QuoteXml {
 private final int maxOutput;
 public QuoteXml(@org.springframework.beans.factory.annotation.Value("${app.max-output-bytes}") int maxOutput) {
  if(maxOutput<1) throw new IllegalArgumentException("Output limit must be positive");this.maxOutput=maxOutput;
 }
 public QuoteModels.Loan normalize(ProfileRegistry.Profile profile, byte[] input) {
  var document=SecureXml.parse(input);
  validate(profile.input(), document, ServiceFailure.Code.SCHEMA_INVALID);
  var canonical=SecureXml.parse(transform(profile.request(), document));
  try {
   return new QuoteModels.Loan(text(canonical,"ApplicationId"),new BigDecimal(text(canonical,"LoanAmount")),
     text(canonical,"Currency"),Integer.parseInt(text(canonical,"TermMonths")));
  } catch(RuntimeException error) { throw new ServiceFailure(ServiceFailure.Code.INTERNAL,"Invalid request mapping"); }
 }
 public byte[] response(ProfileRegistry.Profile profile, byte[] original, QuoteModels.Quote quote) {
  var input=SecureXml.parse(original);
  try {
   var envelope=input.getImplementation().createDocument(null,"Envelope",null);
   var holder=envelope.createElement("Original"); envelope.getDocumentElement().appendChild(holder);
   holder.appendChild(envelope.importNode(input.getDocumentElement(),true));
   var result=envelope.createElement("Quote"); envelope.getDocumentElement().appendChild(result);
   element(envelope,result,"ApplicationId",quote.applicationId());element(envelope,result,"QuoteId",quote.quoteId());
   element(envelope,result,"InterestRate",quote.interestRate().toPlainString());
   element(envelope,result,"MonthlyPayment",quote.monthlyPayment().toPlainString());element(envelope,result,"Status",quote.status());
   byte[] output=transform(profile.response(),envelope);
   validate(profile.output(),SecureXml.parse(output),ServiceFailure.Code.INTERNAL); return output;
  } catch(ServiceFailure error) { throw error; }
  catch(Exception error) { throw new ServiceFailure(ServiceFailure.Code.INTERNAL,"Response mapping failed"); }
 }
 private static void element(Document doc,Element parent,String name,String value) {
  var node=doc.createElement(name);node.setTextContent(value);parent.appendChild(node);
 }
 private static String text(Document doc,String name) { return doc.getElementsByTagName(name).item(0).getTextContent(); }
 private static void validate(javax.xml.validation.Schema schema,Document document,ServiceFailure.Code code) {
  try { var validator=schema.newValidator();validator.setProperty(javax.xml.XMLConstants.ACCESS_EXTERNAL_DTD,"");
   validator.setProperty(javax.xml.XMLConstants.ACCESS_EXTERNAL_SCHEMA,"");validator.validate(new DOMSource(document));
  } catch(Exception error) { throw new ServiceFailure(code,"XML schema validation failed"); }
 }
 private byte[] transform(javax.xml.transform.Templates templates,Document document) {
  try {
   var out=new LimitedOutput(maxOutput); templates.newTransformer().transform(new DOMSource(document),new StreamResult(out));return out.toByteArray();
  } catch(Exception error) { throw new ServiceFailure(ServiceFailure.Code.INTERNAL,"XML transformation failed"); }
 }
 static class LimitedOutput extends ByteArrayOutputStream {
  private final int max;
  LimitedOutput(int max) { this.max=max; }
  @Override public synchronized void write(int value) { check(1);super.write(value); }
  @Override public synchronized void write(byte[] bytes,int offset,int length) { check(length);super.write(bytes,offset,length); }
  private void check(int length) { if(count+length>max) throw new IllegalStateException("Output limit exceeded"); }
 }
}
