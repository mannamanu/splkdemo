package com.example.xml.core;

/** Public messages are allowlisted: exception messages never become API responses. */
public final class ErrorCatalog {
 private ErrorCatalog() {}
 public static String message(String code) {
  return switch (code) {
   case "BAD_XML" -> "Malformed or prohibited XML";
   case "SCHEMA_INVALID" -> "XML does not match the input schema";
   case "UNKNOWN_PROFILE" -> "Unknown transformation profile";
   case "TOO_LARGE" -> "Request exceeds the size limit";
   case "BACKEND_UNAVAILABLE" -> "Quote backend is unavailable";
   case "BACKEND_INVALID" -> "Quote backend returned an invalid response";
   case "BUSY" -> "Processing capacity is temporarily exhausted";
   case "UNAUTHENTICATED" -> "Authentication is required";
   case "PERMISSION_DENIED" -> "Insufficient permissions";
   case "BAD_REQUEST" -> "Invalid request";
   case "NOT_FOUND" -> "Resource not found";
   case "METHOD_NOT_ALLOWED" -> "HTTP method is not supported";
   case "NOT_ACCEPTABLE" -> "Requested response format is not supported";
   case "UNSUPPORTED_MEDIA_TYPE" -> "Request content type is not supported";
   case "UNAVAILABLE" -> "Service is temporarily unavailable";
   default -> "Request failed";
  };
 }
 public static int httpStatus(ServiceFailure.Code code) {
  return switch (code) {
   case BAD_XML -> 400; case SCHEMA_INVALID -> 422; case UNKNOWN_PROFILE -> 404;
   case TOO_LARGE -> 413; case BUSY -> 503; case BACKEND_UNAVAILABLE -> 503; case BACKEND_INVALID -> 502; case INTERNAL -> 500;
  };
 }
 public static String httpCode(int status) {
  return switch (status) {
   case 400 -> "BAD_REQUEST"; case 401 -> "UNAUTHENTICATED"; case 403 -> "PERMISSION_DENIED";
   case 404 -> "NOT_FOUND"; case 405 -> "METHOD_NOT_ALLOWED"; case 406 -> "NOT_ACCEPTABLE";
   case 413 -> "TOO_LARGE"; case 415 -> "UNSUPPORTED_MEDIA_TYPE"; case 503 -> "UNAVAILABLE";
   default -> status >= 500 ? "INTERNAL" : "BAD_REQUEST";
  };
 }
}
