package com.example.xml.core;
public interface QuoteBackend {
 QuoteModels.Quote quote(QuoteModels.BackendRequest request,String idempotencyKey,String correlationId);
}
