package com.example.xml.core;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import tools.jackson.databind.ObjectMapper;

@Component
public class HttpQuoteBackend implements QuoteBackend {
 private final HttpClient client;
 private final ObjectMapper mapper;
 private final URI uri;
 private final String token;
 private final Duration timeout;
 private final int max;
 public HttpQuoteBackend(ObjectMapper mapper,Environment environment,
   @Value("${app.backend.url}") String url,@Value("${app.backend.token}") String token,
   @Value("${app.backend.connect-timeout-seconds}") int connect,
   @Value("${app.backend.timeout-seconds}") int seconds,@Value("${app.backend.max-response-bytes}") int max) {
  this.mapper=mapper;this.uri=URI.create(url);this.token=token;this.max=max;this.timeout=Duration.ofSeconds(seconds);
  boolean local=java.util.Arrays.asList(environment.getActiveProfiles()).contains("local");
  if(uri.getHost()==null || uri.getUserInfo()!=null || uri.getFragment()!=null ||
    !("https".equals(uri.getScheme()) || local && "http".equals(uri.getScheme())))
    throw new IllegalArgumentException("Backend URL must be HTTPS outside local mode");
  if(connect<1 || seconds<1 || max<1) throw new IllegalArgumentException("Backend limits must be positive");
  client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(connect)).followRedirects(HttpClient.Redirect.NEVER).build();
 }
 public QuoteModels.Quote quote(QuoteModels.BackendRequest request,String key,String correlation) {
  try {
   var builder=HttpRequest.newBuilder(uri).timeout(timeout).header("Content-Type","application/json")
     .header("Accept","application/json").header("Idempotency-Key",key).header("X-Correlation-ID",correlation)
     .POST(HttpRequest.BodyPublishers.ofByteArray(mapper.writeValueAsBytes(request)));
   if(!token.isBlank()) builder.header("Authorization","Bearer "+token);
   var future=client.sendAsync(builder.build(),info->new BoundedBody(max));
   HttpResponse<byte[]> response;
   try { response=future.get(timeout.toMillis(),java.util.concurrent.TimeUnit.MILLISECONDS); }
   finally { if(!future.isDone()) future.cancel(true); }
   {
    if(response.statusCode()!=200) throw new ServiceFailure(ServiceFailure.Code.BACKEND_UNAVAILABLE,"Backend failed");
    if(!response.headers().firstValue("Content-Type").orElse("").toLowerCase(java.util.Locale.ROOT).startsWith("application/json"))
      throw invalid();
    byte[] bytes=response.body();
    QuoteModels.Quote quote;
    try { quote=mapper.readValue(bytes,QuoteModels.Quote.class); } catch(Exception error) { throw invalid(); }
    if(quote==null || !request.applicationId().equals(quote.applicationId()) || quote.quoteId()==null ||
      !quote.quoteId().matches("[A-Za-z0-9_-]{1,64}") || quote.interestRate()==null || quote.monthlyPayment()==null ||
      quote.interestRate().compareTo(BigDecimal.ZERO)<0 || quote.interestRate().compareTo(new BigDecimal("100"))>0 ||
      quote.monthlyPayment().compareTo(BigDecimal.ZERO)<0 || quote.monthlyPayment().precision()>14 ||
      quote.monthlyPayment().scale()>2 || !"QUOTED".equals(quote.status())) throw invalid();
    return quote;
   }
  } catch(ServiceFailure error) { throw error; }
  catch(java.util.concurrent.ExecutionException error) {
   if(error.getCause() instanceof ServiceFailure failure) throw failure;
   throw new ServiceFailure(ServiceFailure.Code.BACKEND_UNAVAILABLE,"Backend unavailable");
  }
  catch(InterruptedException error) { Thread.currentThread().interrupt();throw new ServiceFailure(ServiceFailure.Code.BACKEND_UNAVAILABLE,"Backend interrupted"); }
  catch(Exception error) { throw new ServiceFailure(ServiceFailure.Code.BACKEND_UNAVAILABLE,"Backend unavailable"); }
 }
 static final class BoundedBody implements HttpResponse.BodySubscriber<byte[]> {
  private final int max;
  private final java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
  private final java.util.concurrent.CompletableFuture<byte[]> body=new java.util.concurrent.CompletableFuture<>();
  private java.util.concurrent.Flow.Subscription subscription;
  BoundedBody(int max){this.max=max;}
  public java.util.concurrent.CompletionStage<byte[]> getBody(){return body;}
  public void onSubscribe(java.util.concurrent.Flow.Subscription value){subscription=value;value.request(1);}
  public void onNext(java.util.List<java.nio.ByteBuffer> buffers){
   for(var buffer:buffers){
    if(buffer.remaining()>max-out.size()){subscription.cancel();body.completeExceptionally(invalid());return;}
    byte[] bytes=new byte[buffer.remaining()];buffer.get(bytes);out.writeBytes(bytes);
   }
   subscription.request(1);
  }
  public void onError(Throwable error){body.completeExceptionally(error);}
  public void onComplete(){body.complete(out.toByteArray());}
 }
 private static ServiceFailure invalid() { return new ServiceFailure(ServiceFailure.Code.BACKEND_INVALID,"Invalid backend response"); }
}
