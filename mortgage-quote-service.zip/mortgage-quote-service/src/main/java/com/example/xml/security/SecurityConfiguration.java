package com.example.xml.security;
import java.util.Arrays;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.core.*;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
public class SecurityConfiguration {
 @Bean JwtDecoder jwtDecoder(@Value("${app.security.mode}") String mode,
   @Value("${app.security.issuer}") String issuer, @Value("${app.security.jwk-set-uri}") String jwks,
   @Value("${app.security.audience}") String audience, Environment env) {
  if ("none".equals(mode)) {
   if (!Arrays.asList(env.getActiveProfiles()).contains("local")) throw new IllegalStateException("Unauthenticated mode requires the explicit local profile");
   return token -> { throw new JwtException("Local mode does not decode tokens"); };
  }
  if (!"jwt".equals(mode) || !issuer.startsWith("https://") || !jwks.startsWith("https://") || audience.isBlank())
   throw new IllegalStateException("JWT mode requires HTTPS issuer/JWK URLs and an audience");
  var decoder = NimbusJwtDecoder.withJwkSetUri(jwks).build();
  decoder.setJwtValidator(validators(issuer, audience));
  return decoder;
 }
 static OAuth2TokenValidator<Jwt> validators(String issuer, String audience) {
  OAuth2TokenValidator<Jwt> audienceCheck = token -> token.getAudience() != null && token.getAudience().contains(audience)
      ? OAuth2TokenValidatorResult.success() : OAuth2TokenValidatorResult.failure(new OAuth2Error("invalid_token"));
  OAuth2TokenValidator<Jwt> subjectCheck = token -> {
   try { if (token.getExpiresAt() == null) throw new JwtException("Expiry required"); TokenPolicy.tenant(token); return OAuth2TokenValidatorResult.success(); }
   catch (JwtException e) { return OAuth2TokenValidatorResult.failure(new OAuth2Error("invalid_token")); }
  };
  return new DelegatingOAuth2TokenValidator<>(JwtValidators.createDefaultWithIssuer(issuer), audienceCheck, subjectCheck);
 }
 @Bean TokenPolicy tokenPolicy( @Value("${app.security.mode}") String mode) { return new TokenPolicy("none".equals(mode)); }
 @Bean SecurityFilterChain httpSecurity(HttpSecurity http, TokenPolicy policy, com.example.xml.http.SecurityErrors errors) throws Exception {
  http.csrf(csrf -> csrf.disable()).sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
  http.authorizeHttpRequests(auth -> {
   auth.requestMatchers("/swagger-ui.html", "/swagger-ui/**", "/v3/api-docs", "/v3/api-docs/**", "/v3/api-docs.yaml").permitAll();
   auth.requestMatchers("/actuator/health", "/actuator/health/**").permitAll();
   if (policy.local()) auth.anyRequest().permitAll();
   else auth.anyRequest().hasAuthority("SCOPE_" + TokenPolicy.SCOPE);
  });
  http.exceptionHandling(e -> e
    .authenticationEntryPoint((request, response, failure) -> errors.write(request, response, 401))
    .accessDeniedHandler((request, response, failure) -> errors.write(request, response, 403)));
  if (!policy.local()) http.oauth2ResourceServer(o -> o.jwt(j -> {})
    .authenticationEntryPoint((request, response, failure) -> errors.write(request, response, 401))
    .accessDeniedHandler((request, response, failure) -> errors.write(request, response, 403)));
  return http.build();
 }
}
