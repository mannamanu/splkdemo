# Architecture

HTTP controller -> bounded QuoteService -> ProfileRegistry/QuoteXml -> HttpQuoteBackend
-> quote enrichment -> output validation. XML/XSD/XSLT mapping lives in core; adapters
handle transport only. Incoming JWT tenant is the authority for downstream tenant/cache.

The local-only mock controller is in the same process but called over actual HTTP.
Production has no mock and requires an operator-owned HTTPS backend URL. Normalize cache
is optional and bounded; quotes are always fetched. Idempotency is enforced by the real
backend, not by an in-memory gateway cache. No automatic retries or durable workflow.

ProfileRegistry has an explicit immutable allowlist and warms schemas/Templates on startup.
External asset paths are confined to their real configured root. Imports/includes denied;
production schemas using imports need an explicit allowlisted local resolver and tests.
DOMs and mutable XML processors are per request. Backend response bytes are bounded and
validated; XML escaping uses DOM text nodes, not string concatenation of backend values.

Health metrics are lifecycle signals. Backend health is not a readiness dependency in
this starter. Rate limiting, distributed tracing, audit retention, WAF and autoscaling
need platform-specific configuration. Production MISMO/DU conformance requires the
actual authorized schema package, mapping rules and backend contract.
