# Use agents in VS Code

Open the project root. Copilot loads .github/copilot-instructions.md. Select
xml-implementation from Chat's agent picker for changes, test-engineer for coverage.
CLAUDE.md points Claude-compatible tools to AGENTS.md. If agents are not discovered,
attach AGENTS.md and the desired agent Markdown explicitly to your request.

Example: "Follow AGENTS.md. Add approved mismo-3.6 profile using attached schemas,
backend JSON and mapping. Preserve other profiles/security. Implement/tests/docs;
run mvn verify and report JaCoCo coverage. No deployment."

For bugs attach sanitized request, actual/expected response, failing test and affected
files. Ask the agent to reproduce before fixing. Review Source Control diffs and test
output before committing. Use synthetic/redacted XML, never borrower data or tokens.
