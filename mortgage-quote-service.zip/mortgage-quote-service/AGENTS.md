# Coding instructions

One Spring Boot4/Maven/JDK25 HTTP quote gateway. Read README and docs/ARCHITECTURE.md
before editing. Preserve unrelated changes. No Temporal/gRPC/database without a request.
Keep business/XML/backend mapping in core and transport mapping in http.

Profiles in xml-assets are synthetic examples, not certified MISMO/DU definitions.
Do not invent production schemas, business fields, quote rules or version labels.
Ask for approved input/output XSD, field mapping, backend JSON and synthetic fixtures.

Preserve XXE/DOCTYPE/depth/size/concurrency restrictions, JWT signature/issuer/audience/
expiry/scope/tenant checks, no-store and safe errors. Never log XML, tokens or exception
messages containing document data. No arbitrary schema/style/path/URL from requests.
Reuse Schema/Templates only; create mutable XML objects per request. Backend deadlines,
bounded response reading, identity matching and HTTPS requirements must remain.
Cache normalization only, never backend quotes. Idempotency requires backend deduplication.

Run mvn -B -ntp verify on JDK25. Add useful Mockito and real XML/HTTP failure tests.
Do not weaken tests to pass. Review target/site/jacoco reports. Update samples/Swagger/docs
with contract changes. Do not edit target/generated code or deploy/push images unless asked.
