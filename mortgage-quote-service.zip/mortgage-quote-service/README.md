# Mortgage quote XML service

Runnable Spring Boot 4.0.8 / Maven / JDK25 HTTP service. Docker uses Amazon Corretto25.
No Temporal, gRPC or database. A local-only mock backend makes the entire flow runnable.

## Contract scope — read first

The three bundled profiles are **synthetic examples**, not official MISMO or Fannie Mae
DU schemas. Their namespaces intentionally begin with `urn:sample:`. They demonstrate
version isolation and round-trip quote enrichment. They do not accept arbitrary real
MISMO/DU submissions. DU may refer to a specific submission/export interface and release;
you must provide the actual format/version, authorized XSDs, field mapping and backend
contract before production compatibility can be implemented and verified.

| Profile | Example root | Version |
|---|---|---|
| mismo-3.4-sample | MESSAGE | 3.4 |
| mismo-3.5-sample | MESSAGE | 3.5 |
| du-1.0-sample | DU_REQUEST | 1.0 |

Each directory in xml-assets contains input.xsd, output.xsd, request.xsl and response.xsl.
Schemas/XSLTs are compiled once at startup. Missing/invalid assets prevent startup.
Request paths are allowlisted profile IDs, never filesystem paths. Version/root/namespace
mismatches fail validation. Profiles are explicit in the URL; automatic detection is not
implemented. Replace/add approved profile assets and register the profile in ProfileRegistry.

## Flow

1. Authenticate and bound the raw XML body.
2. Select the versioned profile and validate input XSD.
3. Request XSLT maps source XML to canonical Loan XML.
4. Java converts canonical fields to a typed JSON backend request.
5. HTTP POST JSON to the configured quote backend with a scoped Idempotency-Key.
6. Validate the backend response and application identity.
7. Response XSLT copies the approved original fields and appends returned Quote details.
8. Validate output XSD and return XML, with no-store and correlation headers.

The sample output preserves all fields allowed by the sample schema. Real MISMO extension
fields, nested structures and quote placement need explicit production schemas/mappings;
this is not a generic lossless converter for arbitrary XML. Error responses are JSON
ProblemDetail even when successful responses are XML.

## Prerequisites and obtain source

Extract the ZIP and open mortgage-quote-service (the folder containing pom.xml).
If you publish it in Git, use your real repository URL:

```bash
git clone https://github.com/YOUR-ORG/mortgage-quote-service.git
cd mortgage-quote-service
```

For Docker: Docker Desktop using Linux containers or Docker Engine + Compose v2.
No host JDK/Maven needed. For native execution: Amazon Corretto JDK25 and Maven3.9.11+.
Verify `java --version`, `javac --version`, and `mvn --version` report Java25.
Downloads require Maven Central/container registry access through your approved network.

JDK21 can remain installed. On Windows, install Corretto25 then select it for the session:

```powershell
. .\scripts\Use-Jdk25.ps1 -JdkHome 'C:\Program Files\Amazon Corretto\YOUR-JDK25-DIRECTORY'
mvn --version
```

The leading dot makes the selection persist in the current PowerShell session. Set your
IDE project/Maven runner JDK to25 as well. This helper selects an installed JDK; it does
not download or uninstall Java.

## Run with Docker

```bash
docker compose up --build -d
docker compose logs -f --tail=100
```

One application container on http://localhost:8080. The local profile includes a mock
JSON quote backend at /mock/quotes; the application actually calls it over HTTP.
The mock's payment is principal divided by term, **not mortgage pricing or underwriting**.
It returns synthetic quote IDs/rates. It is absent outside the local profile.

```bash
docker compose down
```

Compose mounts ./xml-assets read-only at /opt/xml-assets. Parent-folder assets can use
source ../xml-assets with the same target. Runtime user10001 must be able to read them.
Restart after asset changes; there is no hot reload. AWS uses the image's asset snapshot.

## Run natively

From project root:

```bash
mvn -B -ntp verify
java -jar target/app.jar --spring.profiles.active=local
```

The default local backend URL is http://localhost:8080/mock/quotes. If changing SERVER_PORT,
the local URL uses that configured server port. To use a real development backend,
provide `--app.backend.url=https://your-backend/quotes` explicitly (the local profile
otherwise supplies the mock URL). Stop with Ctrl+C for graceful shutdown.

## Swagger and sample requests

Open http://localhost:8080/swagger-ui/index.html. OpenAPI JSON: /v3/api-docs.
The OperationCustomizer documents XML bodies centrally; no repeated body annotations.
Select POST /api/v1/quotes/{profile}, enter a sample profile and Idempotency-Key,
then paste that profile's samples/*.xml. Swagger example text is for mismo-3.4-sample;
change the XML when selecting another profile.

Bash:

```bash
curl -i http://localhost:8080/api/v1/profiles
curl -i -X POST http://localhost:8080/api/v1/quotes/mismo-3.4-sample \
  -H 'Content-Type: application/xml' -H 'Accept: application/xml' \
  -H 'Idempotency-Key: order-1001' -H 'X-Correlation-ID: demo-123' \
  --data-binary @samples/mismo-3.4-sample.xml
```

PowerShell:

```powershell
curl.exe -i -X POST http://localhost:8080/api/v1/quotes/du-1.0-sample `
  -H "Content-Type: application/xml" -H "Accept: application/xml" `
  -H "Idempotency-Key: order-1001" --data-binary "@samples/du-1.0-sample.xml"
```

See samples/requests.http and samples/expected-response.xml.
A sample backend JSON request:

```json
{"tenant":"local","profile":"mismo-3.4-sample","applicationId":"APP-1",
 "loanAmount":250000.00,"currency":"USD","termMonths":360}
```

Required backend response (HTTP200, application/json):

```json
{"applicationId":"APP-1","quoteId":"Q-123","interestRate":6.25,
 "monthlyPayment":1539.29,"status":"QUOTED"}
```

Backend identity must match the request. Rate is a percent; payment is a decimal amount.
The response is checked before XML generation. Strict output XSD validation is the last gate.

## Authentication, backend and production

Outside local mode provide:

```dotenv
JWT_ISSUER=https://your-idp/issuer
JWT_JWK_SET_URI=https://your-idp/.well-known/jwks.json
JWT_AUDIENCE=xml-transform-api
QUOTE_BACKEND_URL=https://your-backend/quotes
QUOTE_BACKEND_TOKEN=your-service-access-token
```

JWTs must have verified issuer/audience/signature/expiry, tenant_id or subject, and scope
xml:transform. Pass inbound tokens as Authorization: Bearer TOKEN. Inbound credentials
are not forwarded downstream. The backend token is a separate operator-configured
credential; no token refresh implementation is included. Inject it securely and arrange
rotation/redeployment, or implement an approved OAuth client-credentials provider.
Native Java does not automatically load .env files. Do not deploy the local profile.

Backend URLs are configured by operators, require HTTPS outside local mode, and redirects
are disabled. Connect timeout3sec; complete response timeout10sec; response limit64KiB.
No automatic POST retries. Idempotency-Key is required (1–64 letters/digits/_/-).
The backend receives a SHA256 key scoped by tenant/profile/input/client label and must
enforce deduplication. This service has no durable idempotency store. A timed-out request
may already have committed in the backend; retry only with the same label and payload.

Swagger is disabled by default in production. To enable in an approved environment set
springdoc.api-docs.enabled=true and springdoc.swagger-ui.enabled=true. Documentation routes
are public when enabled; API requests still require JWT. Use Authorize with a valid JWT.
There is no OAuth login or identity-provider provisioning in this starter.

## Health, metrics, cache and limits

| Endpoint | Production access |
|---|---|
| /actuator/health | Public status-only |
| /actuator/health/liveness | Public status-only; Docker/ECS probe |
| /actuator/health/readiness | Public status-only; ALB routing probe |
| /actuator/metrics | JWT + scope |
| /actuator/prometheus | JWT + scope |

```bash
curl http://localhost:8080/actuator/health/readiness
curl http://localhost:8080/actuator/prometheus
```

Readiness reflects Spring lifecycle; backend availability is not polled. Backend errors
are reported per request. Do not put remote dependency outages into liveness checks.
Application ready/live gauges, XML processing slots, operation duration, failure/rejection
counts, HTTP latency/status and JVM metrics are exported. Histograms enabled for XML/HTTP.
Counters appear after relevant traffic. Monitoring/prometheus.yml is a local scrape example.
Use collector up/missing-series monitoring to detect a stopped process. Per-task discovery
is required in AWS; ALB load balancing does not scrape every replica.

Compiled schemas/Templates are reused. Parser/Validator/Transformer/DOM objects are
request-local. Optional normalized Loan cache is OFF by default; when enabled it stores
up to256 immutable records for60sec, partitioned by authenticated tenant/profile/input
SHA256. Set RESULT_CACHE_ENABLED=true to enable. It holds financial data in memory;
backend quotes and final XML responses are never cached. Each replica has its own cache.

Input1MiB, output2MiB, XML depth128, concurrent work8. No uploaded schemas/stylesheets.
DOCTYPE/entities/XInclude/network imports/XSLT document() are disabled. Trusted XSLT is
required: Java transformation has no safe hard CPU cancellation; a timeout does not
promise cancellation of already-running server work. Gateway rate limits/load testing
are separate deployment responsibilities.

| Error | HTTP |
|---|---:|
| Malformed/prohibited XML or invalid idempotency label |400|
| Input schema violation |422|
| Unknown profile |404|
| Too large |413|
| Invalid backend JSON/identity |502|
| Backend unavailable or full processing slots |503|
| Unexpected mapping failure |500|

Global errors have stable code, safe detail, correlationId and no-store. Busy errors
include Retry-After. Exception messages, payloads and tokens are not logged by handlers.
Network/framing failures before application dispatch can use transport-specific formats.

## Tests and coverage

```bash
mvn -B -ntp verify
```

JUnit/Mockito, real XSD/XSLT round trips for all profiles, prohibited XML/depth/limits,
backend JSON validation/size/status tests, tenant cache isolation, error handling,
JWT validation and live HTTP backend/Swagger/health/security integration tests.
JaCoCo0.8.14 supports Java25. HTML report: target/site/jacoco/index.html; machine-readable
report: target/site/jacoco/jacoco.xml. See VERIFICATION.md for measured results. The executed HTML report is also included
at verification/jacoco/index.html.
The build enforces at least85% line and60% branch coverage across the application.
The coverage report includes application code; no claim of complete production coverage.

## AI development and AWS

Read AGENTS.md, CLAUDE.md, docs/AI-USAGE.md and .github/agents/*.agent.md. Select the
implementation agent in VS Code Copilot for mappings/features, then test-engineer for
failure scenarios. These are development instructions, not a runtime AI integration.
Attach approved schemas, backend JSON contract and synthetic XML before adding a profile.

Read infra/README.md. Terraform includes ECR, ECS/Fargate, HTTPS ALB, Route53 alias,
CloudWatch logs and security groups in an existing network. Provide existing VPC,
subnets, ACM certificate, hosted zone, IdP and real backend. Secret injection from AWS
Secrets Manager is optional. Docker and Terraform are configuration deliverables;
no resources/images were published during generation. Review plans before applying.
