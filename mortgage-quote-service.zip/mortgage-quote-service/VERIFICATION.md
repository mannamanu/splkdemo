# Verification

Executed 2026-10-03 using Amazon Corretto25.0.4 and Maven3.9.11.

- Maven verify passed: 22 tests, zero failures/errors/skips.
- JaCoCo0.8.14: 90.07% line coverage (263 covered,29 missed), 63.48% branch coverage
  (113 covered,65 missed). Build gates:85% lines and60% branches; both passed.
- Real XML input/output XSD and XSLT round trips for all three synthetic profiles.
- Live HTTP gateway -> local HTTP JSON backend -> enriched XML, profile/version checks,
  XXE/depth/output limits, tenant normalization cache isolation and scoped idempotency.
- JSON backend response validation, response byte bound, non-200 mapping and complete
  body timeout tested. Mockito service/HTTP controller failure tests retained.
- RSA JWT checks, HTTP authentication/scope checks, protected metrics, public health,
  Swagger UI/OpenAPI XML request-body documentation tested.
- Executable JAR separately started with local mock on18080. All three profile POSTs
  returned enriched XML with DEMO quote IDs; health, Prometheus, Swagger UI/OpenAPI
  returned200. Process stopped gracefully after smoke testing.
- Terraform1.14.0 fmt/check passed (HCL parsed). YAML configurations parsed.
- ZIP integrity/source/coverage-report contents checked.

Coverage HTML/XML copied to verification/jacoco for review without rebuilding.
New builds generate target/site/jacoco. Build downloads used the environment's trusted
proxy/CA settings; certificate verification remained enabled. Temporary toolchains,
proxy settings, target binaries and downloaded dependencies are not packaged.

Not executed: Docker image/Compose runtime, Terraform provider-backed validate/plan/
apply, ECR publication, live AWS/Route53/ALB/SecretsManager integration, live IdP JWKS
requests, native Windows PowerShell helpers, load/soak or vulnerability audit.

No official MISMO or Fannie Mae DU schema package was supplied. The example contracts
are synthetic; production compatibility, mappings and quote pricing are not certified.
