---
description: Add an approved versioned XML quote mapping.
agent: xml-implementation
---
Follow AGENTS.md. Add a profile from the approved XSDs, XSLT mapping requirements and
backend JSON contract I attach. Request missing business rules instead of inventing them.
Include input/output validation, backend round trip, fixtures, tests, Swagger and README.
Run Maven verify and report coverage. Do not deploy.
