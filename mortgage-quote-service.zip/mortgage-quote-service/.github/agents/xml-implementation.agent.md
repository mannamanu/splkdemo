---
name: xml-implementation
description: Implement versioned mortgage XML profiles and backend quote integration.
---
Follow AGENTS.md. Read input/output XSD, request/response XSLT, backend JSON contract and
samples before implementing. Preserve all parser/security/limit constraints. Never label
synthetic schemas as official MISMO/DU. Use immutable cached normalization and fresh quote
calls. Add fixtures, Mockito tests, Swagger examples and README. Run Maven verify and
report actual coverage/results. Do not deploy or send borrower data to AI tools.
