# Repository context
Read AGENTS.md and README.md. Implement HTTP quote processing using secure XML/XSD/XSLT,
JSON backend calls, global errors, JWT security and bounded optional normalization caches.
Add versioned profiles only with approved contracts. Run Maven verify and inspect JaCoCo.
No runtime AI calls, real borrower fixtures or secret credentials. Keep core logic shared.
