package com.example.mismo.orchestrator;
import org.junit.jupiter.api.Test;
import org.springframework.boot.health.contributor.Status;
import static org.junit.jupiter.api.Assertions.*;

class CloudHealthTest {
    @Test void successfulNamespaceCallIsUp() {
        assertEquals(Status.UP, new TemporalCloudHealthIndicator(() -> {}).health().getStatus());
    }
    @Test void failedNamespaceCallIsDownWithoutSensitiveDetails() {
        var health = new TemporalCloudHealthIndicator(() -> {throw new RuntimeException("sensitive-value");}).health();
        assertEquals(Status.DOWN, health.getStatus());
        assertTrue(health.getDetails().isEmpty());
    }
    @Test void rejectsMissingCloudCredentials() {
        assertThrows(IllegalArgumentException.class, () -> new CloudSettings("test.tmprl.cloud:7233", "test.account", ""));
        assertThrows(IllegalArgumentException.class, () -> new CloudSettings("test.tmprl.cloud:7233", "", "secret"));
    }
    @Test void rejectsUrlSchemeAndInvalidPort() {
        assertThrows(IllegalArgumentException.class, () -> new CloudSettings("https://test:7233", "ns", "secret"));
        assertThrows(IllegalArgumentException.class, () -> new CloudSettings("test:99999", "ns", "secret"));
    }
    @Test void settingsDoNotPrintTheApiKey() {
        assertFalse(new CloudSettings("test.tmprl.cloud:7233", "ns.account", "sensitive-value").toString().contains("sensitive-value"));
    }
}
