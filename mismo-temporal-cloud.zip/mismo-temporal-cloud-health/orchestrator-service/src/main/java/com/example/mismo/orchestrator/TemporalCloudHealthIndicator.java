package com.example.mismo.orchestrator;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.stereotype.Component;

@Component("temporalCloud")
public class TemporalCloudHealthIndicator implements HealthIndicator {
    private final CloudNamespaceProbe probe;
    public TemporalCloudHealthIndicator(CloudNamespaceProbe probe) { this.probe = probe; }
    @Override public Health health() {
        try {
            probe.check();
            return Health.up().build();
        } catch (Exception ignored) {
            // Do not expose credentials, endpoint, namespace or gRPC error details publicly.
            return Health.down().build();
        }
    }
}
