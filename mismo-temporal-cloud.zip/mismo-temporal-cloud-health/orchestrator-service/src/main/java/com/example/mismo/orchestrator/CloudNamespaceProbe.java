package com.example.mismo.orchestrator;
@FunctionalInterface
public interface CloudNamespaceProbe { void check(); }
