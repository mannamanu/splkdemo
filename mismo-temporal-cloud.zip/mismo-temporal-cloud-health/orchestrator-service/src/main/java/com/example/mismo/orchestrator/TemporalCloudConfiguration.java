package com.example.mismo.orchestrator;

import io.grpc.Metadata;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowClientOptions;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.serviceclient.WorkflowServiceStubsOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TemporalCloudConfiguration {
    @Bean
    CloudSettings cloudSettings(@Value("${temporal.cloud.target}") String target,
            @Value("${temporal.cloud.namespace}") String namespace,
            @Value("${temporal.cloud.api-key}") String apiKey) {
        return new CloudSettings(target, namespace, apiKey);
    }

    @Bean(destroyMethod = "shutdown")
    WorkflowServiceStubs temporalService(CloudSettings settings) {
        // Explicit namespace metadata also applies to the raw DescribeNamespace health RPC.
        Metadata headers = new Metadata();
        headers.put(Metadata.Key.of("temporal-namespace", Metadata.ASCII_STRING_MARSHALLER), settings.namespace());
        return WorkflowServiceStubs.newServiceStubs(WorkflowServiceStubsOptions.newBuilder()
                .setTarget(settings.target())
                .setEnableHttps(true)
                .setHeaders(headers)
                .addApiKey(settings::apiKey)
                .build());
    }

    @Bean
    WorkflowClient workflowClient(WorkflowServiceStubs service, CloudSettings settings) {
        return WorkflowClient.newInstance(service, WorkflowClientOptions.newBuilder()
                .setNamespace(settings.namespace()).build());
    }
}
