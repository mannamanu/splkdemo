package com.example.mismo.orchestrator;

public record CloudSettings(String target, String namespace, String apiKey) {
    public CloudSettings {
        if (target == null || !target.matches("[A-Za-z0-9][A-Za-z0-9.-]*:[0-9]{1,5}")) {
            throw new IllegalArgumentException("TEMPORAL_TARGET must be the Cloud hostname:port, without https://");
        }
        int port = Integer.parseInt(target.substring(target.lastIndexOf(':') + 1));
        if (port < 1 || port > 65535) throw new IllegalArgumentException("Invalid TEMPORAL_TARGET port");
        if (namespace == null || namespace.isBlank()) throw new IllegalArgumentException("TEMPORAL_NAMESPACE is required");
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("TEMPORAL_API_KEY is required");
    }
    @Override public String toString() { return "CloudSettings[credentials and endpoint redacted]"; }
}
