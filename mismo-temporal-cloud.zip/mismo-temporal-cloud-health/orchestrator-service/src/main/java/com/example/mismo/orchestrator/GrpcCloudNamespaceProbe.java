package com.example.mismo.orchestrator;
import io.temporal.api.workflowservice.v1.DescribeNamespaceRequest;
import io.temporal.serviceclient.WorkflowServiceStubs;
import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Component;

@Component
public class GrpcCloudNamespaceProbe implements CloudNamespaceProbe {
    private final WorkflowServiceStubs service;
    private final CloudSettings settings;
    public GrpcCloudNamespaceProbe(WorkflowServiceStubs service, CloudSettings settings) {
        this.service = service; this.settings = settings;
    }
    @Override public void check() {
        service.blockingStub().withDeadlineAfter(3, TimeUnit.SECONDS).describeNamespace(
                DescribeNamespaceRequest.newBuilder().setNamespace(settings.namespace()).build());
    }
}
