<#
.SYNOPSIS
Select an already installed JDK 25 for this PowerShell session.
.EXAMPLE
. .\scripts\Use-Jdk25.ps1 -JdkHome 'C:\Java\jdk-25'
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$JdkHome
)

# Validate everything before changing the calling process environment.
$resolvedHome = (Resolve-Path -LiteralPath $JdkHome -ErrorAction Stop).ProviderPath
$javaBin = Join-Path $resolvedHome 'bin'
$javaExe = Join-Path $javaBin 'java.exe'
$javacExe = Join-Path $javaBin 'javac.exe'
if (!(Test-Path -LiteralPath $javaExe -PathType Leaf) -or
    !(Test-Path -LiteralPath $javacExe -PathType Leaf)) {
    throw 'JdkHome must contain bin\java.exe and bin\javac.exe. Select a JDK, not a JRE.'
}
$compilerVersion = (& $javacExe -version 2>&1 | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $compilerVersion -notmatch '^javac 25(?:[.\s+\-]|$)') {
    throw "Expected JDK 25. Found: $compilerVersion"
}
$runtimeVersion = (& $javaExe --version 2>&1 | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $runtimeVersion -notmatch '^(?:openjdk|java) 25(?:[.\s+\-]|$)') {
    throw "Expected Java 25 runtime. Found: $runtimeVersion"
}

$env:JAVA_HOME = $resolvedHome
$env:PATH = $javaBin + [IO.Path]::PathSeparator + $env:PATH
Write-Host "JAVA_HOME=$env:JAVA_HOME"
Write-Host $runtimeVersion
Write-Host 'JDK 25 selected for this terminal and its child processes. Close this terminal to revert.'
Write-Host 'Run mvn -version to confirm Maven uses Java 25.'
