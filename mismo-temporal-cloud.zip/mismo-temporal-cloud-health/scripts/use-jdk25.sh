#!/usr/bin/env bash
# Source this file so the environment changes stay in your current Bash shell.
# Usage: source scripts/use-jdk25.sh /absolute/path/to/jdk-25
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    echo 'Use: source scripts/use-jdk25.sh /absolute/path/to/jdk-25' >&2
    exit 1
fi

_mismo_use_jdk25() {
    local jdk_home compiler_version runtime_version
    if [[ $# -ne 1 ]]; then
        echo 'Use: source scripts/use-jdk25.sh /absolute/path/to/jdk-25' >&2
        return 1
    fi
    jdk_home=$(cd -- "$1" 2>/dev/null && pwd -P) || {
        echo 'JDK directory does not exist.' >&2; return 1;
    }
    if [[ ! -x "$jdk_home/bin/java" || ! -x "$jdk_home/bin/javac" ]]; then
        echo 'Select a JDK containing executable bin/java and bin/javac.' >&2
        return 1
    fi
    compiler_version=$("$jdk_home/bin/javac" -version 2>&1) || return 1
    runtime_version=$("$jdk_home/bin/java" --version 2>&1) || return 1
    if [[ ! "$compiler_version" =~ ^javac\ 25([.[:space:]+-]|$) ]] ||
       [[ ! "$runtime_version" =~ ^(openjdk|java)\ 25([.[:space:]+-]|$) ]]; then
        echo "Expected JDK 25. Found: $compiler_version" >&2
        return 1
    fi
    export JAVA_HOME="$jdk_home"
    export PATH="$JAVA_HOME/bin:$PATH"
    hash -r
    printf 'JAVA_HOME=%s\n%s\n' "$JAVA_HOME" "$runtime_version"
    echo 'JDK 25 selected for this shell and its child processes. Close this shell to revert.'
    echo 'Run mvn -version to confirm Maven uses Java 25.'
}
_mismo_use_jdk25 "$@" || { unset -f _mismo_use_jdk25; return 1; }
unset -f _mismo_use_jdk25
