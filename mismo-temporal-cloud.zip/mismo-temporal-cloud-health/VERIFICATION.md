# Verification

Verified 2026-09-23.

- Full Maven reactor `verify` passed for all three services on JDK 25 (Azul Zulu 25.0.4.1) with Maven 3.9.11. All three executable JARs were packaged.
- All five tests passed: Cloud health success, dependency failure/redaction, missing credentials, invalid endpoint/port, and settings credential redaction.
- Started all three actual Spring Boot processes on JDK 25 and checked their HTTP endpoints.
- All liveness endpoints returned 200 UP. AuthService and OrderService readiness returned 200 UP.
- With a synthetic API key and deliberately unreachable endpoint, orchestrator readiness, Cloud health and overall health returned 503 DOWN. Orchestrator liveness stayed 200 UP. Responses exposed no credential/exception details; overall health lists group names.
- Parsed all YAML and Maven XML. Confirmed Compose includes only the three application services and no database/Temporal server containers or volumes.
- Checked Java 25 class-file versions and archive integrity.

Not verified: a successful real Temporal Cloud connection (no account credentials were supplied), Docker image build/container execution (Docker runtime unavailable here), or AWS deployment. A unit test simulates successful namespace access; it is not a live Cloud test.

README and JDK-switch script update:

- Bash script syntax passed; sourcing it selected the installed JDK 25 and Maven reported Java 25.
- Missing-directory and non-25-JDK inputs were rejected without changing PATH.
- PowerShell script was reviewed but could not be executed here: Windows/PowerShell is unavailable.
- README clone command intentionally uses a placeholder: no remote repository was created.
