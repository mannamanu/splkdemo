# MISMO services — health checks and Temporal Cloud configuration only

A separate, minimal Maven multi-module project using Spring Boot 4.0.8, JDK 25 and Temporal Java SDK 1.39.0.

| Module | Included behavior |
|---|---|
| orchestrator-service | Actuator health probes, TLS/API-key Cloud connection, WorkflowClient bean and namespace-access readiness check |
| auth-service | Actuator health probes only |
| order-service | Actuator health probes only |

There is no XML processing, account-validation business logic, workflow/activity implementation, worker or task-queue polling. No local Temporal server, UI, SQLite or PostgreSQL is included. The Cloud connection uses API-key authentication; mTLS client certificates are not configured in this version.

## 1. Get the source

This download is a source ZIP; no remote Git repository has been published for it.
Extract `mismo-temporal-cloud-health.zip` and open a terminal in the extracted
`mismo-temporal-cloud-health` directory (the directory containing `pom.xml` and
`compose.yaml`). If you or your team publish the project to Git, clone it using
its actual repository URL:

```bash
# Replace the entire example URL with your real repository URL.
git clone https://github.com/YOUR-ORG/mismo-temporal-cloud-health.git
cd mismo-temporal-cloud-health
```

For a larger monorepo, clone that repository and change into this project's
subdirectory. Run every command below from this project's root unless stated otherwise.

## 2. Install prerequisites

| Prerequisite | Docker route | Native Java route |
|---|---|---|
| Git, from https://git-scm.com/downloads | Only for cloning | Only for cloning |
| Docker Desktop (Windows/macOS) or Docker Engine with Compose v2 (Linux), from https://docs.docker.com/get-started/get-docker/ | Required; start Docker first | Not required |
| JDK 25, from https://adoptium.net/temurin/releases/?version=25 | Not required on host | Required; choose **JDK**, not JRE |
| Maven 3.9.11 or newer 3.9.x, from https://maven.apache.org/install.html | Not required on host | Required; extract binary archive and add its `bin` directory to PATH |
| Temporal Cloud namespace, endpoint and API key | Required | Required |

On Windows, configure Docker Desktop to run Linux containers. Network access is
needed for Maven dependencies/container images and your Temporal Cloud endpoint.
No local SQLite, PostgreSQL or Temporal installation is needed.

Verify the tools for your chosen route:

```bash
# Docker route:
docker version
docker compose version

# Native route (after selecting JDK 25 below):
java --version
javac -version
mvn -version
```

Java and javac must report **25**, and Maven must report **Java version: 25**.
The Docker build selects JDK 25 inside the image regardless of your host JDK.

## 3. Switch from JDK 21 to JDK 25 for native runs

Keep JDK 21 installed. Install/extract a separate JDK 25 first; these scripts
**select an existing installation**, they do not download Java. To avoid changing
your machine's default JDK, download the JDK 25 ZIP/tar.gz and extract it to a
separate directory. Pass the actual extracted JDK root, which contains `bin`.

### Windows PowerShell

For example, if the JDK is extracted to `C:\Java\jdk-25`:

```powershell
. .\scripts\Use-Jdk25.ps1 -JdkHome "C:\Java\jdk-25"
java --version
javac -version
mvn -version
```

Adjust the path for your installation (paths with spaces are supported).
The script checks both the compiler and runtime, then sets `JAVA_HOME` and
prepends its `bin` directory to `PATH` for the **current terminal only**.
It does not uninstall JDK 21 or change system/user environment settings.
Close the terminal to revert. Run it again in each terminal used to start a service.
Do not launch it using a separate `powershell -File` process: those changes would
end when that child process exits.

If your organization's PowerShell execution policy blocks scripts, follow its
approved process. You can also set the same session variables manually after
checking the selected JDK is version 25:

```powershell
$env:JAVA_HOME = "C:\Java\jdk-25"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
java --version
javac -version
mvn -version
```

### macOS/Linux Bash

```bash
source scripts/use-jdk25.sh "/absolute/path/to/jdk-25"
java --version
javac -version
mvn -version
```

On macOS the JDK home is normally the installation's `Contents/Home` directory.
Use `source`, not `bash scripts/use-jdk25.sh`, so changes stay in the current shell.
Close the shell to revert. These scripts do not change an IDE's JDK settings:
select JDK 25 separately for the IDE project SDK and Maven runner if using an IDE.

## 4. Configure Temporal Cloud

In your existing Temporal Cloud account:

1. Select/create the namespace to use. Copy its exact gRPC endpoint (hostname:port) and full namespace identifier from the Cloud namespace page. Do not prefix the endpoint with `https://`.
2. Obtain a Temporal Cloud API key for an identity with access to that namespace and permission to describe/read it. This is a real Cloud key, not the old `local-client-key-change-me` application key. Never commit it.
3. Ensure your machine/network can reach the copied endpoint and port over TLS/gRPC. Corporate proxies/firewalls must permit it.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
notepad .env
```

macOS/Linux:

```bash
cp .env.example .env
# Edit .env with your Cloud settings.
```

All three variables are required:

```dotenv
TEMPORAL_TARGET=your-namespace.account-id.tmprl.cloud:7233
TEMPORAL_NAMESPACE=your-namespace.account-id
TEMPORAL_API_KEY=your-real-cloud-api-key
```

Those are shape examples, not usable credentials. TLS and server certificate verification are always enabled. `temporal-namespace` metadata is included for Cloud routing. The client credentials are read at startup; restart the orchestrator after key rotation.

## 5A. Run locally in Docker (recommended first run)

Stop earlier versions using host ports 8080–8082 before starting this one. Keep their database volumes.

```bash
docker compose config --quiet
docker compose up --build -d
docker compose ps
```

The build runs tests with Java 25 inside Docker. No host Java/Maven installation is needed for this route. Compose creates only the three Spring Boot containers. Do not post the full output of `docker compose config` without `--quiet`, because resolved environment values include the API key.

## Health endpoints

| Service/check | URL | Meaning |
|---|---|---|
| Orchestrator liveness | http://localhost:8080/actuator/health/liveness | JVM/app running; independent of Cloud |
| Orchestrator readiness | http://localhost:8080/actuator/health/readiness | App ready AND Cloud namespace RPC succeeds |
| Cloud connection only | http://localhost:8080/actuator/health/temporal | Cloud namespace can be described |
| Auth readiness | http://localhost:8081/actuator/health/readiness | App ready |
| Order readiness | http://localhost:8082/actuator/health/readiness | App ready |

Each service also has `/actuator/health` and `/actuator/health/liveness`. An UP result is HTTP 200 with `{"status":"UP"}`. A failed Cloud call makes orchestrator readiness/overall health return HTTP 503 with `{"status":"DOWN"}`. The overall `/actuator/health` response also lists its available health-group names. Liveness remains independent so a Cloud outage does not cause unnecessary orchestrator restart loops. Docker's HEALTHCHECK intentionally uses liveness, so a healthy Docker status alone does not prove Cloud connectivity.

PowerShell:

```powershell
curl.exe -i http://localhost:8080/actuator/health/liveness
curl.exe -i http://localhost:8080/actuator/health/readiness
curl.exe -i http://localhost:8080/actuator/health/temporal
curl.exe -i http://localhost:8081/actuator/health/readiness
curl.exe -i http://localhost:8082/actuator/health/readiness
```

Use `curl` on macOS/Linux. Health responses expose status only and require no application API key. Keep these management endpoints private when deployed.

The Cloud probe invokes DescribeNamespace with a 3-second deadline per health request. It verifies reachability, TLS, authentication and permission for that read operation; it does not verify workflow execution, task-queue workers or permissions to start workflows. Avoid very frequent probing across large fleets; use a reasonable monitoring interval such as 30 seconds. No Cloud resource or workflow is created by this check.

## 5B. Run without Docker

Select JDK 25 using the script above, then build all three services:

```bash
mvn -B -ntp verify
```

Native Spring Boot processes do not automatically load `.env`.
Open three terminals in the project root and select JDK 25 in each one before
running the corresponding commands below.

In three PowerShell terminals:

```powershell
# Orchestrator terminal: set actual values locally; avoid sharing commands containing real secrets.
$env:TEMPORAL_TARGET="your-namespace.account-id.tmprl.cloud:7233"
$env:TEMPORAL_NAMESPACE="your-namespace.account-id"
$env:TEMPORAL_API_KEY="your-real-cloud-api-key"
java -jar orchestrator-service/target/app.jar
```

```powershell
$env:SERVER_PORT="8081"
java -jar auth-service/target/app.jar
```

```powershell
$env:SERVER_PORT="8082"
java -jar order-service/target/app.jar
```

On Bash, use these commands in three separate terminals after selecting JDK 25:

```bash
# Terminal 1: supply your actual Cloud settings.
export TEMPORAL_TARGET='your-namespace.account-id.tmprl.cloud:7233'
export TEMPORAL_NAMESPACE='your-namespace.account-id'
read -r -s -p 'Temporal Cloud API key: ' TEMPORAL_API_KEY; echo
export TEMPORAL_API_KEY
SERVER_PORT=8080 java -jar orchestrator-service/target/app.jar
```

```bash
# Terminal 2
SERVER_PORT=8081 java -jar auth-service/target/app.jar
```

```bash
# Terminal 3
SERVER_PORT=8082 java -jar order-service/target/app.jar
```

Executable JAR names are `target/app.jar`. Use the health URLs above to verify
startup. Stop native applications with `Ctrl+C` in their terminals.

## Logs, restart and stop

For the Docker route:

```bash
docker compose logs --tail=100 -f
docker compose up -d --force-recreate orchestrator-service
docker compose down
```

Use `Ctrl+C` to stop following logs. Recreate the orchestrator after editing its
Cloud values in `.env`; a plain container restart does not reload Compose's
changed environment. Use `docker compose up --build -d` after source changes.
`docker compose down` stops this project's containers.

## Troubleshooting

- `release version 25 not supported`: Maven is still using an older JDK; run the switch script in that terminal and inspect `mvn -version`.
- Port already allocated: stop the older service or change the host-side port mapping in `compose.yaml`.
- Startup rejects blank settings: fill all three Cloud variables.
- Liveness UP / readiness DOWN: check the endpoint, full namespace, key validity/namespace permissions, DNS and outbound TLS/gRPC access. Health bodies deliberately hide exception details and secrets.
- Existing demo HTTP keys do not authenticate with Temporal Cloud.
- There are no workflow workers in this version, so the Cloud UI will show no worker polling or new executions from it.

## AWS later

Deploy these same images to ECS/Fargate or your existing compute platform. Inject TEMPORAL_API_KEY from Secrets Manager and endpoint/namespace through environment configuration. Set load-balancer readiness checks to `/actuator/health/readiness`, while keeping container liveness separate. Provide outbound connectivity to Cloud. No database configuration or Temporal server task is required for Cloud persistence. No AWS resources or Cloud account/namespace are provisioned by this package.

## Validation

See `VERIFICATION.md` for executed checks and limitations.

Official references:
- https://docs.temporal.io/develop/java/client/temporal-client
- https://docs.spring.io/spring-boot/reference/actuator/endpoints.html

- JDK installation: https://adoptium.net/installation/windows
- Maven installation: https://maven.apache.org/install.html
