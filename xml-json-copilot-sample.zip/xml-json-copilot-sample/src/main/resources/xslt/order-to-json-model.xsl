<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:o="urn:example:order:v1"
                exclude-result-prefixes="o">
    <xsl:output method="xml" encoding="UTF-8" omit-xml-declaration="yes"/>
    <xsl:strip-space elements="*"/>

    <!-- XSLT maps XML to a stable intermediate model; Jackson writes the final JSON. -->
    <xsl:template match="/o:Order">
        <jsonOrder>
            <orderId><xsl:value-of select="o:OrderId"/></orderId>
            <customer>
                <name><xsl:value-of select="o:Customer/o:Name"/></name>
                <email><xsl:value-of select="o:Customer/o:Email"/></email>
            </customer>
            <items>
                <xsl:for-each select="o:Items/o:Item">
                    <item>
                        <sku><xsl:value-of select="o:Sku"/></sku>
                        <quantity><xsl:value-of select="o:Quantity"/></quantity>
                        <unitPrice><xsl:value-of select="o:UnitPrice"/></unitPrice>
                    </item>
                </xsl:for-each>
            </items>
        </jsonOrder>
    </xsl:template>
</xsl:stylesheet>
