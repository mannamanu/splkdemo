package com.example.xmljson.demo;

import com.example.xmljson.model.OrderPayload;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Profile("demo")
@RestController
public class DemoDownstreamController {
    @PostMapping(value = "/demo/downstream/orders", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Receipt> acceptOrder(@RequestBody OrderPayload payload) {
        return ResponseEntity.accepted().body(new Receipt(true, payload.orderId(), payload.items().size()));
    }

    public record Receipt(boolean accepted, String orderId, int itemCount) {}
}
