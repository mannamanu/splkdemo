package com.example.xmljson.config;

import java.net.URI;
import java.time.Duration;
import java.util.Set;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "pipeline")
public record PipelineProperties(
        URI downstreamUrl,
        Duration connectTimeout,
        Duration readTimeout,
        int maxXmlBytes) {

    public PipelineProperties {
        if (downstreamUrl == null || downstreamUrl.getHost() == null
                || !Set.of("http", "https").contains(downstreamUrl.getScheme())) {
            throw new IllegalArgumentException("pipeline.downstream-url must be an absolute HTTP(S) URL");
        }
        if (connectTimeout == null || connectTimeout.isNegative() || connectTimeout.isZero()
                || readTimeout == null || readTimeout.isNegative() || readTimeout.isZero()) {
            throw new IllegalArgumentException("Pipeline timeouts must be positive");
        }
        if (maxXmlBytes < 1 || maxXmlBytes == Integer.MAX_VALUE) {
            throw new IllegalArgumentException("pipeline.max-xml-bytes must be between 1 and 2147483646");
        }
    }
}
