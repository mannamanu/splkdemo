package com.example.xmljson.error;

import org.springframework.http.HttpStatus;

public class PipelineException extends RuntimeException {
    private final HttpStatus status;

    public PipelineException(HttpStatus status, String message) {
        this(status, message, null);
    }

    public PipelineException(HttpStatus status, String message, Throwable cause) {
        super(message, cause);
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }
}
