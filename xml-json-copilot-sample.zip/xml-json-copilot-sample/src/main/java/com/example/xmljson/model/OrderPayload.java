package com.example.xmljson.model;

import java.math.BigDecimal;
import java.util.List;

public record OrderPayload(String orderId, Customer customer, List<LineItem> items) {
    public OrderPayload {
        items = List.copyOf(items);
    }

    public record Customer(String name, String email) {}

    public record LineItem(String sku, int quantity, BigDecimal unitPrice) {}
}
