package com.example.xmljson;

import com.example.xmljson.config.PipelineProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(PipelineProperties.class)
public class XmlJsonApplication {
    public static void main(String[] args) {
        SpringApplication.run(XmlJsonApplication.class, args);
    }
}
