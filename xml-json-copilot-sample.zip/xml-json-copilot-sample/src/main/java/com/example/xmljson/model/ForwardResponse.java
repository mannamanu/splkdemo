package com.example.xmljson.model;

public record ForwardResponse(String status, int downstreamStatus, OrderPayload payload) {}
