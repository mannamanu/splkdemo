package com.example.xmljson.service;

import com.example.xmljson.client.DownstreamOrderClient;
import com.example.xmljson.model.ForwardResponse;
import com.example.xmljson.model.OrderPayload;
import org.springframework.stereotype.Service;

@Service
public class OrderPipelineService {
    private final XmlOrderTransformer transformer;
    private final DownstreamOrderClient downstream;

    public OrderPipelineService(XmlOrderTransformer transformer, DownstreamOrderClient downstream) {
        this.transformer = transformer;
        this.downstream = downstream;
    }

    public ForwardResponse transformAndForward(byte[] xml) {
        OrderPayload payload = transformer.transform(xml);
        int downstreamStatus = downstream.send(payload);
        return new ForwardResponse("FORWARDED", downstreamStatus, payload);
    }
}
