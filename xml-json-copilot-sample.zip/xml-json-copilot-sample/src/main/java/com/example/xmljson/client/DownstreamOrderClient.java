package com.example.xmljson.client;

import com.example.xmljson.config.PipelineProperties;
import com.example.xmljson.error.PipelineException;
import com.example.xmljson.model.OrderPayload;
import java.net.SocketTimeoutException;
import java.net.http.HttpTimeoutException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

@Component
public class DownstreamOrderClient {
    private final RestClient restClient;
    private final PipelineProperties properties;

    public DownstreamOrderClient(RestClient downstreamRestClient, PipelineProperties properties) {
        this.restClient = downstreamRestClient;
        this.properties = properties;
    }

    public int send(OrderPayload payload) {
        try {
            var response = restClient.post()
                    .uri(properties.downstreamUrl())
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(payload)
                    .retrieve()
                    .toBodilessEntity();
            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new PipelineException(HttpStatus.BAD_GATEWAY,
                        "The downstream service did not accept the order");
            }
            return response.getStatusCode().value();
        } catch (RestClientResponseException exception) {
            throw new PipelineException(HttpStatus.BAD_GATEWAY,
                    "The downstream service rejected the order", exception);
        } catch (ResourceAccessException exception) {
            if (isTimeout(exception)) {
                throw new PipelineException(HttpStatus.GATEWAY_TIMEOUT,
                        "The downstream service timed out", exception);
            }
            throw new PipelineException(HttpStatus.BAD_GATEWAY,
                    "The downstream service is unavailable", exception);
        }
    }

    private static boolean isTimeout(Throwable exception) {
        for (Throwable cause = exception; cause != null; cause = cause.getCause()) {
            if (cause instanceof HttpTimeoutException || cause instanceof SocketTimeoutException) {
                return true;
            }
        }
        return false;
    }
}
