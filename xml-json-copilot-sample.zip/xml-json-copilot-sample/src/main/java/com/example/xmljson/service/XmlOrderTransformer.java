package com.example.xmljson.service;

import com.example.xmljson.config.PipelineProperties;
import com.example.xmljson.error.PipelineException;
import com.example.xmljson.model.OrderPayload;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

@Component
public class XmlOrderTransformer {
    private final PipelineProperties properties;
    private final Schema inputSchema;
    private final Templates mapping;

    public XmlOrderTransformer(PipelineProperties properties) {
        this.properties = properties;
        try (InputStream xsd = new ClassPathResource("schemas/order.xsd").getInputStream();
             InputStream xsl = new ClassPathResource("xslt/order-to-json-model.xsl").getInputStream()) {
            SchemaFactory schemas = SchemaFactory.newDefaultInstance();
            schemas.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            schemas.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            schemas.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            inputSchema = schemas.newSchema(new StreamSource(xsd));

            TransformerFactory transforms = TransformerFactory.newDefaultInstance();
            transforms.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            transforms.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            transforms.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            transforms.setURIResolver((href, base) -> {
                throw new TransformerException("External XSLT resources are disabled");
            });
            mapping = transforms.newTemplates(new StreamSource(xsl));
        } catch (IOException | SAXException | TransformerException exception) {
            throw new IllegalStateException("Cannot load the bundled XML schema or stylesheet", exception);
        }
    }

    public OrderPayload transform(byte[] xml) {
        if (xml.length == 0) {
            throw new PipelineException(HttpStatus.BAD_REQUEST, "The XML body must not be empty");
        }
        if (xml.length > properties.maxXmlBytes()) {
            throw new PipelineException(HttpStatus.PAYLOAD_TOO_LARGE, "The XML body exceeds the configured size limit");
        }

        Document validatedXml = validateAndParse(xml);
        try {
            // Templates and Schema are reusable; Transformer and DocumentBuilder are per request.
            Transformer transformer = mapping.newTransformer();
            transformer.setURIResolver((href, base) -> {
                throw new TransformerException("External XSLT resources are disabled");
            });
            DOMResult result = new DOMResult();
            transformer.transform(new DOMSource(validatedXml), result);
            return mapToPayload((Document) result.getNode());
        } catch (TransformerException | RuntimeException exception) {
            throw new PipelineException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "The bundled XML mapping could not produce an order", exception);
        }
    }

    private Document validateAndParse(byte[] xml) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newDefaultInstance();
            factory.setNamespaceAware(true);
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            factory.setSchema(inputSchema);

            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setErrorHandler(new StrictXmlErrorHandler());
            return builder.parse(new ByteArrayInputStream(xml));
        } catch (SAXException | IOException exception) {
            throw new PipelineException(HttpStatus.BAD_REQUEST,
                    "XML is malformed or does not conform to schemas/order.xsd", exception);
        } catch (ParserConfigurationException exception) {
            throw new IllegalStateException("Cannot configure the secure XML parser", exception);
        }
    }

    private OrderPayload mapToPayload(Document model) {
        Element root = model.getDocumentElement();
        Element customer = (Element) root.getElementsByTagName("customer").item(0);
        List<OrderPayload.LineItem> items = new ArrayList<>();
        NodeList nodes = root.getElementsByTagName("item");
        for (int index = 0; index < nodes.getLength(); index++) {
            Element item = (Element) nodes.item(index);
            items.add(new OrderPayload.LineItem(
                    text(item, "sku"),
                    Integer.parseInt(text(item, "quantity")),
                    new BigDecimal(text(item, "unitPrice"))));
        }
        return new OrderPayload(text(root, "orderId"),
                new OrderPayload.Customer(text(customer, "name"), text(customer, "email")), items);
    }

    private static String text(Element parent, String name) {
        return parent.getElementsByTagName(name).item(0).getTextContent().trim();
    }

    private static class StrictXmlErrorHandler implements ErrorHandler {
        @Override
        public void warning(SAXParseException exception) throws SAXException {
            throw exception;
        }

        @Override
        public void error(SAXParseException exception) throws SAXException {
            throw exception;
        }

        @Override
        public void fatalError(SAXParseException exception) throws SAXException {
            throw exception;
        }
    }
}
