package com.example.xmljson.controller;

import com.example.xmljson.config.PipelineProperties;
import com.example.xmljson.model.ForwardResponse;
import com.example.xmljson.service.OrderPipelineService;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderPipelineService pipeline;
    private final PipelineProperties properties;

    public OrderController(OrderPipelineService pipeline, PipelineProperties properties) {
        this.pipeline = pipeline;
        this.properties = properties;
    }

    @PostMapping(value = "/transform",
            consumes = {MediaType.APPLICATION_XML_VALUE, MediaType.TEXT_XML_VALUE},
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ForwardResponse transform(HttpServletRequest request) throws IOException {
        // Read at most the allowed size plus one byte, so oversized bodies are detected early.
        byte[] xml = request.getInputStream().readNBytes(properties.maxXmlBytes() + 1);
        return pipeline.transformAndForward(xml);
    }
}
