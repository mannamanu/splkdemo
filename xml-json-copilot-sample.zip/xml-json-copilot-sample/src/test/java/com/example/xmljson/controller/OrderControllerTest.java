package com.example.xmljson.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.xmljson.TestData;
import com.example.xmljson.client.DownstreamOrderClient;
import com.example.xmljson.error.ApiExceptionHandler;
import com.example.xmljson.error.PipelineException;
import com.example.xmljson.service.OrderPipelineService;
import com.example.xmljson.service.XmlOrderTransformer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

class OrderControllerTest {
    private MockMvc mvc;
    private DownstreamOrderClient downstream;

    @BeforeEach
    void setUp() {
        var properties = TestData.properties("http://localhost:8081/orders");
        downstream = mock(DownstreamOrderClient.class);
        var pipeline = new OrderPipelineService(new XmlOrderTransformer(properties), downstream);
        mvc = MockMvcBuilders.standaloneSetup(new OrderController(pipeline, properties))
                .setControllerAdvice(new ApiExceptionHandler()).build();
    }

    @Test
    void returnsTransformedPayloadAfterDownstreamAcceptsIt() throws Exception {
        when(downstream.send(any())).thenReturn(202);
        mvc.perform(post("/api/orders/transform").contentType(MediaType.APPLICATION_XML)
                        .content(TestData.xml()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("FORWARDED"))
                .andExpect(jsonPath("$.downstreamStatus").value(202))
                .andExpect(jsonPath("$.payload.orderId").value("ORD-1001"))
                .andExpect(jsonPath("$.payload.items[0].quantity").value(2));
    }

    @Test
    void rejectsInvalidXmlBeforeCallingDownstream() throws Exception {
        mvc.perform(post("/api/orders/transform").contentType(MediaType.APPLICATION_XML)
                        .content(TestData.xml().replace("<Quantity>2</Quantity>", "<Quantity>0</Quantity>")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400));
        verifyNoInteractions(downstream);
    }

    @Test
    void rejectsOversizedBodiesBeforeCallingDownstream() throws Exception {
        mvc.perform(post("/api/orders/transform").contentType(MediaType.APPLICATION_XML)
                        .content(new byte[65537]))
                .andExpect(status().isPayloadTooLarge());
        verifyNoInteractions(downstream);
    }

    @Test
    void rejectsEmptyBodyBeforeCallingDownstream() throws Exception {
        mvc.perform(post("/api/orders/transform").contentType(MediaType.APPLICATION_XML))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(downstream);
    }

    @Test
    void rejectsJsonInput() throws Exception {
        mvc.perform(post("/api/orders/transform").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isUnsupportedMediaType());
        verifyNoInteractions(downstream);
    }

    @Test
    void propagatesDownstreamTimeoutAsProblemDetail() throws Exception {
        when(downstream.send(any())).thenThrow(
                new PipelineException(HttpStatus.GATEWAY_TIMEOUT, "The downstream service timed out"));
        mvc.perform(post("/api/orders/transform").contentType(MediaType.APPLICATION_XML).content(TestData.xml()))
                .andExpect(status().isGatewayTimeout())
                .andExpect(jsonPath("$.detail").value("The downstream service timed out"));
    }
}
