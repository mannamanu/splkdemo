package com.example.xmljson;

import com.example.xmljson.config.PipelineProperties;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import org.springframework.core.io.ClassPathResource;

public final class TestData {
    private TestData() {}

    public static PipelineProperties properties(String downstreamUrl) {
        return new PipelineProperties(URI.create(downstreamUrl), Duration.ofSeconds(2),
                Duration.ofSeconds(5), 65536);
    }

    public static String xml() throws IOException {
        return new ClassPathResource("fixtures/order.xml").getContentAsString(StandardCharsets.UTF_8);
    }
}
