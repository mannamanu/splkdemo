package com.example.xmljson;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class OrderPipelineIntegrationTest {
    private static final AtomicInteger calls = new AtomicInteger();
    private static final AtomicReference<String> receivedJson = new AtomicReference<>();
    private static final AtomicReference<String> receivedContentType = new AtomicReference<>();
    private static final HttpServer downstream = startDownstream();
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();

    @LocalServerPort
    private int port;

    @Autowired
    private ObjectMapper mapper;

    @DynamicPropertySource
    static void downstreamProperties(DynamicPropertyRegistry registry) {
        registry.add("pipeline.downstream-url",
                () -> "http://localhost:" + downstream.getAddress().getPort() + "/orders");
    }

    @BeforeEach
    void reset() {
        calls.set(0);
        receivedJson.set(null);
        receivedContentType.set(null);
    }

    @AfterAll
    static void stopDownstream() {
        downstream.stop(0);
    }

    @Test
    void forwardsRealHttpJsonWithSpecialCharactersAndNumericValues() throws Exception {
        String xml = TestData.xml().replace("Jane Doe", "Jane &amp; \"Doe\"");
        HttpResponse<String> response = postXml(xml);
        assertThat(response.statusCode()).isEqualTo(200);
        assertThat(calls.get()).isEqualTo(1);
        assertThat(receivedContentType.get()).startsWith("application/json");
        JsonNode posted = mapper.readTree(receivedJson.get());
        assertThat(posted.at("/customer/name").asText()).isEqualTo("Jane & \"Doe\"");
        assertThat(posted.at("/items/0/quantity").isInt()).isTrue();
        assertThat(posted.at("/items/0/unitPrice").isNumber()).isTrue();
        assertThat(posted.at("/items/0/unitPrice").decimalValue()).isEqualByComparingTo("19.95");
        assertThat(mapper.readTree(response.body()).at("/downstreamStatus").asInt()).isEqualTo(202);
    }

    @Test
    void preventsDownstreamCallWhenSchemaValidationFails() throws Exception {
        HttpResponse<String> response = postXml(TestData.xml().replace("<OrderId>ORD-1001</OrderId>", ""));
        assertThat(response.statusCode()).isEqualTo(400);
        assertThat(calls.get()).isZero();
        assertThat(mapper.readTree(response.body()).at("/status").asInt()).isEqualTo(400);
    }

    private HttpResponse<String> postXml(String xml) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create("http://localhost:" + port + "/api/orders/transform"))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/xml")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(xml, StandardCharsets.UTF_8)).build();
        return http.send(request, HttpResponse.BodyHandlers.ofString());
    }

    private static HttpServer startDownstream() {
        try {
            HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
            server.createContext("/orders", exchange -> {
                receivedJson.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
                receivedContentType.set(exchange.getRequestHeaders().getFirst("Content-Type"));
                calls.incrementAndGet();
                byte[] body = "{\"accepted\":true}".getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(202, body.length);
                try (var output = exchange.getResponseBody()) {
                    output.write(body);
                } finally {
                    exchange.close();
                }
            });
            server.start();
            return server;
        } catch (IOException exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }
}
