package com.example.xmljson.client;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

import com.example.xmljson.TestData;
import com.example.xmljson.config.PipelineProperties;
import com.example.xmljson.error.PipelineException;
import com.example.xmljson.service.XmlOrderTransformer;
import java.io.IOException;
import java.net.SocketTimeoutException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClient;

class DownstreamOrderClientTest {
    private MockRestServiceServer server;
    private DownstreamOrderClient client;
    private final PipelineProperties properties = TestData.properties("http://localhost:8081/orders");

    @BeforeEach
    void setUp() {
        RestClient.Builder builder = RestClient.builder();
        server = MockRestServiceServer.bindTo(builder).build();
        client = new DownstreamOrderClient(builder.build(), properties);
    }

    @ParameterizedTest
    @ValueSource(ints = {200, 202, 204})
    void sendsJsonAndAcceptsAnySuccessfulStatus(int status) throws Exception {
        var payload = new XmlOrderTransformer(properties)
                .transform(TestData.xml().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        server.expect(requestTo("http://localhost:8081/orders"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json("""
                        {"orderId":"ORD-1001","customer":{"name":"Jane Doe","email":"jane@example.com"},
                        "items":[{"sku":"SKU-101","quantity":2,"unitPrice":19.95},
                        {"sku":"SKU-202","quantity":1,"unitPrice":5.50}]}
                        """))
                .andRespond(withStatus(HttpStatusCode.valueOf(status)));
        assertThat(client.send(payload)).isEqualTo(status);
        server.verify();
    }

    @ParameterizedTest
    @ValueSource(ints = {400, 503, 302})
    void mapsRejectedOrRedirectedRequestsToBadGateway(int status) throws Exception {
        server.expect(requestTo("http://localhost:8081/orders"))
                .andRespond(withStatus(HttpStatusCode.valueOf(status)));
        assertFailure(HttpStatus.BAD_GATEWAY);
        server.verify();
    }

    @Test
    void mapsTimeoutToGatewayTimeout() throws Exception {
        server.expect(requestTo("http://localhost:8081/orders"))
                .andRespond(request -> { throw new SocketTimeoutException("simulated timeout"); });
        assertFailure(HttpStatus.GATEWAY_TIMEOUT);
        server.verify();
    }

    @Test
    void mapsConnectionFailureToBadGateway() throws Exception {
        server.expect(requestTo("http://localhost:8081/orders"))
                .andRespond(request -> { throw new IOException("simulated connection failure"); });
        assertFailure(HttpStatus.BAD_GATEWAY);
        server.verify();
    }

    private void assertFailure(HttpStatus expected) throws Exception {
        var payload = new XmlOrderTransformer(properties)
                .transform(TestData.xml().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertThatThrownBy(() -> client.send(payload)).isInstanceOfSatisfying(PipelineException.class,
                exception -> assertThat(exception.status()).isEqualTo(expected));
    }

}
