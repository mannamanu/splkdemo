package com.example.xmljson.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.example.xmljson.TestData;
import com.example.xmljson.error.PipelineException;
import com.example.xmljson.model.OrderPayload;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpStatus;

class XmlOrderTransformerTest {
    private final XmlOrderTransformer transformer =
            new XmlOrderTransformer(TestData.properties("http://localhost:8081/orders"));

    @Test
    void validatesTransformsAndPreservesNumericTypes() throws Exception {
        OrderPayload payload = transform(TestData.xml());
        assertThat(payload.orderId()).isEqualTo("ORD-1001");
        assertThat(payload.customer().name()).isEqualTo("Jane Doe");
        assertThat(payload.customer().email()).isEqualTo("jane@example.com");
        assertThat(payload.items()).containsExactly(
                new OrderPayload.LineItem("SKU-101", 2, new BigDecimal("19.95")),
                new OrderPayload.LineItem("SKU-202", 1, new BigDecimal("5.50")));
    }

    @Test
    void acceptsEquivalentNamespacePrefixes() throws Exception {
        String xml = TestData.xml().replace("xmlns=", "xmlns:o=")
                .replaceAll("<(\\/?)(Order|OrderId|Customer|Name|Email|Items|Item|Sku|Quantity|UnitPrice)([ >])",
                        "<$1o:$2$3");
        assertThat(transform(xml).orderId()).isEqualTo("ORD-1001");
    }

    @ParameterizedTest
    @MethodSource("invalidXml")
    void rejectsInvalidXml(String xml) {
        assertThatThrownBy(() -> transform(xml)).isInstanceOfSatisfying(PipelineException.class,
                exception -> assertThat(exception.status()).isEqualTo(HttpStatus.BAD_REQUEST));
    }

    static Stream<String> invalidXml() throws Exception {
        String valid = TestData.xml();
        return Stream.of(
                "<Order>",
                valid.replace("<OrderId>ORD-1001</OrderId>", ""),
                valid.replace("urn:example:order:v1", "urn:wrong:namespace"),
                valid.replace("<Quantity>2</Quantity>", "<Quantity>0</Quantity>"),
                valid.replace("<Quantity>2</Quantity>", "<Quantity>2.5</Quantity>"),
                valid.replace("<UnitPrice>19.95</UnitPrice>", "<UnitPrice>19.955</UnitPrice>"));
    }

    @Test
    void rejectsDoctypeAndExternalEntities() throws Exception {
        String xml = TestData.xml()
                .replace("<Order xmlns=", "<!DOCTYPE Order [<!ENTITY xxe SYSTEM \"file:///etc/passwd\">]>\n<Order xmlns=")
                .replace("Jane Doe", "&xxe;");
        assertThatThrownBy(() -> transform(xml)).isInstanceOfSatisfying(PipelineException.class,
                exception -> assertThat(exception.status()).isEqualTo(HttpStatus.BAD_REQUEST));
    }

    @Test
    void rejectsEmptyInput() {
        assertThatThrownBy(() -> transformer.transform(new byte[0]))
                .isInstanceOfSatisfying(PipelineException.class,
                        exception -> assertThat(exception.status()).isEqualTo(HttpStatus.BAD_REQUEST));
    }

    @Test
    void rejectsOversizedInput() {
        assertThatThrownBy(() -> transformer.transform(new byte[65537]))
                .isInstanceOfSatisfying(PipelineException.class,
                        exception -> assertThat(exception.status()).isEqualTo(HttpStatus.PAYLOAD_TOO_LARGE));
    }

    @Test
    void honorsDeclaredXmlEncoding() throws Exception {
        String xml = TestData.xml().replace("UTF-8", "ISO-8859-1").replace("Jane Doe", "José Doe");
        assertThat(transformer.transform(xml.getBytes(StandardCharsets.ISO_8859_1)).customer().name())
                .isEqualTo("José Doe");
    }

    @Test
    void safelyHandlesConcurrentRequests() throws Exception {
        var executor = Executors.newFixedThreadPool(4);
        try {
            List<Future<OrderPayload>> results = new ArrayList<>();
            for (int index = 0; index < 20; index++) {
                String xml = TestData.xml().replace("ORD-1001", "ORD-" + index);
                results.add(executor.submit(() -> transform(xml)));
            }
            for (int index = 0; index < results.size(); index++) {
                assertThat(results.get(index).get().orderId()).isEqualTo("ORD-" + index);
            }
        } finally {
            executor.shutdownNow();
        }
    }

    private OrderPayload transform(String xml) {
        return transformer.transform(xml.getBytes(StandardCharsets.UTF_8));
    }
}
