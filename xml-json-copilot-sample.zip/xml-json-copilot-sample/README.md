# XML-to-JSON Spring Boot sample with Copilot agents

A small, synchronous Java service that receives an XML order, validates it with an XSD,
maps it with XSLT, serializes the mapped records as JSON, and sends an HTTP POST to a downstream REST service.
The project also includes four GitHub Copilot custom agents for use in VS Code.

## Requirements

- JDK 17 or newer, with `JAVA_HOME` pointing to your JDK.
- Internet access on the first build to download Maven and dependencies.
- VS Code with Java support and GitHub Copilot access for the optional IDE agent workflow.

The project targets Java 17 and pins Spring Boot **3.5.16** and Maven **3.9.16**.
Maven is supplied through the official Maven Wrapper, so you do not need to install Maven separately.

## Run the local demo

Extract the ZIP and open **the `xml-json-copilot-sample` folder itself** in VS Code.
Run commands from that folder.

macOS/Linux:

```bash
chmod +x mvnw
./mvnw verify
./mvnw spring-boot:run -Dspring-boot.run.profiles=demo
```

Windows PowerShell:

```powershell
.\mvnw.cmd verify
.\mvnw.cmd spring-boot:run -Dspring-boot.run.profiles=demo
```

The `demo` profile starts a mock JSON endpoint in the same application. The pipeline still makes
a real HTTP call to that endpoint. It lets you run the complete flow with one process.
The mock is only active with the `demo` profile.

In a second terminal, send XML:

```bash
curl -i -X POST http://localhost:8080/api/orders/transform \
  -H 'Content-Type: application/xml' \
  -H 'Accept: application/json' \
  --data-binary @samples/order.xml
```

Windows PowerShell:

```powershell
Invoke-RestMethod -Method Post `
  -Uri 'http://localhost:8080/api/orders/transform' `
  -ContentType 'application/xml' `
  -InFile 'samples/order.xml'
```

The result is HTTP 200:

```json
{
  "status": "FORWARDED",
  "downstreamStatus": 202,
  "payload": {
    "orderId": "ORD-1001",
    "customer": { "name": "Jane Doe", "email": "jane@example.com" },
    "items": [
      { "sku": "SKU-101", "quantity": 2, "unitPrice": 19.95 },
      { "sku": "SKU-202", "quantity": 1, "unitPrice": 5.50 }
    ]
  }
}
```

Only the `payload` object is sent to the downstream API; the wrapper is returned to the original caller.
The downstream response body is discarded. Its successful HTTP status is recorded in `downstreamStatus`.
A successful downstream HTTP response means that endpoint accepted the request according to its HTTP contract;
it does not prove that later asynchronous processing completed.

Health: `GET http://localhost:8080/actuator/health`.
You can also choose **Run XML-to-JSON demo** from VS Code's Run and Debug view.

## Call your actual downstream service

Run without the demo profile and set `DOWNSTREAM_URL`:

```bash
DOWNSTREAM_URL=https://your-service.example.com/api/orders ./mvnw spring-boot:run
```

Windows PowerShell:

```powershell
$env:DOWNSTREAM_URL = 'https://your-service.example.com/api/orders'
.\mvnw.cmd spring-boot:run
```

The placeholder above must be replaced with your actual endpoint. The default outside demo mode is
`http://localhost:8081/orders`. No real external service or account is needed for the supplied demo.
The client sends `Content-Type: application/json` and `Accept: application/json`.
For authentication, adapt `RestClientConfig` to add the headers your API requires and load secrets from configuration.

You can also package and run the JAR:

```bash
./mvnw verify
java -jar target/xml-json-copilot-sample-1.0.0.jar --spring.profiles.active=demo
```

## Where the transformation happens

| Stage | File | Purpose |
|---|---|---|
| XML endpoint | `controller/OrderController.java` | Accept XML and read a bounded body. |
| Input validation | `resources/schemas/order.xsd` | Require fields and constrain quantities, prices, item counts, and lengths. |
| Field mapping | `resources/xslt/order-to-json-model.xsl` | Rename and reshape XML into an intermediate `jsonOrder` XML model. |
| Typed output | `service/XmlOrderTransformer.java`, `model/OrderPayload.java` | Convert the intermediate XML into records with integer quantities and decimal prices. |
| JSON POST | `client/DownstreamOrderClient.java` | Let Jackson serialize those records as JSON and send them with `RestClient`. |
| Orchestration | `service/OrderPipelineService.java` | Validate/transform first, then send once. |

Java files in the table are under `src/main/java/com/example/xmljson`; resource files are under `src/main`.

**XSD validates the XML; XSLT transforms it.** This sample uses the JDK's XSLT 1.0 implementation to
produce intermediate XML. Jackson writes the final JSON so quotes, ampersands, Unicode, numbers,
and arrays are serialized correctly. It does not concatenate JSON strings inside the stylesheet.

The expected input namespace is `urn:example:order:v1`. Prefixes may vary, but the namespace URI must match.
To support your own XML contract, update the XSD, the XSLT selectors/output, and the Java model/mapping together.
For XSLT 2.0/3.0 features, choose a supporting engine and test the resource restrictions before changing the setup.

## HTTP and validation behavior

| Situation | Response |
|---|---|
| Valid XML and downstream HTTP 2xx | 200 with `FORWARDED`, the downstream status, and the mapped payload. |
| Empty, malformed, XSD-invalid, or DOCTYPE-containing XML | 400. No downstream request. |
| XML exceeds `pipeline.max-xml-bytes` | 413. No downstream request. |
| Input media type other than XML | 415. |
| Downstream HTTP rejection, redirect, or connection failure | 502. |
| Downstream connect/read timeout | 504. |
| Broken bundled transformation | 500. |

Failures use Spring `ProblemDetail` JSON. Raw input and downstream response bodies are not returned in errors.
The XSD requires 1–100 items, quantities 1–10000, and nonnegative decimal prices with up to two fractional digits.
It requires a nonblank customer email value but does not validate email-address syntax.

Configuration in `src/main/resources/application.yml`:

| Property | Default |
|---|---|
| `server.port` | `8080`; override with `PORT`. |
| `pipeline.downstream-url` | `http://localhost:8081/orders`; override with `DOWNSTREAM_URL` outside demo mode. |
| `pipeline.connect-timeout` | `2s`. |
| `pipeline.read-timeout` | `5s`. |
| `pipeline.max-xml-bytes` | `65536` bytes. |

Example override: `--pipeline.read-timeout=10s` when running the JAR.

The parser rejects DTDs and external entities. External schema/stylesheet access and XSLT `document()` resolution
are disabled. Bundled schemas and compiled templates are reusable; parsers and transformers are created per request.
The sample has no inbound authentication, persistence, retry queue, or downstream availability health probe.
Its health endpoint reports application health. Add the controls your deployment requires before exposing it publicly.
Outbound POSTs are not retried automatically; retries require an idempotency contract with the downstream API.

## Copilot agent setup included in this repository

These are **IDE development agents**, not Spring beans, background services, or runtime AI calls.
They are optional: the application runs without Copilot.

| Agent picker name | Definition | Tools | Role |
|---|---|---|---|
| `planner` | `.github/agents/planner.agent.md` | Read/search | Plan changes across XSD, XSLT, Java, and tests. |
| `developer` | `.github/agents/developer.agent.md` | Read/search/edit/execute | Implement and verify changes. |
| `tester` | `.github/agents/tester.agent.md` | Read/search/edit/execute | Add tests and report defects. |
| `reviewer` | `.github/agents/reviewer.agent.md` | Read/search | Review the diff and test evidence without editing. |

Shared context lives in `.github/copilot-instructions.md`. Scoped rules live in
`.github/instructions/java.instructions.md` and `.github/instructions/tests.instructions.md`.
No model is pinned; each role uses the model selected in your Copilot session.

1. Open this project's root folder in an up-to-date VS Code and sign in to GitHub Copilot.
2. Open Copilot Chat and choose `planner` from the agent dropdown.
3. Submit the task with acceptance criteria. Review its plan.
4. Use **Implement plan**, or select `developer` and provide the plan.
5. Use **Test implementation** to switch to `tester`, then **Review changes** for `reviewer`.

Handoffs prefill the next prompt; they use `send: false`, so you submit each stage yourself.
The four roles do not run simultaneously or automatically because files exist.
Tool availability depends on VS Code, the selected agent harness, extensions, and organization policy.
These definitions use documented VS Code tool sets. If a tool name is flagged, inspect the tool picker and update
the file for your installed environment. Keep `planner` and `reviewer` limited to read/search tools.

If agents are missing, open Chat's **Configure Chat → Agents** view and check the loaded definitions.
Also check that this project folder, rather than its parent folder, is the workspace root.
The VS Code Local harness supports these tool sets and handoffs; other harnesses can vary.
See [the practical agent walkthrough](docs/copilot-agents.md) for ready-to-use prompts and an example enhancement.

## Tests

```bash
./mvnw verify
./mvnw -Dtest=XmlOrderTransformerTest test
./mvnw -Dtest=OrderControllerTest test
./mvnw -Dtest=DownstreamOrderClientTest test
./mvnw -Dtest=OrderPipelineIntegrationTest test
```

Use `.\mvnw.cmd` on Windows. The unit tests cover mapping, namespace prefixes, input encodings,
numeric values, concurrent transformations, invalid XML, external entities, size limits, controller behavior,
and downstream success/rejection/timeout handling. The integration tests run real inbound and outbound HTTP,
verify JSON escaping and numeric types, and verify that invalid input never reaches the downstream service.
All test endpoints are local mocks; tests do not send customer data to an external service.

## References

- [Spring Framework RestClient documentation](https://docs.spring.io/spring-framework/reference/6.2/integration/rest-clients.html)
- [Java XML security guide](https://docs.oracle.com/en/java/javase/17/security/java-api-xml-processing-jaxp-security-guide.html)
- [VS Code custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents)
- [VS Code custom instructions](https://code.visualstudio.com/docs/agent-customization/custom-instructions)
- [VS Code tools reference](https://code.visualstudio.com/docs/agents/reference/tools-reference)
