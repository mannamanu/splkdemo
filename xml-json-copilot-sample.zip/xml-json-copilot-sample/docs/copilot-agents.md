# Using the included Copilot agents

Open the repository root in VS Code and sign in to GitHub Copilot. The `.github` folder contains all setup;
you do not need to register agents with the Spring application or add AI dependencies to `pom.xml`.

## The four roles

| Role | Select in Chat | Focus | Allowed tool sets |
|---|---|---|---|
| Planning | `planner` | Inspect the contracts and propose a bounded change. | `read`, `search` |
| Implementation | `developer` | Edit Java/resources, update examples, and run checks. | `read`, `search`, `edit`, `execute` |
| Testing | `tester` | Add behavior tests and report defects. | `read`, `search`, `edit`, `execute` |
| Review | `reviewer` | Inspect changes for concrete bugs and missing tests. | `read`, `search` |

These are role configurations for IDE chat sessions. They inherit the model you select in Chat.
The tool sets control available capabilities; tester file scope is an instruction, not an enforced filesystem boundary.
Normal VS Code permission controls still apply to command execution. A reviewer can inspect test output but cannot run tests.

The agent files have YAML frontmatter for names/tools/handoffs, followed by task instructions.
Each handoff carries the conversation context and a prepared prompt. `send: false` keeps submission manual.
You can also use separate sessions and explicitly attach the requirements, plan, diff, and test results.

## First exercise: add an optional reference ID

This enhancement is an exercise; it is not implemented in the starting service. Existing example XML should remain valid.
Save a source-control baseline first so the reviewer can inspect the actual changes.

Select `planner` and send:

```text
Plan adding an optional ReferenceId after OrderId in the input XML.
Map it to a JSON field named referenceId, omitting that JSON field when the XML element is absent.
Existing XML and its expected JSON must remain valid and unchanged when ReferenceId is absent.
Require a nonblank value of at most 64 characters when the field is present.
Inspect the XSD, XSLT, records, DOM mapping, examples, and tests.
Return acceptance criteria and affected files. Do not edit files.
```

Review the plan, then use **Implement plan** or select `developer`:

```text
Implement the preceding ReferenceId plan using the existing architecture.
Update the XSD, XSLT, Java records/mapping, relevant samples, and tests consistently.
Preserve secure XML settings, numeric output types, input limits, and downstream error handling.
Run focused tests and then the Maven wrapper verify command.
Report changed behavior, files, and actual verification results.
```

Select `tester` or use **Test implementation**:

```text
Test the ReferenceId change against the supplied requirements.
Cover present, absent, blank, and oversized ReferenceId values.
Verify that absent ReferenceId is omitted from outbound JSON and existing samples still work.
Verify invalid XML never calls the downstream API.
Use the existing testing patterns; report production defects for the developer to fix.
Run the relevant tests and the Maven wrapper verify command.
```

Select `reviewer` or use **Review changes**:

```text
Review the current diff against the ReferenceId requirements and test evidence.
Check optional-field handling, XSD/XSLT/record/mapping consistency, JSON serialization,
XML resource restrictions, and absence of downstream calls after validation failures.
Report actionable findings with severity and file/location. Do not edit files.
```

The review handoff **Fix review findings** returns to `developer`.
For an independent review, open a fresh reviewer session and attach the requirements and test output.
The developer and tester have execution tools; the planner and reviewer intentionally do not.

## Context to supply for other tasks

Provide a concrete behavior change, expected input/output, acceptance criteria, and relevant files.
For XML mapping changes, include the XSD, XSLT, `XmlOrderTransformer`, `OrderPayload`, and a sample request.
For outbound issues, include `DownstreamOrderClient`, `RestClientConfig`, a sanitized error, and the HTTP contract.
For tests, include the affected classes and their existing tests. Do not paste credentials or real customer documents.

For one small defect you can go directly to `developer`, then request a review.
Use parallel sessions for independent tasks; concurrent edits should use separate Git worktrees.
Separate chat windows do not automatically isolate workspace files.

## Troubleshooting discovery

1. Open the `xml-json-copilot-sample` folder as the workspace root.
2. Check Chat's agent dropdown and **Configure Chat → Agents**.
3. Check the role file's YAML frontmatter for errors and whether the current harness supports its tools/handoffs.
4. Inspect available tools from the Chat tool picker. Documented tool IDs can vary across harnesses and older VS Code versions.
5. Check organization policy if Agent mode or customizations are disabled.

With the VS Code Local harness, this project's `.vscode/settings.json` enables Copilot instruction files.
Copilot-hosted sessions discover repository instructions through their own discovery rules.
The runtime behavior of the Spring application is unaffected by which IDE agent you select.

Official documentation:
[custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents),
[custom instructions](https://code.visualstudio.com/docs/agent-customization/custom-instructions), and
[tool sets](https://code.visualstudio.com/docs/agents/reference/tools-reference).
