# Verification of the supplied sample

Verified on Linux with OpenJDK 17.0.20, Maven Wrapper 3.3.4, Maven 3.9.16, and Spring Boot 3.5.16.

## Build and tests

The supplied Maven wrapper was used to run `verify`. Public Maven dependencies were resolved using
temporary environment-specific proxy settings and a temporary dependency cache; those settings are not part of the project.
The build completed successfully and produced the executable Spring Boot JAR.

| Suite | Tests | Failures | Errors | Skipped |
|---|---:|---:|---:|---:|
| `XmlOrderTransformerTest` | 13 | 0 | 0 | 0 |
| `DownstreamOrderClientTest` | 8 | 0 | 0 | 0 |
| `OrderControllerTest` | 6 | 0 | 0 | 0 |
| `OrderPipelineIntegrationTest` | 2 | 0 | 0 | 0 |
| **Total** | **29** | **0** | **0** | **0** |

The integration tests exercised real inbound/outbound HTTP with a separate local mock HTTP server,
including JSON escaping and numeric types. No external business API was called.

## Packaged application checks

The executable JAR was started with `--spring.profiles.active=demo --server.port=18080`.
Checks passed for:

- Health reporting `UP`.
- Valid sample XML returning HTTP 200 with `FORWARDED` and downstream status 202.
- The forwarded payload matching `samples/expected-downstream.json`.
- The demo JSON endpoint returning HTTP 202 and a receipt.
- Invalid XML returning HTTP 400.
- An oversized XML body returning HTTP 413.
- JSON submitted to the XML endpoint returning HTTP 415.

The demo process was stopped after verification.

## Development configuration checks

All four custom agent files were parsed as YAML frontmatter. Names, handoff targets, and documented
tool sets were checked. Planner and reviewer have only read/search tools. Scoped instruction frontmatter,
VS Code JSON, application YAML, Maven XML, and the shared XML fixture were also checked.
The wrapper distribution SHA-256 is pinned after verifying the published Maven distribution SHA-512.

Actual Copilot chat sessions and Windows execution were not run in this environment. Agent discovery,
tool availability, and handoff support depend on the user's VS Code version, selected harness, account, and organization policy.
