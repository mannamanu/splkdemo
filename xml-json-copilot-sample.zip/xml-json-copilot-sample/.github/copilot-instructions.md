# Project context

- This is a Java 17, Spring Boot 3.5, Maven, Spring MVC sample. Read `pom.xml` for exact versions.
- The synchronous pipeline accepts XML, validates it with the bundled XSD, applies the bundled XSLT 1.0 stylesheet, maps the intermediate XML to records, and POSTs JSON using Spring `RestClient`.
- Input contract: `src/main/resources/schemas/order.xsd`. Mapping: `src/main/resources/xslt/order-to-json-model.xsl`. JSON contract: `OrderPayload` and `samples/expected-downstream.json`.
- Keep HTTP input in `controller`, transformation and orchestration in `service`, and outbound HTTP in `client`. Use constructor injection.
- Changes to a field can require coordinated updates to the XSD, XSLT, Java records, DOM mapping, examples, and tests.
- Reuse Jackson to serialize JSON. Keep prices as `BigDecimal` and quantities as integers.
- Keep XML external entities, DTDs, external schemas, external stylesheets, and XSLT external document loading disabled. Only packaged, trusted XSD and XSL files are used.
- Reuse `Schema` and `Templates`; create a separate `DocumentBuilder` and `Transformer` per request.
- Validate before sending HTTP. Invalid XML must never trigger a downstream call. Keep bounded request reads and configured HTTP timeouts.
- Preserve the explicit non-2xx, connection failure, and timeout behavior. POST retries require an agreed idempotency contract.
- Avoid logging raw XML, JSON bodies, or credentials. Keep the mock REST endpoint restricted to the `demo` profile.
- Unit tests use JUnit 5, Mockito, standalone MockMvc, and MockRestServiceServer without loading Spring. `OrderPipelineIntegrationTest` is the HTTP integration test that intentionally starts Spring Boot.
- Run `./mvnw verify` from the project root; on Windows use `.\mvnw.cmd verify`. For focused tests use `./mvnw -Dtest=ClassName test`.
- Run the local demo with `./mvnw spring-boot:run -Dspring-boot.run.profiles=demo`; use the Windows wrapper on Windows.
- Summarize changed behavior, files, commands actually run, and their results. Clearly report any checks you could not run.
