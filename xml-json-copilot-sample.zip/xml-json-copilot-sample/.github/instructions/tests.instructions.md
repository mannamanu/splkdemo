---
description: Focused testing conventions for transformation and HTTP behavior.
applyTo: "src/test/java/**/*.java"
---

- Test observable behavior and meaningful edge cases, including failure paths and absence of unwanted downstream calls.
- Use JUnit 5 and AssertJ. Prefer Mockito for collaborators and standalone MockMvc for controller tests.
- Use MockRestServiceServer for outbound client unit tests. Use the existing embedded HTTP server for integration tests.
- Unit tests should not load Spring. The existing integration test deliberately exercises a real HTTP pipeline.
- Use existing fixtures; add clear fixtures when behavior requires them. Cover namespace handling, decimal precision, JSON escaping, validation failures, external-entity rejection, and downstream errors when relevant.
- Run focused tests during iteration, then the Maven verify command. Report actual outcomes rather than assuming tests passed.
