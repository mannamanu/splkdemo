---
description: Java application conventions for the XML transformation service.
applyTo: "src/main/java/**/*.java"
---

- Use Java 17-compatible code, constructor injection, and immutable records for transport models.
- Keep Spring MVC and synchronous RestClient consistent with the existing architecture.
- Maintain the XML namespace `urn:example:order:v1` unless the requested API change explicitly revises it.
- Serialize records using Jackson; preserve integer quantities and BigDecimal money values.
- Treat XML parsing errors as HTTP 400, size-limit errors as 413, downstream rejections/unavailability as 502, and downstream timeouts as 504.
- Keep parsing, mapping, and HTTP concerns in their existing classes. Do not share mutable XML parsers or transformers between requests.
