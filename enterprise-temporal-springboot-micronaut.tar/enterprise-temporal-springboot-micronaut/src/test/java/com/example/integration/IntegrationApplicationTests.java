package com.example.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = {
        "spring.temporal.connection.target=localhost:7233",
        "spring.temporal.workers[0].task-queue=integration-workflow-tq",
        "spring.temporal.workers[0].name=test-worker"
})
class IntegrationApplicationTests {
    @Test void contextLoads() {}
}
