package com.example.integration.api;

import com.example.integration.model.IntegrationRequest;
import com.example.integration.model.IntegrationResponse;
import com.example.integration.temporal.workflow.IntegrationWorkflow;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowOptions;
import io.temporal.client.WorkflowStub;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/integrations")
public class IntegrationController {
    private final WorkflowClient workflowClient;

    public IntegrationController(WorkflowClient workflowClient) {
        this.workflowClient = workflowClient;
    }

    @PostMapping
    public ResponseEntity<IntegrationResponse> execute(@Valid @RequestBody IntegrationRequest request) {
        String workflowId = "integration-" + request.requestId() + "-" + UUID.randomUUID();
        IntegrationWorkflow workflow = workflowClient.newWorkflowStub(
                IntegrationWorkflow.class,
                WorkflowOptions.newBuilder()
                        .setWorkflowId(workflowId)
                        .setTaskQueue("integration-workflow-tq")
                        .setWorkflowExecutionTimeout(Duration.ofMinutes(2))
                        .build());

        IntegrationResponse result = WorkflowStub.fromTyped(workflow).execute(request);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{workflowId}")
    public ResponseEntity<Map<String, Object>> status(@PathVariable String workflowId) {
        var stub = workflowClient.newUntypedWorkflowStub(workflowId);
        var description = stub.describe();
        return ResponseEntity.ok(Map.of(
                "workflowId", workflowId,
                "status", description.getStatus().name(),
                "runId", description.getWorkflowExecution().getRunId()));
    }
}
