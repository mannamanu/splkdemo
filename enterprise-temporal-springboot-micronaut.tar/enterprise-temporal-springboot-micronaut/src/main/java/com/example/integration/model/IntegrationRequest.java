package com.example.integration.model;

import jakarta.validation.constraints.NotBlank;

public record IntegrationRequest(
        @NotBlank String requestId,
        @NotBlank String payload
) {}
