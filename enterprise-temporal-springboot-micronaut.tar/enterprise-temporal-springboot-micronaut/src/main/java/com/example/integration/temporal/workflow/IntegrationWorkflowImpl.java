package com.example.integration.temporal.workflow;

import com.example.integration.model.IntegrationRequest;
import com.example.integration.model.IntegrationResponse;
import com.example.integration.model.ServiceResult;
import com.example.integration.temporal.activity.IntegrationActivities;
import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.workflow.Async;
import io.temporal.workflow.Promise;
import io.temporal.workflow.Workflow;
import io.temporal.spring.boot.WorkflowImpl;

import java.time.Duration;

@WorkflowImpl(taskQueues = "integration-workflow-tq")
public class IntegrationWorkflowImpl implements IntegrationWorkflow {
    private static final ActivityOptions OPTIONS = ActivityOptions.newBuilder()
            .setStartToCloseTimeout(Duration.ofSeconds(10))
            .setRetryOptions(RetryOptions.newBuilder()
                    .setInitialInterval(Duration.ofSeconds(1))
                    .setBackoffCoefficient(2.0)
                    .setMaximumAttempts(3)
                    .build())
            .build();

    private final IntegrationActivities activities =
            Workflow.newActivityStub(IntegrationActivities.class, OPTIONS);

    @Override
    public IntegrationResponse execute(IntegrationRequest request) {
        Workflow.getLogger(IntegrationWorkflowImpl.class)
                .info("Starting workflow for requestId={}", request.requestId());

        Promise<ServiceResult> validator = Async.function(
                activities::validate, request.requestId(), request.payload());
        Promise<ServiceResult> auth = Async.function(
                activities::authorize, request.requestId());

        Promise.allOf(validator, auth).get();

        ServiceResult v = validator.get();
        ServiceResult a = auth.get();
        String status = "OK".equalsIgnoreCase(v.status()) && "AUTHORIZED".equalsIgnoreCase(a.status())
                ? "COMPLETED" : "REJECTED";
        return new IntegrationResponse(request.requestId(), Workflow.getInfo().getWorkflowId(),
                v.status(), a.status(), status);
    }
}
