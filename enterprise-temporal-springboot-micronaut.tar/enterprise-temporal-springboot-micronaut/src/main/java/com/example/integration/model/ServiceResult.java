package com.example.integration.model;

public record ServiceResult(String service, String status, String message) {}
