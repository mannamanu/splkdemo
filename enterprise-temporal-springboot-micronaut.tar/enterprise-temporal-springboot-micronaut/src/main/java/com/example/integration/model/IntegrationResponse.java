package com.example.integration.model;

public record IntegrationResponse(
        String requestId,
        String workflowId,
        String validatorStatus,
        String authStatus,
        String status
) {}
