package com.example.integration.service;

import com.example.integration.config.IntegrationProperties;
import com.example.integration.model.ServiceResult;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class DownstreamClient {
    private final RestClient validator;
    private final RestClient auth;

    public DownstreamClient(IntegrationProperties p, RestClient.Builder builder) {
        this.validator = builder.baseUrl(p.validatorUrl()).build();
        this.auth = builder.baseUrl(p.authUrl()).build();
    }

    public ServiceResult validate(String requestId, String payload) {
        return validator.post().uri("/validate")
                .body(new Payload(requestId, payload)).retrieve().body(ServiceResult.class);
    }

    public ServiceResult authorize(String requestId) {
        return auth.post().uri("/authorize")
                .body(new AuthRequest(requestId)).retrieve().body(ServiceResult.class);
    }

    record Payload(String requestId, String payload) {}
    record AuthRequest(String requestId) {}
}
