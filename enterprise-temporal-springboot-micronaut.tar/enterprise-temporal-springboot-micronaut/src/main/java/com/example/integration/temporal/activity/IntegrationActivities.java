package com.example.integration.temporal.activity;

import com.example.integration.model.ServiceResult;
import io.temporal.activity.ActivityInterface;
import io.temporal.activity.ActivityMethod;

@ActivityInterface
public interface IntegrationActivities {
    @ActivityMethod(name = "validate-request")
    ServiceResult validate(String requestId, String payload);

    @ActivityMethod(name = "authorize-request")
    ServiceResult authorize(String requestId);
}
