package com.example.integration.temporal.workflow;

import com.example.integration.model.IntegrationRequest;
import com.example.integration.model.IntegrationResponse;
import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface IntegrationWorkflow {
    @WorkflowMethod
    IntegrationResponse execute(IntegrationRequest request);
}
