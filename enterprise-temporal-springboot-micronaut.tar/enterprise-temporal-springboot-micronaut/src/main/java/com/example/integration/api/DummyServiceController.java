package com.example.integration.api;

import com.example.integration.model.ServiceResult;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dummy")
public class DummyServiceController {
    @PostMapping("/validate")
    public ServiceResult validate(@RequestBody Object ignored) {
        return new ServiceResult("validator", "OK", "Validation passed");
    }

    @PostMapping("/authorize")
    public ServiceResult authorize(@RequestBody Object ignored) {
        return new ServiceResult("auth", "AUTHORIZED", "Authorization passed");
    }
}
