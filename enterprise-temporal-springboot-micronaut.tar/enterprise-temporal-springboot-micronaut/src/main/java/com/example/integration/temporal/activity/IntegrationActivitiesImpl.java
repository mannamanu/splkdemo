package com.example.integration.temporal.activity;

import com.example.integration.model.ServiceResult;
import com.example.integration.service.DownstreamClient;
import io.temporal.spring.boot.ActivityImpl;
import org.springframework.stereotype.Component;

@Component
@ActivityImpl(taskQueues = "integration-workflow-tq")
public class IntegrationActivitiesImpl implements IntegrationActivities {
    private final DownstreamClient client;

    public IntegrationActivitiesImpl(DownstreamClient client) {
        this.client = client;
    }

    @Override
    public ServiceResult validate(String requestId, String payload) {
        return client.validate(requestId, payload);
    }

    @Override
    public ServiceResult authorize(String requestId) {
        return client.authorize(requestId);
    }
}
