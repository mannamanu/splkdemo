package com.example.integration.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "integration")
public record IntegrationProperties(
        String validatorUrl,
        String authUrl,
        int connectTimeoutMs,
        int readTimeoutMs
) {}
