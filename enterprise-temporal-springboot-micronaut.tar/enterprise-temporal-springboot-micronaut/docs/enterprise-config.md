# Enterprise configuration model

| Concern | DEV | QA | PROD |
|---|---|---|---|
| Spring profile | dev | qa | prod |
| Temporal namespace | integration-dev | integration-qa | integration-prod |
| Temporal endpoint | dev cluster | QA cluster | HA cluster / Temporal Cloud |
| Service endpoints | Docker/K8s | QA service DNS | production service DNS |
| Secrets | local env / dev secret | secret manager | enterprise secret manager |
| TLS | optional local | required | required |
| Health details | visible | hidden | hidden |
| Logs | INFO | INFO | INFO for app, WARN root |
| Scaling | 1+ | 2+ | HPA / workload-based |

## Environment variables

`TEMPORAL_ADDRESS`, `TEMPORAL_NAMESPACE`, `VALIDATOR_URL`, `AUTH_URL`, `TEMPORAL_WORKFLOW_POLLERS`, `TEMPORAL_ACTIVITY_POLLERS`, `SERVER_PORT`, and timeout settings are externalized.

For production, use secret references rather than literal values. The sample intentionally does not include credentials, OAuth secrets, API keys, or certificates.
