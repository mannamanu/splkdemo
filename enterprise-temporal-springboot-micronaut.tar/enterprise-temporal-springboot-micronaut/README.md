# Enterprise Temporal + Spring Boot + Micronaut Integration Sample

A runnable reference implementation for an enterprise integration service:

**Client → Gravitee → Spring Boot Controller → Temporal Workflow → Validator + Auth Activities → response**

The application uses the Temporal Spring Boot starter and includes Micronaut's Spring Boot integration so Micronaut components can be introduced without replacing the Spring programming model. Micronaut documents this integration as a way to run Spring applications with Micronaut/AOT infrastructure and expose Micronaut beans to Spring. 

## What is included

- Java 21 / Spring Boot 3.5.2
- Temporal Java SDK 1.38.0
- Temporal Spring Boot starter
- Micronaut Spring Boot starter 5.1.0
- REST controller with validation
- Temporal workflow with two parallel activities
- Dummy Validator and Auth downstream services
- Retry/backoff policy for activities
- Temporal workflow execution timeout
- Spring Boot Actuator health/readiness/liveness/metrics endpoints
- Dockerfile and Docker Compose
- DEV / QA / PROD profile configuration
- PostgreSQL-backed Temporal server for local enterprise-shaped testing
- Temporal UI

## Run everything with Docker

```bash
docker compose up --build
```

Then:

- Integration API: http://localhost:8080
- Health: http://localhost:8080/actuator/health
- Readiness: http://localhost:8080/actuator/health/readiness
- Liveness: http://localhost:8080/actuator/health/liveness
- Temporal UI: http://localhost:8233

Test the workflow:

```bash
curl -X POST http://localhost:8080/api/v1/integrations \
  -H 'Content-Type: application/json' \
  -d '{"requestId":"REQ-1001","payload":"sample-MISMO-or-DU-payload"}'
```

Expected response:

```json
{
  "requestId": "REQ-1001",
  "workflowId": "integration-REQ-1001-<uuid>",
  "validatorStatus": "OK",
  "authStatus": "AUTHORIZED",
  "status": "COMPLETED"
}
```

## Local Maven run

If Temporal is running locally on `localhost:7233`:

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

For the sample Docker Compose setup, keep `TEMPORAL_ADDRESS=temporal:7233` inside the container network.

## DEV / QA / PROD

Profiles are deliberately environment-neutral. Runtime-specific endpoints and secrets are injected through environment variables or your deployment platform's secret manager.

```bash
# DEV
SPRING_PROFILES_ACTIVE=dev
TEMPORAL_ADDRESS=temporal-dev:7233
TEMPORAL_NAMESPACE=integration-dev

# QA
SPRING_PROFILES_ACTIVE=qa
TEMPORAL_ADDRESS=temporal-qa:7233
TEMPORAL_NAMESPACE=integration-qa

# PROD
SPRING_PROFILES_ACTIVE=prod
TEMPORAL_ADDRESS=temporal-prod:7233
TEMPORAL_NAMESPACE=integration-prod
VALIDATOR_URL=https://validator.prod.example
AUTH_URL=https://auth.prod.example
```

Do not put production credentials in `application-prod.yml`; use Kubernetes Secrets, AWS Secrets Manager, Vault, or your organization's approved secret-management platform.

## Enterprise deployment recommendation

For development, API + Temporal Worker can run in the same Spring Boot process. For QA/PROD, consider separate deployments:

```text
Gravitee
   |
   v
Integration API pods
   |
   | Temporal Client
   v
Temporal Cluster
   |
   v
Integration Worker pods
   |
   +--> Validator
   +--> Auth
```

This allows the HTTP API tier and Temporal Worker tier to scale independently. The Temporal Java Spring Boot integration supports automatic worker registration/configuration, and Temporal's own Spring Boot demo shows workflow/activity auto-discovery and worker configuration through `spring.temporal.workers`.

## Important production hardening

1. Use Temporal Cloud or a properly HA-managed Temporal cluster rather than the single-node Docker setup.
2. Enable TLS/mTLS for Temporal connections and service-to-service traffic.
3. Use separate Temporal namespaces for DEV/QA/PROD.
4. Keep application business data outside Temporal persistence; Temporal stores workflow execution history/state while your application database stores domain data.
5. Add OpenTelemetry tracing and propagate correlation/workflow IDs.
6. Configure Kubernetes liveness/readiness probes against Actuator endpoints.
7. Use resource requests/limits and horizontal pod autoscaling.
8. Store secrets outside Git and outside YAML files.
9. Add idempotency keys to downstream activities.
10. Define activity retry policies per downstream dependency; do not blindly retry non-idempotent operations.
11. Add contract/integration tests for Validator/Auth and Temporal workflow tests using Temporal's test framework.
12. Use a dedicated task queue per workload/domain when scaling or isolating workloads.

## Architecture

```text
                       +-------------------+
                       | External Client   |
                       +---------+---------+
                                 |
                                 v
                       +-------------------+
                       | Gravitee Gateway  |
                       | Auth / Rate Limit |
                       +---------+---------+
                                 |
                                 v
                +----------------------------------+
                | Spring Boot Integration API      |
                |                                  |
                | REST Controller                  |
                |        |                         |
                |        v                         |
                | Temporal Client                  |
                +--------+-------------------------+
                         |
                         v
                +----------------------------------+
                | Temporal Cluster                  |
                | Workflow State / History          |
                +----------------+-----------------+
                                 |
                                 v
                +----------------------------------+
                | Temporal Worker                   |
                | IntegrationWorkflow               |
                +------------+-----------+----------+
                             |           |
                         Activity      Activity
                             |           |
                             v           v
                       +---------+   +---------+
                       |Validator|   |  Auth   |
                       +---------+   +---------+
```

## Why the workflow calls services through Activities

The Workflow code is deterministic. Network calls, authentication calls, database access, timestamps, randomness, and other side effects belong in Activities. This sample therefore uses:

- `IntegrationWorkflow` for orchestration
- `IntegrationActivities` for side effects
- `DownstreamClient` for REST calls
- retry/timeout policies at the Activity boundary

## Version note

The project pins exact dependency versions so builds are reproducible. Review and update the pinned versions through your enterprise dependency-management process before promoting to production.
