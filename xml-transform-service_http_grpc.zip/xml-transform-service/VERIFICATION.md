# Verification

Revision: global exception handling and external XML assets, 2026-10-02.

Executed with Amazon Corretto 25.0.4 and Maven 3.9.11:

- `mvn -B -ntp verify`: 40 tests, zero failures/errors/skips; executable Spring Boot
  JAR packaged. Final verification used cached dependencies in offline mode.
- Mockito service/cache/controller/gRPC tests and real XML/XSD/XSLT security tests.
- HTTP unexpected exceptions produce safe ProblemDetail, stable codes, correlation
  IDs and no-store responses, including requests accepting XML.
- HTTP framework errors retain 405/415 and Allow headers; busy responses retain
  Retry-After. Invalid correlation IDs are replaced.
- gRPC synchronous failures and asynchronous close handling sanitize descriptions
  and metadata. Duplicate close is suppressed; domain codes survive mapping.
- Live HTTP/gRPC authentication, authorization and transformation parity tests on
  random local ports. Authentication failures have consistent safe error metadata.
- External filesystem assets compile from a temporary directory; missing assets
  fail startup. Real transformation tests use the project-root xml-assets directory.
- RSA JWT validation, prohibited XML, size/depth/concurrency limits, tenant-scoped
  caching, defensive copies and gRPC readiness coverage retained.
- ZIP integrity and source contents checked; build output excluded from source ZIP.

The restricted execution sandbox blocks local server sockets. The integration suite
was run with local socket access; tests were not disabled or weakened. Maven downloads
used the environment's proxy and trusted CA configuration, not disabled TLS checks.
These environment-specific build settings are not included in the source package.

Not executed for this revision:

- Docker build/Compose execution (no Docker daemon used).
- Terraform provider-backed validation/plan/apply, ECR publication, Route53/ALB routing,
  live identity-provider requests, or any AWS deployment.
- Native Windows/PowerShell helper execution, load/soak tests or vulnerability audit.

Docker and AWS configurations are included as starter configurations. See README.md
and infra/README.md for prerequisites and deployment-specific settings.
