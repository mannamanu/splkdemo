<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:n="urn:example:normalized:v1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:o="urn:example:order:v1" exclude-result-prefixes="o">
  <xsl:output method="xml" encoding="UTF-8" indent="yes" />
  <xsl:template match="/o:Order">
    <n:NormalizedOrder version="1">
      <n:id>
        <xsl:value-of select="o:OrderId" />
      </n:id>
      <n:customer>
        <xsl:value-of select="normalize-space(o:CustomerName)" />
      </n:customer>
      <n:total currency="{o:Currency}">
        <xsl:value-of select="o:Amount" />
      </n:total>
    </n:NormalizedOrder>
  </xsl:template>
</xsl:stylesheet>