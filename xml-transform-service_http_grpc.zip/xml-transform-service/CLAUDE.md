# Claude repository instructions

Read and follow AGENTS.md and README.md before making changes. They define the
architecture, security constraints, test commands and deployment boundaries.
Use docs/AI-USAGE.md and .github/prompts/add-transformation.prompt.md as task templates.
The .github/agents files are optional role descriptions; no runtime AI API/key is needed.
