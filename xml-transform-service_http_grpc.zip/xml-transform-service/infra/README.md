# AWS Terraform starter for the single service

This is separate from the local Docker setup. It uses existing VPC/subnets, an
issued ACM certificate in the deployment region and an existing Route 53 hosted
zone. It does not provision networking, an identity provider or certificates.
No resources were deployed when this package was generated.

## Topology

One ECR repository -> one ECS/Fargate service (1 vCPU, 2 GiB per task).
One HTTPS ALB listener on 443 routes:

- HTTP `/api/v1/...` and health/metrics -> HTTP target group, container8080.
- `/xml.v1.TransformationService/*` -> GRPC target group, container9090 (HTTP/2).

Route 53 aliases the ALB. Both listeners belong to the SAME Java process/container.
ALB's gRPC health check calls `/grpc.health.v1.Health/Check` with matcher0. Our custom
Check returns a nonzero status when Spring is not ready, unlike a health implementation
that returns an OK gRPC status with a NOT_SERVING message body. The health method is
not routed externally by the gRPC listener rule. Server reflection is not enabled.

Default ALB is internal; clients need VPC/VPN/DNS connectivity. Task ports permit
inbound only from the ALB security group. TLS ends at ALB and backends are plaintext
within private subnets. Add end-to-end encryption if your platform requires it.

## Prerequisites and inputs

Install Terraform >=1.10, AWS CLIv2, Docker/Buildx and PowerShell7. Authenticate with
your organization's AWS SSO role (no embedded access keys):

```powershell
aws configure sso --profile my-dev
aws sso login --profile my-dev
$env:AWS_PROFILE='my-dev'
aws sts get-caller-identity
```

The role must manage the declared ECR/ECS/ELB/Route53/IAM/log/security-group resources,
pass task/execution roles and push images. Application task role has no AWS API
permissions. ECS may need its service-linked role on first use.

Use private task subnets across two AZs with access to ECR, S3 image layers,
CloudWatch Logs and the JWT JWKS endpoint (NAT or appropriate VPC endpoints/routes).
The IdP must be reachable to validate tokens and refresh signing keys. Existing
VPC DNS must resolve internal and external dependency hostnames.

ALB subnets must span two AZs. An internal ALB can use private subnets; an internet
facing ALB needs public subnets and a public hosted zone. Configure approved client
CIDRs. Certificates must cover the hostname, be issued and exist in the same region.
Internal DNS names may require a private/imported certificate and client trust;
public ACM certificates require a publicly validatable domain.

## Deploy (commands from repository root)

```powershell
Copy-Item infra/registry/terraform.tfvars.example infra/registry/terraform.tfvars
Copy-Item infra/service/terraform.tfvars.example infra/service/terraform.tfvars
```

Edit both files, replacing every placeholder; use the same name/account/region.
Set JWT issuer, public JWK URL and audience in the service file. The token must
contain scope xml:transform. Do not supply the local profile in AWS. No secret
values are needed in these Terraform variables; the JWT private key stays at the IdP.

First create the image repository (separate state):

```powershell
terraform -chdir=infra/registry init
terraform -chdir=infra/registry validate
terraform -chdir=infra/registry plan
terraform -chdir=infra/registry apply
```

Build/test/push the image. This is a real ECR publication when you run it:

```powershell
pwsh -File scripts/Publish-Image.ps1 -Region us-east-1
```

The script checks the AWS account/region against the registry, builds linux/amd64,
runs Dockerfile tests, pushes a unique immutable tag and writes the resolved digest
to `infra/service/image.auto.tfvars.json`. It does not apply Terraform.

```powershell
terraform -chdir=infra/service init
terraform -chdir=infra/service validate
terraform -chdir=infra/service plan -out=release.tfplan
terraform -chdir=infra/service show release.tfplan
# Applies the exact saved plan immediately. Run only after reviewing it:
terraform -chdir=infra/service apply release.tfplan
terraform -chdir=infra/service output
```

Fargate waits for steady state and enables circuit-breaker rollback. Inspect ECS
service events and confirm its task definition matches the Terraform output: a
stable service could be running an earlier revision after a rollback. The first
failed deployment may have no prior stable revision to restore.

Verify with an IdP-issued access token. HTTP and gRPC use the SAME DNS name, port443:

```powershell
curl.exe -i https://xml.dev.example.com/actuator/health/readiness
curl.exe -i -X POST https://xml.dev.example.com/api/v1/profiles/order-v1/transform `
  -H "Authorization: Bearer $env:ACCESS_TOKEN" `
  -H "Content-Type: application/xml" --data-binary "@samples/order.xml"

$env:GRPC_BEARER_TOKEN=$env:ACCESS_TOKEN
.\scripts\Invoke-Grpc.ps1 -Target 'xml.dev.example.com:443' -Tls
```

Use the appropriate secure process to obtain/set ACCESS_TOKEN; don't commit tokens.
If using an internal ALB these calls require internal network connectivity. The
container itself uses HTTP/h2c; TLS verification is performed against the ALB hostname.

## Production integration and state

This starter omits WAF/rate-limit policies, autoscaling, alarms, centralized traces,
long-term audit retention and disaster recovery. Add those with your platform team.
Defaults are a baseline, not validated throughput sizing. Consider 2+ tasks for
availability. Caches are per process and are not synchronized across tasks.
ALB/DNS health can fail open when every target is unhealthy; retain application checks.
Task outbound rules are broad initially; tighten them to approved dependencies.

Registry and service each have an independent state. Use encrypted, versioned S3
remote state with locking for team work. Add `terraform { backend "s3" {} }` to
each root, create/use an approved state bucket and initialize distinct keys:

```powershell
terraform -chdir=infra/registry init -migrate-state `
  -backend-config='bucket=YOUR-STATE-BUCKET' `
  -backend-config='key=xml/dev/registry.tfstate' `
  -backend-config='region=us-east-1' `
  -backend-config='encrypt=true' -backend-config='use_lockfile=true'
```

Repeat for service using key xml/dev/service.tfstate. Use separate keys/config for
QA/PROD. Commit provider lock files after init. Never commit state, plans, tokens or
actual tfvars. For an isolated first test local state works but must be protected.
Do not reuse the previous monorepo/Temporal deployment's state with this new layout.

For updates: republish a new image, review a new plan and apply it. To roll back,
select a retained previous digest in image.auto.tfvars.json and plan/apply again.
ECR force_delete=false preserves images until you deliberately remove them.

Applying creates billable resources. For deliberate cleanup, review
`terraform -chdir=infra/service plan -destroy` then run destroy on that root. This
also removes its API DNS record/log group. Registry images/state are separate;
existing VPC/certificate/zone/IdP are not deleted. Preserve required logs first.

References:
- https://docs.aws.amazon.com/elasticloadbalancing/latest/application/load-balancer-target-groups.html
- https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-to-elb-load-balancer.html
- https://docs.aws.amazon.com/AmazonECR/latest/userguide/vpc-endpoints.html
