variable "vpc_id" { type = string }
variable "task_subnet_ids" { type = list(string) }
variable "alb_subnet_ids" { type = list(string) }
variable "allowed_client_cidrs" { type = set(string) }
variable "certificate_arn" { type = string }
variable "hosted_zone_id" { type = string }
variable "domain_name" { type = string }
variable "internal_alb" {
  type    = bool
  default = true
}
variable "image_uri" {
  type = string
  validation {
    condition     = can(regex("@sha256:[0-9a-f]{64}$", var.image_uri))
    error_message = "Use a digest-pinned ECR image URI."
  }
}
variable "desired_count" {
  type    = number
  default = 1
  validation {
    condition     = var.desired_count >= 1 && floor(var.desired_count) == var.desired_count
    error_message = "desired_count must be a positive integer."
  }
}
variable "jwt_issuer" {
  type = string
  validation {
    condition     = startswith(var.jwt_issuer, "https://")
    error_message = "JWT issuer must use HTTPS."
  }
}
variable "jwt_jwk_set_uri" {
  type = string
  validation {
    condition     = startswith(var.jwt_jwk_set_uri, "https://")
    error_message = "JWK URL must use HTTPS."
  }
}
variable "jwt_audience" { type = string }
variable "result_cache_enabled" {
  type    = bool
  default = false
}
