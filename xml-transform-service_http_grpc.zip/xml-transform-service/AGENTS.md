# Instructions for coding agents

This is one Spring Boot 4 / Maven / JDK 25 service. HTTP and gRPC share the same
TransformationService and XmlEngine. Do not introduce Temporal, extra services,
a database, a remote cache, or a new framework without an explicit requirement.

## Before editing

Read README.md, docs/ARCHITECTURE.md, the affected API contract and relevant tests.
Check git status; preserve unrelated user changes. State intended scope briefly.
Follow existing package boundaries. Generated Java under target/ must not be edited.

## Implementation boundaries

- HTTP and gRPC adapters translate requests/errors only; business logic lives in core.
- XSD validates; XSLT transforms. Profiles and resource paths are server-owned allowlists.
- Do not accept uploaded XSD/XSLT, arbitrary paths, URLs or XSLT document() sources.
- Keep DOCTYPE/entities/XInclude/external schema and stylesheet access disabled.
- Reuse Schema/Templates only. Create Validator/Transformer/DOM per request.
- Preserve input/output/depth/concurrency bounds. Do not bypass JWT issuer/audience,
  expiry, signature, scope or tenant checks, or log XML/token contents.
- Result caching stays optional, bounded, short-lived and keyed by authenticated tenant,
  profile version and input digest. Do not create static/global unbounded payload maps.
- New profiles need new versioned XSD/XSLT fixtures, registry changes and tests.
- HTTP and gRPC must enforce equivalent authorization and error semantics.

## Tests and review

Run mvn -B -ntp verify with JDK25. Prefer JUnit5/Mockito unit tests without Spring;
retain transport/security integration tests for actual wiring. Add meaningful failure
cases: schema errors, prohibited XML, size limits, cache isolation and unknown profiles.
Do not weaken assertions or skip tests to obtain a passing build. Report exact checks
run and any blockers. Update samples, .proto/HTTP examples and README together.

Terraform plan/apply, image publication, DNS changes and credentials require explicit
user authorization for that action. A request to change code alone does not authorize
cloud deployment. Do not commit secrets, state, plans, generated binaries or API tokens.

## Error handling and external assets

Use ErrorCatalog for public messages; never return exception.getMessage() or rich
exception trailers to clients. Keep HTTP and gRPC mappings equivalent. Domain logic
throws ServiceFailure; adapters rely on global handlers. New async gRPC tasks must
report failures with observer.onError. Preserve authentication handlers, correlation
IDs, no-store and framework headers. Test sanitized unexpected failures and metadata.
XSD/XSLT files are under xml-assets, configured by XML_ASSETS_DIR and mounted read-only
for local Docker. Compile at startup; changes require restart and a profile version
change when contracts change. Never silently fall back to stale classpath resources.
