package com.example.xml.grpc;
import com.example.xml.core.*;
import com.example.xml.proto.*;
import com.google.protobuf.ByteString;
import io.grpc.*;
import io.grpc.inprocess.*;
import com.example.xml.security.TokenPolicy;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class TransformationGrpcTest {
 @Mock TransformationService service;
 Server server;ManagedChannel channel;
 TransformationServiceGrpc.TransformationServiceBlockingStub client;
 @BeforeEach void start() throws Exception {
  String name=InProcessServerBuilder.generateName();
  server=InProcessServerBuilder.forName(name).directExecutor().addService(ServerInterceptors.interceptForward(new TransformationGrpcEndpoint(service),new GrpcErrors(),new GrpcAuthentication(new TokenPolicy(null,true)))).build().start();
  channel=InProcessChannelBuilder.forName(name).directExecutor().build();client=TransformationServiceGrpc.newBlockingStub(channel);
 }
 @AfterEach void stop() {channel.shutdownNow();server.shutdownNow();}
 @Test void protobufTransportUsesSharedService() {
  when(service.transform(eq("local"),eq("order-v1"),any())).thenReturn("<result/>".getBytes());
  var reply=client.transform(XmlRequest.newBuilder().setProfile("order-v1").setXml(ByteString.copyFromUtf8("<Order/>")).build());
  assertEquals("<result/>",reply.getXml().toStringUtf8());
 }
 @Test void invalidSchemaMapsToInvalidArgument() {
  doThrow(new ServiceFailure(ServiceFailure.Code.SCHEMA_INVALID,"Invalid XML")).when(service).validate(anyString(),any());
  assertEquals(Status.Code.INVALID_ARGUMENT,assertThrows(StatusRuntimeException.class,()->client.validate(XmlRequest.newBuilder().setProfile("order-v1").build())).getStatus().getCode());
 }
 @Test void busyMapsToResourceExhausted() {
  when(service.transform(any(),any(),any())).thenThrow(new ServiceFailure(ServiceFailure.Code.BUSY,"Busy"));
  assertEquals(Status.Code.RESOURCE_EXHAUSTED,assertThrows(StatusRuntimeException.class,()->client.transform(XmlRequest.newBuilder().build())).getStatus().getCode());
 }

 @Test void unexpectedFailureIsSafeAndHasTrailers() {
  when(service.transform(any(), any(), any())).thenThrow(new IllegalStateException("private XML secret"));
  var headers = new Metadata(); headers.put(GrpcErrors.CORRELATION, "grpc-test-123");
  var correlated = client.withInterceptors(io.grpc.stub.MetadataUtils.newAttachHeadersInterceptor(headers));
  var error = assertThrows(StatusRuntimeException.class, () -> correlated.transform(XmlRequest.getDefaultInstance()));
  assertEquals(Status.Code.INTERNAL, error.getStatus().getCode());
  assertEquals("Request failed", error.getStatus().getDescription());
  assertEquals("INTERNAL", error.getTrailers().get(GrpcErrors.CODE));
  assertEquals("grpc-test-123", error.getTrailers().get(GrpcErrors.CORRELATION));
 }
 @Test void schemaFailureHasStableCodeAndSafeMessage() {
  doThrow(new ServiceFailure(ServiceFailure.Code.SCHEMA_INVALID, "secret XML content")).when(service).validate(any(), any());
  var error = assertThrows(StatusRuntimeException.class, () -> client.validate(XmlRequest.getDefaultInstance()));
  assertEquals("SCHEMA_INVALID", error.getTrailers().get(GrpcErrors.CODE));
  assertEquals("XML does not match the input schema", error.getStatus().getDescription());
 }
}
