package com.example.xml.security;
import org.junit.jupiter.api.*;
import org.springframework.security.oauth2.jwt.*;
import java.time.Instant;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class TokenPolicyTest {
 @Test void missingBearerRejected() { assertThrows(JwtException.class,()->new TokenPolicy(mock(JwtDecoder.class),false).authenticate(null)); }
 @Test void insufficientScopeRejected() {
  var decoder=mock(JwtDecoder.class);when(decoder.decode("test")).thenReturn(jwt("read"));
  assertThrows(TokenPolicy.ScopeDenied.class,()->new TokenPolicy(decoder,false).authenticate("Bearer test"));
 }
 @Test void signedTenantDrivesCachePartition() {
  var decoder=mock(JwtDecoder.class);when(decoder.decode("test")).thenReturn(jwt("xml:transform"));
  assertEquals("tenant-a",new TokenPolicy(decoder,false).authenticate("Bearer test"));
 }
 @Test void anonymousModeRequiresExplicitLocalProfile() {
  var env=new org.springframework.mock.env.MockEnvironment();
  assertThrows(IllegalStateException.class,()->new SecurityConfiguration().jwtDecoder("none","","","aud",env));
 }
 private Jwt jwt(String scope) {return Jwt.withTokenValue("test").header("alg","RS256").subject("user").claim("tenant_id","tenant-a").claim("scope",scope).issuedAt(Instant.now()).expiresAt(Instant.now().plusSeconds(60)).build();}
}
