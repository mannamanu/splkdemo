package com.example.xml.core;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.nio.file.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;
class XmlArtifactsTest {
 @TempDir Path directory;
 @Test void externalDirectoryCompilesAndMissingAssetsFailStartup() throws Exception {
  assertThrows(IllegalStateException.class, () -> new XmlArtifacts(new SimpleMeterRegistry(), directory.toString()));
  var profile = Files.createDirectory(directory.resolve("order-v1"));
  for (String name : new String[]{"order-input.xsd", "order-output.xsd", "order-to-normalized.xsl"})
   Files.copy(Path.of("xml-assets/order-v1", name), profile.resolve(name));
  var artifacts = new XmlArtifacts(new SimpleMeterRegistry(), directory.toString());
  assertNotNull(artifacts.input()); assertNotNull(artifacts.output()); assertNotNull(artifacts.stylesheet());
 }
}
