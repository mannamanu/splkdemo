package com.example.xml;
import com.example.xml.grpc.GrpcServerLifecycle;
import com.example.xml.proto.*;
import com.google.protobuf.ByteString;
import io.grpc.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,properties={"spring.profiles.active=local","app.grpc.port=0"})
class ApplicationIntegrationTest {
 @Autowired Environment env;
 @Autowired GrpcServerLifecycle grpc;
 @Test void sameXmlOverHttpAndGrpcHasSameOutput() throws Exception {
  byte[] xml=Files.readAllBytes(Path.of("samples/order.xml"));
  var request=HttpRequest.newBuilder(URI.create("http://localhost:"+env.getProperty("local.server.port")+"/api/v1/profiles/order-v1/transform"))
   .header("Content-Type","application/xml").POST(HttpRequest.BodyPublishers.ofByteArray(xml)).build();
  var response=HttpClient.newHttpClient().send(request,HttpResponse.BodyHandlers.ofByteArray());
  assertEquals(200,response.statusCode());
  var channel=ManagedChannelBuilder.forAddress("localhost",grpc.boundPort()).usePlaintext().build();
  try {
   var reply=TransformationServiceGrpc.newBlockingStub(channel).withDeadlineAfter(5,java.util.concurrent.TimeUnit.SECONDS)
    .transform(XmlRequest.newBuilder().setProfile("order-v1").setXml(ByteString.copyFrom(xml)).build());
   assertArrayEquals(response.body(),reply.getXml().toByteArray());
  } finally {channel.shutdownNow();}
 }
}
