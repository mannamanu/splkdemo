package com.example.xml.core;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class TransformationServiceTest {
 @Mock XmlEngine engine;
 private TransformationService service(boolean cache, int concurrent) { return new TransformationService(engine,new SimpleMeterRegistry(),cache,1048576,60,1024,concurrent); }
 @Test void repeatedInputHitsCacheAndResponseCannotMutateIt() {
  byte[] xml={1}; when(engine.transform("order-v1",xml)).thenReturn(new byte[]{9});
  var s=service(true,2); var first=s.transform("tenant-a","order-v1",xml); first[0]=0;
  assertEquals(9,s.transform("tenant-a","order-v1",xml)[0]);
  verify(engine,times(1)).transform("order-v1",xml);
 }
 @Test void tenantBoundarySeparatesCachedValues() {
  byte[] xml={1}; when(engine.transform("order-v1",xml)).thenReturn(new byte[]{9});
  var s=service(true,2);s.transform("a","order-v1",xml);s.transform("b","order-v1",xml);
  verify(engine,times(2)).transform("order-v1",xml);
 }
 @Test void disabledResultCacheInvokesEngineEveryTime() {
  byte[] xml={1};when(engine.transform("order-v1",xml)).thenReturn(new byte[]{9});
  var s=service(false,2);s.transform("a","order-v1",xml);s.transform("a","order-v1",xml);
  verify(engine,times(2)).transform("order-v1",xml);
 }
 @Test void failedResultsAreNotCached() {
  byte[] xml={1};when(engine.transform("order-v1",xml)).thenThrow(new ServiceFailure(ServiceFailure.Code.BAD_XML,"Invalid"));
  var s=service(true,2);
  for(int i=0;i<2;i++) assertThrows(ServiceFailure.class,()->s.transform("a","order-v1",xml));
  verify(engine,times(2)).transform("order-v1",xml);
 }
 @Test void oversizedInputNeverReachesEngine() {
  assertEquals(ServiceFailure.Code.TOO_LARGE,assertThrows(ServiceFailure.class,()->service(false,2).transform("a","order-v1",new byte[1025])).code());
  verifyNoInteractions(engine);
 }
 @Test void busyServiceRejectsWithoutQueueing() throws Exception {
  var entered=new CountDownLatch(1);var release=new CountDownLatch(1);byte[] xml={1};
  when(engine.transform("order-v1",xml)).thenAnswer(inv->{entered.countDown();release.await(5,TimeUnit.SECONDS);return new byte[]{9};});
  var s=service(false,1);
  try(var executor=Executors.newSingleThreadExecutor()) {
   var first=executor.submit(()->s.transform("a","order-v1",xml));
   try { assertTrue(entered.await(5,TimeUnit.SECONDS));assertEquals(ServiceFailure.Code.BUSY,assertThrows(ServiceFailure.class,()->s.transform("a","order-v1",xml)).code()); }
   finally {release.countDown();}
   assertEquals(9,first.get(5,TimeUnit.SECONDS)[0]);
  }
 }
}
