package com.example.xml.grpc;
import io.grpc.Status;
import io.grpc.health.v1.*;
import io.grpc.stub.StreamObserver;
import org.junit.jupiter.api.Test;
import org.springframework.boot.availability.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
class GrpcReadinessTest {
 @Test void refusingTrafficReturnsNonzeroGrpcStatusForAlb() {
  var availability=mock(ApplicationAvailability.class);
  when(availability.getReadinessState()).thenReturn(ReadinessState.REFUSING_TRAFFIC);
  @SuppressWarnings("unchecked") StreamObserver<HealthCheckResponse> observer=mock(StreamObserver.class);
  new GrpcReadiness(availability).check(HealthCheckRequest.getDefaultInstance(),observer);
  verify(observer).onError(argThat(error->Status.fromThrowable(error).getCode()==Status.Code.UNAVAILABLE));
  verify(observer,never()).onNext(any());
 }
 @Test void readyReturnsServingAndCompletes() {
  var availability=mock(ApplicationAvailability.class);
  when(availability.getReadinessState()).thenReturn(ReadinessState.ACCEPTING_TRAFFIC);
  @SuppressWarnings("unchecked") StreamObserver<HealthCheckResponse> observer=mock(StreamObserver.class);
  new GrpcReadiness(availability).check(HealthCheckRequest.getDefaultInstance(),observer);
  verify(observer).onNext(argThat(reply->reply.getStatus()==HealthCheckResponse.ServingStatus.SERVING));
  verify(observer).onCompleted();
 }
}
