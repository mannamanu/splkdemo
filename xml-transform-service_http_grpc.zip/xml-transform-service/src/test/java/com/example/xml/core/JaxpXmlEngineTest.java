package com.example.xml.core;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
class JaxpXmlEngineTest {
 private final JaxpXmlEngine engine = new JaxpXmlEngine(new XmlArtifacts(new SimpleMeterRegistry(), "./xml-assets"), 2097152);
 private byte[] sample() throws Exception { return Files.readAllBytes(Path.of("samples/order.xml")); }
 @Test void validatesAndTransforms() throws Exception {
  engine.validate("order-v1", sample());
  var doc = SecureXml.parse(engine.transform("order-v1", sample()));
  assertEquals("NormalizedOrder", doc.getDocumentElement().getLocalName());
  assertEquals("125.50", doc.getElementsByTagNameNS("urn:example:normalized:v1", "total").item(0).getTextContent());
 }
 @Test void invalidAmountIsRejected() throws Exception {
  var ex=assertThrows(ServiceFailure.class, () -> engine.validate("order-v1", Files.readAllBytes(Path.of("samples/invalid-order.xml"))));
  assertEquals(ServiceFailure.Code.SCHEMA_INVALID, ex.code());
 }
 @Test void doctypeAndExternalEntityAreRejected() {
  var xml="<!DOCTYPE Order [<!ENTITY secret SYSTEM 'file:///etc/passwd'>]><Order>&secret;</Order>";
  var ex=assertThrows(ServiceFailure.class, () -> engine.transform("order-v1", xml.getBytes(StandardCharsets.UTF_8)));
  assertEquals(ServiceFailure.Code.BAD_XML, ex.code());
  assertFalse(ex.getMessage().contains("passwd"));
 }
 @Test void deepXmlRejected() {
  byte[] xml=("<a>".repeat(140)+"</a>".repeat(140)).getBytes(StandardCharsets.UTF_8);
  assertEquals(ServiceFailure.Code.BAD_XML, assertThrows(ServiceFailure.class, () -> engine.validate("order-v1", xml)).code());
 }
 @Test void clientCannotChooseAnArbitraryFile() throws Exception {
  assertEquals(ServiceFailure.Code.UNKNOWN_PROFILE, assertThrows(ServiceFailure.class, () -> engine.transform("../../etc/passwd", sample())).code());
 }
 @Test void outputLimitIsEnforced() throws Exception {
  var small = new JaxpXmlEngine(new XmlArtifacts(new SimpleMeterRegistry(), "./xml-assets"), 20);
  assertEquals(ServiceFailure.Code.INTERNAL, assertThrows(ServiceFailure.class, () -> small.transform("order-v1", sample())).code());
 }
 @Test void templatesAreSafeAcrossConcurrentRequests() throws Exception {
  byte[] xml=sample();
  try(var pool=Executors.newFixedThreadPool(4)) {
   var futures=new java.util.ArrayList<Future<byte[]>>();
   for(int i=0;i<20;i++) futures.add(pool.submit(() -> engine.transform("order-v1", xml)));
   for(var result:futures) assertTrue(new String(result.get(10,TimeUnit.SECONDS), StandardCharsets.UTF_8).contains("ORD-1001"));
  }
 }
}
