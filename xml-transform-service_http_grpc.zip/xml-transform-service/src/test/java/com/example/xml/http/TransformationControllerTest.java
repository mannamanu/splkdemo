package com.example.xml.http;
import com.example.xml.core.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
@ExtendWith(MockitoExtension.class)
class TransformationControllerTest {
 @Mock TransformationService service;
 MockMvc mvc;
 @BeforeEach void setup() { mvc=MockMvcBuilders.standaloneSetup(new TransformationController(service,1024)).setControllerAdvice(new ApiErrors()).addFilters(new CorrelationFilter()).build(); }
 @Test void transformDelegatesToSharedService() throws Exception {
  when(service.transform(eq("local"),eq("order-v1"),any())).thenReturn("<result/>".getBytes());
  mvc.perform(post("/api/v1/profiles/order-v1/transform").contentType("application/xml").content("<Order/>"))
   .andExpect(status().isOk()).andExpect(content().string("<result/>")).andExpect(header().string("Cache-Control","no-store"));
 }
 @Test void validateReturnsJson() throws Exception {
  mvc.perform(post("/api/v1/profiles/order-v1/validate").contentType("application/xml").content("<Order/>"))
   .andExpect(status().isOk()).andExpect(jsonPath("$.valid").value(true));
  verify(service).validate(eq("order-v1"),any());
 }
 @Test void validationFailureMapsTo422() throws Exception {
  doThrow(new ServiceFailure(ServiceFailure.Code.SCHEMA_INVALID,"XML does not match the input schema")).when(service).validate(anyString(),any());
  mvc.perform(post("/api/v1/profiles/order-v1/validate").contentType("application/xml").content("<Order/>"))
   .andExpect(status().isUnprocessableEntity()).andExpect(jsonPath("$.code").value("SCHEMA_INVALID"));
 }
 @Test void oversizedBodyRejectedBeforeService() throws Exception {
  mvc.perform(post("/api/v1/profiles/order-v1/transform").contentType("application/xml").content(new byte[1025])).andExpect(status().isPayloadTooLarge());
  verifyNoInteractions(service);
 }
 @Test void wrongContentTypeIs415() throws Exception {
  mvc.perform(post("/api/v1/profiles/order-v1/transform").contentType("application/json").content("{}")).andExpect(status().isUnsupportedMediaType());
 }

 @Test void unexpectedFailureIsSafeAndCorrelated() throws Exception {
  when(service.transform(any(), any(), any())).thenThrow(new IllegalStateException("secret XML and database password"));
  mvc.perform(post("/api/v1/profiles/order-v1/transform").contentType("application/xml")
    .accept("application/xml").header("X-Correlation-ID", "test-123").content("<Order/>"))
   .andExpect(status().isInternalServerError()).andExpect(content().contentType("application/problem+json"))
   .andExpect(jsonPath("$.detail").value("Request failed")).andExpect(jsonPath("$.code").value("INTERNAL"))
   .andExpect(jsonPath("$.correlationId").value("test-123"))
   .andExpect(header().string("X-Correlation-ID", "test-123"));
 }
 @Test void frameworkErrorsKeepStatusAndHeaders() throws Exception {
  mvc.perform(get("/api/v1/profiles/order-v1/transform"))
   .andExpect(status().isMethodNotAllowed()).andExpect(header().exists("Allow"))
   .andExpect(jsonPath("$.code").value("METHOD_NOT_ALLOWED"));
  mvc.perform(post("/api/v1/profiles/order-v1/transform").contentType("application/json").content("{}"))
   .andExpect(status().isUnsupportedMediaType()).andExpect(jsonPath("$.code").value("UNSUPPORTED_MEDIA_TYPE"));
 }
 @Test void busyHasRetryAfterAndSafeMessage() throws Exception {
  doThrow(new ServiceFailure(ServiceFailure.Code.BUSY, "private details")).when(service).validate(any(), any());
  mvc.perform(post("/api/v1/profiles/order-v1/validate").contentType("application/xml").content("<Order/>"))
   .andExpect(status().isServiceUnavailable()).andExpect(header().string("Retry-After", "1"))
   .andExpect(jsonPath("$.detail").value("Processing capacity is temporarily exhausted"));
 }
 @Test void invalidCorrelationIdIsReplaced() throws Exception {
  var result = mvc.perform(get("/api/v1/profiles").header("X-Correlation-ID", "bad id!"))
   .andExpect(status().isOk()).andReturn();
  org.junit.jupiter.api.Assertions.assertDoesNotThrow(() -> java.util.UUID.fromString(result.getResponse().getHeader("X-Correlation-ID")));
 }
}
