package com.example.xml.grpc;

import com.example.xml.core.ServiceFailure;
import io.grpc.*;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GrpcErrorsTest {
 @SuppressWarnings("unchecked")
 @Test void asynchronousCloseSanitizesDescriptionAndTrailers() {
  ServerCall<String, String> call = mock(ServerCall.class);
  var supplied = new Metadata(); supplied.put(GrpcErrors.CORRELATION, "async-123");
  new GrpcErrors().interceptCall(call, supplied, (wrapped, headers) -> {
   var untrusted = new Metadata(); untrusted.put(GrpcErrors.CODE, "secret");
   wrapped.close(Status.INTERNAL.withDescription("private details"), untrusted);
   wrapped.close(Status.INTERNAL, untrusted);
   return new ServerCall.Listener<>() {};
  });
  var status = ArgumentCaptor.forClass(Status.class); var trailers = ArgumentCaptor.forClass(Metadata.class);
  verify(call, times(1)).close(status.capture(), trailers.capture());
  assertEquals("Request failed", status.getValue().getDescription());
  assertEquals("INTERNAL", trailers.getValue().get(GrpcErrors.CODE));
  assertEquals("async-123", trailers.getValue().get(GrpcErrors.CORRELATION));
 }
 @SuppressWarnings("unchecked")
 @Test void startupFailureMapsToDomainStatus() {
  ServerCall<String, String> call = mock(ServerCall.class);
  new GrpcErrors().interceptCall(call, new Metadata(), (wrapped, headers) -> {
   throw new ServiceFailure(ServiceFailure.Code.BUSY, "secret");
  });
  var status = ArgumentCaptor.forClass(Status.class); var trailers = ArgumentCaptor.forClass(Metadata.class);
  verify(call).close(status.capture(), trailers.capture());
  assertEquals(Status.Code.RESOURCE_EXHAUSTED, status.getValue().getCode());
  assertEquals("BUSY", trailers.getValue().get(GrpcErrors.CODE));
 }
}
