package com.example.xml.security;
import java.util.Arrays;
import java.util.Collection;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
public class TokenPolicy {
 public static final String SCOPE = "xml:transform";
 private final JwtDecoder decoder;
 private final boolean local;
 public TokenPolicy(JwtDecoder decoder, boolean local) { this.decoder = decoder; this.local = local; }
 public boolean local() { return local; }
 public String authenticate(String authorization) {
  if (local) return "local";
  if (authorization == null || !authorization.startsWith("Bearer ")) throw new JwtException("Bearer token required");
  Jwt jwt = decoder.decode(authorization.substring(7));
  Object claim = jwt.getClaims().getOrDefault("scope", jwt.getClaims().get("scp"));
  boolean allowed = claim instanceof String s ? Arrays.asList(s.split(" ")).contains(SCOPE)
      : claim instanceof Collection<?> scopes && scopes.contains(SCOPE);
  if (!allowed) throw new ScopeDenied();
  return tenant(jwt);
 }
 public static String tenant(Jwt jwt) {
  String tenant = jwt.getClaimAsString("tenant_id");
  String key = tenant != null && !tenant.isBlank() ? tenant : jwt.getSubject();
  if (key == null || key.isBlank() || key.length() > 256) throw new JwtException("Tenant or subject required");
  return key;
 }
 public static class ScopeDenied extends RuntimeException {}
}
