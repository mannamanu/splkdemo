package com.example.xml.core;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import javax.xml.XMLConstants;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.validation.Schema;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
@Component
public class JaxpXmlEngine implements XmlEngine {
 private final XmlArtifacts artifacts;
 private final int maxOutput;
 public JaxpXmlEngine(XmlArtifacts artifacts, @Value("${app.max-output-bytes}") int maxOutput) {
  if (maxOutput < 1) throw new IllegalArgumentException("max-output-bytes must be positive");
  this.artifacts = artifacts; this.maxOutput = maxOutput;
 }
 public void validate(String profile, byte[] xml) {
  artifacts.requireProfile(profile);
  validateDocument(artifacts.input(), SecureXml.parse(xml), false);
 }
 public byte[] transform(String profile, byte[] xml) {
  artifacts.requireProfile(profile);
  var document = SecureXml.parse(xml);
  validateDocument(artifacts.input(), document, false);
  try {
   // Templates and Schema may be reused. Transformer/Validator/DOM are per request.
   var transformer = artifacts.stylesheet().newTransformer();
   transformer.setURIResolver((href, base) -> { throw new javax.xml.transform.TransformerException("External resources prohibited"); });
   var out = new LimitedOutput(maxOutput);
   transformer.transform(new DOMSource(document), new StreamResult(out));
   var result = out.bytes();
   validateDocument(artifacts.output(), SecureXml.parse(result), true);
   return result;
  } catch (ServiceFailure e) { throw e; }
  catch (Exception e) { throw new ServiceFailure(ServiceFailure.Code.INTERNAL, "Transformation failed"); }
 }
 private static void validateDocument(Schema schema, Document document, boolean output) {
  try {
   var validator = schema.newValidator();
   validator.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
   validator.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
   validator.validate(new DOMSource(document));
  } catch (Exception e) {
   throw new ServiceFailure(output ? ServiceFailure.Code.INTERNAL : ServiceFailure.Code.SCHEMA_INVALID,
       output ? "Transformed XML failed output validation" : "XML does not match the input schema");
  }
 }
 private static class LimitedOutput extends OutputStream {
  private final int maximum;
  private final ByteArrayOutputStream delegate = new ByteArrayOutputStream();
  LimitedOutput(int maximum) { this.maximum = maximum; }
  private void check(int count) throws IOException {
   if (count > maximum - delegate.size()) throw new IOException("Output limit exceeded");
  }
  public void write(int value) throws IOException { check(1); delegate.write(value); }
  public void write(byte[] bytes, int offset, int length) throws IOException { check(length); delegate.write(bytes, offset, length); }
  byte[] bytes() { return delegate.toByteArray(); }
 }
}
