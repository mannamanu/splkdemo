package com.example.xml.http;

import com.example.xml.core.ErrorCatalog;
import jakarta.servlet.http.*;
import java.io.IOException;
import org.springframework.stereotype.Component;
import tools.jackson.databind.ObjectMapper;

/** Security filters run before MVC advice, so they use the same problem factory. */
@Component
public class SecurityErrors {
 private final ObjectMapper mapper;
 public SecurityErrors(ObjectMapper mapper) { this.mapper = mapper; }
 public void write(HttpServletRequest request, HttpServletResponse response, int status) throws IOException {
  if (response.isCommitted()) return;
  String id = CorrelationFilter.id(request);
  response.setStatus(status);
  response.setContentType("application/problem+json");
  response.setHeader("Cache-Control", "no-store");
  response.setHeader(CorrelationFilter.HEADER, id);
  if (status == 401) response.setHeader("WWW-Authenticate", "Bearer");
  mapper.writeValue(response.getOutputStream(), ApiErrors.problem(status, ErrorCatalog.httpCode(status), id));
 }
}
