package com.example.xml.grpc;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.stereotype.Component;
@Component("grpcServer")
public class GrpcServerHealth implements HealthIndicator {
 private final GrpcServerLifecycle server;
 public GrpcServerHealth(GrpcServerLifecycle server) { this.server=server; }
 public Health health() { return server.isRunning() ? Health.up().build() : Health.down().build(); }
}
