package com.example.xml.http;
import com.example.xml.core.*;
import com.example.xml.security.TokenPolicy;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/v1")
public class TransformationController {
 private final TransformationService service;
 private final int maxInput;
 public TransformationController(TransformationService service, @Value("${app.max-input-bytes}") int maxInput) { this.service=service; this.maxInput=maxInput; }
 @GetMapping("/profiles") public Map<String,Object> profiles() { return Map.of("profiles", java.util.List.of(XmlArtifacts.PROFILE)); }
 @PostMapping(value="/profiles/{profile}/transform", consumes={"application/xml","text/xml"}, produces="application/xml")
 public ResponseEntity<byte[]> transform(@PathVariable String profile, HttpServletRequest request, Authentication auth) throws IOException {
  String tenant = auth instanceof JwtAuthenticationToken jwt ? TokenPolicy.tenant(jwt.getToken()) : "local";
  return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).cacheControl(CacheControl.noStore()).body(service.transform(tenant, profile, read(request)));
 }
 @PostMapping(value="/profiles/{profile}/validate", consumes={"application/xml","text/xml"}, produces="application/json")
 public Map<String,Object> validate(@PathVariable String profile, HttpServletRequest request) throws IOException {
  service.validate(profile, read(request)); return Map.of("valid", true, "profile", profile);
 }
 private byte[] read(HttpServletRequest request) throws IOException {
  if (request.getContentLengthLong() > maxInput) throw new ServiceFailure(ServiceFailure.Code.TOO_LARGE, "XML exceeds the input limit");
  byte[] data = request.getInputStream().readNBytes(maxInput + 1);
  if (data.length > maxInput) throw new ServiceFailure(ServiceFailure.Code.TOO_LARGE, "XML exceeds the input limit");
  return data;
 }
}
