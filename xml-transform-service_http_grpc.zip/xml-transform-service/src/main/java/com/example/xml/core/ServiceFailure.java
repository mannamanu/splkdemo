package com.example.xml.core;
public class ServiceFailure extends RuntimeException {
 public enum Code { BAD_XML, SCHEMA_INVALID, UNKNOWN_PROFILE, TOO_LARGE, BUSY, INTERNAL }
 private final Code code;
 public ServiceFailure(Code code, String message) { super(message); this.code = code; }
 public Code code() { return code; }
}
