package com.example.xml.core;
public interface XmlEngine {
 byte[] transform(String profile, byte[] xml);
 void validate(String profile, byte[] xml);
}
