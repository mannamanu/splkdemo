package com.example.xml.grpc;
import io.grpc.Status;
import io.grpc.health.v1.*;
import io.grpc.stub.StreamObserver;
import org.springframework.boot.availability.ApplicationAvailability;
import org.springframework.boot.availability.ReadinessState;
import org.springframework.stereotype.Component;
@Component
public class GrpcReadiness extends HealthGrpc.HealthImplBase {
 private final ApplicationAvailability availability;
 public GrpcReadiness(ApplicationAvailability availability) { this.availability=availability; }
 @Override public void check(HealthCheckRequest request, StreamObserver<HealthCheckResponse> observer) {
  if (availability.getReadinessState() != ReadinessState.ACCEPTING_TRAFFIC) {
   // ALB checks the gRPC status, not the health message body.
   observer.onError(Status.UNAVAILABLE.withDescription("Not ready").asRuntimeException()); return;
  }
  if (!request.getService().isEmpty() && !request.getService().equals("xml.v1.TransformationService")) {
   observer.onError(Status.NOT_FOUND.asRuntimeException()); return;
  }
  observer.onNext(HealthCheckResponse.newBuilder().setStatus(HealthCheckResponse.ServingStatus.SERVING).build());
  observer.onCompleted();
 }
}
