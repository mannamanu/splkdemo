package com.example.xml.http;

import com.example.xml.core.*;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.*;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class ApiErrors extends ResponseEntityExceptionHandler {
 private static final Logger LOG = LoggerFactory.getLogger(ApiErrors.class);
 public static ProblemDetail problem(int status, String code, String id) {
  var body = ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(status), ErrorCatalog.message(code));
  body.setProperty("code", code);
  body.setProperty("correlationId", id);
  return body;
 }
 @ExceptionHandler(ServiceFailure.class)
 public ResponseEntity<Object> failure(ServiceFailure error, HttpServletRequest request) {
  return response(error, ErrorCatalog.httpStatus(error.code()), error.code().name(), new HttpHeaders(), request);
 }
 @ExceptionHandler(AuthenticationException.class)
 public ResponseEntity<Object> unauthenticated(AuthenticationException error, HttpServletRequest request) {
  return response(error, 401, "UNAUTHENTICATED", new HttpHeaders(), request);
 }
 @ExceptionHandler(AccessDeniedException.class)
 public ResponseEntity<Object> denied(AccessDeniedException error, HttpServletRequest request) {
  return response(error, 403, "PERMISSION_DENIED", new HttpHeaders(), request);
 }
 @ExceptionHandler(Exception.class)
 public ResponseEntity<Object> unexpected(Exception error, HttpServletRequest request) {
  return response(error, 500, "INTERNAL", new HttpHeaders(), request);
 }
 @Override protected ResponseEntity<Object> handleExceptionInternal(Exception error, Object body,
   HttpHeaders headers, HttpStatusCode status, WebRequest request) {
  var servlet = ((ServletWebRequest) request);
  if (servlet.getResponse() != null && servlet.getResponse().isCommitted()) return null;
  return response(error, status.value(), ErrorCatalog.httpCode(status.value()), headers, servlet.getRequest());
 }
 private ResponseEntity<Object> response(Exception error, int status, String code,
   HttpHeaders originalHeaders, HttpServletRequest request) {
  String id = CorrelationFilter.id(request);
  if (status >= 500) LOG.error("HTTP failure code={} correlationId={} exceptionType={}", code, id, error.getClass().getName());
  var headers = new HttpHeaders(); headers.putAll(originalHeaders);
  headers.setContentType(MediaType.APPLICATION_PROBLEM_JSON);
  headers.setCacheControl("no-store"); headers.set(CorrelationFilter.HEADER, id);
  if (status == 401) headers.set(HttpHeaders.WWW_AUTHENTICATE, "Bearer");
  if (code.equals("BUSY")) headers.set(HttpHeaders.RETRY_AFTER, "1");
  return new ResponseEntity<>(problem(status, code, id), headers, HttpStatusCode.valueOf(status));
 }
}
