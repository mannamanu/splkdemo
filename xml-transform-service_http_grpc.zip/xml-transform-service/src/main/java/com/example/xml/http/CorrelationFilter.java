package com.example.xml.http;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.UUID;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationFilter extends OncePerRequestFilter {
 public static final String HEADER = "X-Correlation-ID";
 private static final String ATTRIBUTE = CorrelationFilter.class.getName();
 public static String safeId(String supplied) {
  return supplied != null && supplied.matches("[A-Za-z0-9_-]{1,64}") ? supplied : UUID.randomUUID().toString();
 }
 public static String id(HttpServletRequest request) {
  var id = request.getAttribute(ATTRIBUTE);
  if (id == null) { id = safeId(request.getHeader(HEADER)); request.setAttribute(ATTRIBUTE, id); }
  return id.toString();
 }
 @Override protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
   FilterChain chain) throws ServletException, IOException {
  response.setHeader(HEADER, id(request));
  chain.doFilter(request, response);
 }
}
