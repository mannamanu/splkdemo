package com.example.xml.core;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.cache.CaffeineCacheMetrics;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.HexFormat;
import java.util.concurrent.Semaphore;
import java.util.function.Supplier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class TransformationService {
 private record Key(String tenant, String profile, String digest) {}
 private final XmlEngine engine;
 private final Cache<Key, byte[]> results;
 private final boolean enabled;
 private final int maxInput;
 private final Semaphore slots;
 private final MeterRegistry metrics;
 public TransformationService(XmlEngine engine, MeterRegistry metrics,
   @Value("${app.cache.results-enabled}") boolean enabled,
   @Value("${app.cache.max-result-bytes}") long maxWeight,
   @Value("${app.cache.ttl-seconds}") long ttl,
   @Value("${app.max-input-bytes}") int maxInput,
   @Value("${app.max-concurrent-operations}") int concurrent) {
  if (ttl < 1 || maxWeight < 1 || maxInput < 1 || concurrent < 1) throw new IllegalArgumentException("Limits must be positive");
  this.engine = engine; this.metrics = metrics; this.enabled = enabled; this.maxInput = maxInput; slots = new Semaphore(concurrent);
  results = Caffeine.newBuilder().maximumWeight(maxWeight)
    .weigher((Key k, byte[] value) -> value.length + 256 + 2 * (k.tenant.length() + k.profile.length()))
    .expireAfterWrite(Duration.ofSeconds(ttl)).recordStats().build();
  CaffeineCacheMetrics.monitor(metrics, results, "xml.results");
 }
 public byte[] transform(String tenant, String profile, byte[] xml) {
  return execute("transform", () -> {
   check(xml);
   if (!enabled) return engine.transform(profile, xml);
   var key = new Key(tenant, profile, digest(xml));
   return results.get(key, unused -> engine.transform(profile, xml)).clone();
  });
 }
 public void validate(String profile, byte[] xml) {
  execute("validate", () -> { check(xml); engine.validate(profile, xml); return true; });
 }
 private void check(byte[] xml) {
  if (xml.length == 0) throw new ServiceFailure(ServiceFailure.Code.BAD_XML, "XML body is required");
  if (xml.length > maxInput) throw new ServiceFailure(ServiceFailure.Code.TOO_LARGE, "XML exceeds the input limit");
 }
 private <T> T execute(String operation, Supplier<T> action) {
  if (!slots.tryAcquire()) {
   metrics.counter("xml.requests.rejected", "reason", "busy").increment();
   throw new ServiceFailure(ServiceFailure.Code.BUSY, "Service is busy; retry later");
  }
  long start = System.nanoTime();
  try { return action.get(); }
  catch (ServiceFailure e) { metrics.counter("xml.requests.failed", "code", e.code().name()).increment(); throw e; }
  finally { slots.release(); metrics.timer("xml.operation", "operation", operation).record(System.nanoTime()-start, java.util.concurrent.TimeUnit.NANOSECONDS); }
 }
 private static String digest(byte[] xml) {
  try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(xml)); }
  catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
 }
}
