package com.example.xml.core;
import java.io.ByteArrayInputStream;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;
final class SecureXml {
 private SecureXml() {}
 static Document parse(byte[] xml) {
  try {
   var f = DocumentBuilderFactory.newDefaultInstance();
   f.setNamespaceAware(true);
   f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
   f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
   f.setFeature("http://xml.org/sax/features/external-general-entities", false);
   f.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
   f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
   f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
   f.setAttribute("http://www.oracle.com/xml/jaxp/properties/maxElementDepth", 128);
   f.setXIncludeAware(false);
   f.setExpandEntityReferences(false);
   var builder = f.newDocumentBuilder();
   builder.setErrorHandler(new ErrorHandler() {
    public void warning(SAXParseException e) throws SAXParseException { throw e; }
    public void error(SAXParseException e) throws SAXParseException { throw e; }
    public void fatalError(SAXParseException e) throws SAXParseException { throw e; }
   });
   return builder.parse(new ByteArrayInputStream(xml));
  } catch (Exception e) {
   throw new ServiceFailure(ServiceFailure.Code.BAD_XML, "Malformed or prohibited XML");
  }
 }
}
