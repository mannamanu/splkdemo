package com.example.xml.grpc;

import com.example.xml.core.*;
import com.example.xml.http.CorrelationFilter;
import io.grpc.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.slf4j.LoggerFactory;

/** Global boundary for synchronous callbacks and asynchronous observer.onError calls. */
public final class GrpcErrors implements ServerInterceptor {
 public static final Metadata.Key<String> CODE = Metadata.Key.of("error-code", Metadata.ASCII_STRING_MARSHALLER);
 public static final Metadata.Key<String> CORRELATION = Metadata.Key.of("correlation-id", Metadata.ASCII_STRING_MARSHALLER);
 private static Status status(ServiceFailure.Code code) {
  return switch (code) {
   case BAD_XML, SCHEMA_INVALID -> Status.INVALID_ARGUMENT;
   case UNKNOWN_PROFILE -> Status.NOT_FOUND;
   case TOO_LARGE, BUSY -> Status.RESOURCE_EXHAUSTED;
   case INTERNAL -> Status.INTERNAL;
  };
 }
 @Override public <Q, R> ServerCall.Listener<Q> interceptCall(ServerCall<Q, R> call,
   Metadata incoming, ServerCallHandler<Q, R> next) {
  String id = CorrelationFilter.safeId(incoming.get(CORRELATION));
  var closed = new AtomicBoolean();
  var safeCall = new ForwardingServerCall.SimpleForwardingServerCall<Q, R>(call) {
   @Override public void sendHeaders(Metadata headers) {
    headers.discardAll(CORRELATION); headers.put(CORRELATION, id); super.sendHeaders(headers);
   }
   @Override public void close(Status original, Metadata trailers) {
    if (!closed.compareAndSet(false, true)) return;
    if (original.isOk()) { trailers.discardAll(CORRELATION); trailers.put(CORRELATION, id); super.close(original, trailers); return; }
    Throwable cause = original.getCause();
    String code = cause instanceof ServiceFailure failure ? failure.code().name() : original.getCode().name();
    Status mapped = cause instanceof ServiceFailure failure ? status(failure.code()) : original;
    if (mapped.getCode() == Status.Code.UNKNOWN) { mapped = Status.INTERNAL; code = "INTERNAL"; }
    if (mapped.getCode() == Status.Code.INTERNAL) LoggerFactory.getLogger(GrpcErrors.class)
      .error("gRPC failure code={} correlationId={} exceptionType={}", code, id, cause == null ? "none" : cause.getClass().getName());
    // Discard arbitrary exception trailers (including rich status details) to prevent leakage.
    var safeTrailers = new Metadata(); safeTrailers.put(CODE, code); safeTrailers.put(CORRELATION, id);
    super.close(mapped.withCause(null).withDescription(ErrorCatalog.message(code)), safeTrailers);
   }
  };
  try {
   var listener = next.startCall(safeCall, incoming);
   return new ForwardingServerCallListener.SimpleForwardingServerCallListener<Q>(listener) {
    private void guard(Runnable action) {
     if (closed.get()) return;
     try { action.run(); } catch (Exception error) { fail(safeCall, error); }
    }
    @Override public void onMessage(Q message) { guard(() -> super.onMessage(message)); }
    @Override public void onHalfClose() { guard(super::onHalfClose); }
    @Override public void onReady() { guard(super::onReady); }
    // Always deliver terminal callbacks so delegates can release resources.
    @Override public void onCancel() { try { super.onCancel(); } catch (Exception e) { fail(safeCall, e); } }
    @Override public void onComplete() { try { super.onComplete(); } catch (Exception e) { fail(safeCall, e); } }
   };
  } catch (Exception error) { fail(safeCall, error); return new ServerCall.Listener<>() {}; }
 }
 private static void fail(ServerCall<?, ?> call, Exception error) {
  Status mapped = error instanceof ServiceFailure failure ? status(failure.code())
    : error instanceof StatusRuntimeException || error instanceof StatusException ? Status.fromThrowable(error) : Status.INTERNAL;
  call.close(mapped.withCause(error), new Metadata());
 }
}
