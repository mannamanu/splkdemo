package com.example.xml.grpc;
import com.example.xml.security.TokenPolicy;
import io.grpc.*;
import org.springframework.security.oauth2.jwt.JwtException;
public class GrpcAuthentication implements ServerInterceptor {
 public static final Context.Key<String> TENANT = Context.key("tenant");
 private final TokenPolicy policy;
 public GrpcAuthentication(TokenPolicy policy) { this.policy=policy; }
 public <Q,S> ServerCall.Listener<Q> interceptCall(ServerCall<Q,S> call, Metadata headers, ServerCallHandler<Q,S> next) {
  try {
   String tenant = policy.authenticate(headers.get(Metadata.Key.of("authorization", Metadata.ASCII_STRING_MARSHALLER)));
   return Contexts.interceptCall(Context.current().withValue(TENANT, tenant), call, headers, next);
  } catch (TokenPolicy.ScopeDenied e) { call.close(Status.PERMISSION_DENIED.withDescription("Required scope missing"), new Metadata()); }
  catch (JwtException e) { call.close(Status.UNAUTHENTICATED.withDescription("Valid bearer token required"), new Metadata()); }
  return new ServerCall.Listener<>() {};
 }
}
