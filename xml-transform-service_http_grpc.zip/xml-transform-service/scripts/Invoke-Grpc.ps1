[CmdletBinding()]
param(
 [ValidateSet('Transform','Validate')][string]$Method='Transform',
 [string]$Target='localhost:9090',
 [string]$XmlPath,
 [switch]$Tls
)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
if (!$XmlPath) {$XmlPath=Join-Path $root 'samples/order.xml'}
Get-Command grpcurl -ErrorAction Stop | Out-Null
$body=@{profile='order-v1';xml=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path $XmlPath).Path))} | ConvertTo-Json -Compress
$argsList=@('-import-path',(Join-Path $root 'src/main/proto'),'-proto','transformation.proto','-max-time','10','-d','@')
if (!$Tls) {$argsList=@('-plaintext')+$argsList}
if ($env:GRPC_BEARER_TOKEN) {$argsList+=@('-H',"authorization: Bearer $env:GRPC_BEARER_TOKEN")}
$argsList+=@($Target,"xml.v1.TransformationService/$Method")
$response=$body | & grpcurl @argsList
if ($LASTEXITCODE -ne 0) {throw 'gRPC request failed'}
if ($Method -eq 'Transform') {
 $reply=($response -join "`n") | ConvertFrom-Json
 [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($reply.xml))
} else {$response}
