# Run after infra/registry has been applied. This script pushes an image, not infrastructure.
[CmdletBinding()]
param([string]$Region='us-east-1',[string]$Tag)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$root=Split-Path $PSScriptRoot -Parent
function Run([string]$Exe,[string[]]$Arguments) {
 & $Exe @Arguments
 if($LASTEXITCODE -ne 0){throw "$Exe failed with exit code $LASTEXITCODE"}
}
foreach($tool in @('docker','aws','terraform')){Get-Command $tool -ErrorAction Stop | Out-Null}
if(!$Tag){$Tag=[DateTime]::UtcNow.ToString('yyyyMMddHHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8)}
if($Tag -notmatch '^[a-zA-Z0-9_][a-zA-Z0-9_.-]{0,127}$'){throw 'Invalid image tag'}
$env:AWS_PAGER=''
$repo=(Run 'terraform' @("-chdir=$root/infra/registry",'output','-raw','repository_url') | Out-String).Trim()
$repoName=(Run 'terraform' @("-chdir=$root/infra/registry",'output','-raw','repository_name') | Out-String).Trim()
$account=(Run 'aws' @('sts','get-caller-identity','--query','Account','--output','text') | Out-String).Trim()
if(!$repo.StartsWith("$account.dkr.ecr.$Region.")){throw 'AWS account/region do not match the repository'}
$image="${repo}:$Tag"
Run 'docker' @('buildx','build','--platform','linux/amd64','--load','-t',$image,$root)
$password=(Run 'aws' @('ecr','get-login-password','--region',$Region) | Out-String).Trim()
try {
 $password | & docker login --username AWS --password-stdin ($repo -split '/')[0]
 if($LASTEXITCODE -ne 0){throw 'Docker ECR login failed'}
} finally {$password=$null}
Run 'docker' @('push',$image)
$digest=(Run 'aws' @('ecr','describe-images','--region',$Region,'--repository-name',$repoName,'--image-ids',"imageTag=$Tag",'--query','imageDetails[0].imageDigest','--output','text') | Out-String).Trim()
if($digest -notmatch '^sha256:[0-9a-f]{64}$'){throw 'Unable to resolve image digest'}
@{image_uri="${repo}@$digest"} | ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $root 'infra/service/image.auto.tfvars.json')
Write-Host "Published ${repo}@$digest. Review a Terraform plan before applying the service."
