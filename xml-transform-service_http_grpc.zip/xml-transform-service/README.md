# XML transformation service — HTTP + gRPC

One Spring Boot 4.0.8 application, Maven and JDK 25. Docker compiles/runs with Amazon
Corretto 25. No Temporal, database, other microservice or AI runtime is required.

This is an enterprise-oriented starter with production JWT defaults, XML security
controls, bounded processing/cache settings, health/metrics, tests and an AWS
Terraform baseline. It is not a claim of production certification or load capacity.

## What the sample does

XSD **validates** document structure and values. XSLT **transforms** the document.
The included `order-v1` profile converts `samples/order.xml` to the shape shown in
`samples/expected-output.xml`, validating both input and output. These are small
synthetic order schemas, not the full MISMO specification. Transformation output is
XML; validation returns JSON over HTTP and a protobuf reply over gRPC.

| Transport | Endpoint / method | Behavior |
|---|---|---|
| HTTP GET | `/api/v1/profiles` | List allowed profiles |
| HTTP POST | `/api/v1/profiles/order-v1/validate` | Validate raw XML against input XSD |
| HTTP POST | `/api/v1/profiles/order-v1/transform` | Validate, transform with XSLT, validate output |
| gRPC unary | `xml.v1.TransformationService/Validate` | Same input validation |
| gRPC unary | `xml.v1.TransformationService/Transform` | Same transformation |

Source map:

- `src/main/java/com/example/xml/core`: shared engine, errors, limits and caches.
- `http`: Spring MVC controller and status mapping.
- `grpc`: protobuf adapter, JWT interceptor, managed server and readiness probe.
- `security`: JWT decoder/validators and transport policy.
- `src/main/proto/transformation.proto`: gRPC contract; Maven generates Java classes.
- `xml-assets/order-v1`: input XSD, output XSD and XSLT.
- `src/test/java`: Mockito unit tests, XML tests and real transport integration tests.
- `samples`: XML documents and HTTP requests; `scripts`: gRPC helper/image publisher.
- `infra`: ECR/ECS/ALB/Route 53 Terraform; `docs`: architecture and AI usage.

## 1. Obtain the code and prerequisites

Extract this ZIP and open a terminal in `xml-transform-service`, containing pom.xml.
No remote Git repository was created. If you publish it, clone YOUR real URL:

```bash
git clone https://github.com/YOUR-ORG/xml-transform-service.git
cd xml-transform-service
```

For Docker: install/start Docker Desktop with Linux containers (or Docker Engine
and Compose v2 on Linux). Host Java/Maven are not needed for this path.
https://docs.docker.com/get-started/get-docker/

For native execution: install Amazon Corretto JDK25 and Maven 3.9.11+ (3.9.x).
https://docs.aws.amazon.com/corretto/latest/corretto-25-ug/downloads-list.html
https://maven.apache.org/install.html

```bash
java --version
javac -version
mvn -version
```

Java/javac and Maven's Java version must all report 25. If JDK21 is still installed,
select the JDK25 home in your terminal/IDE without uninstalling it. PowerShell example:

```powershell
$env:JAVA_HOME = 'C:\Java\jdk-25' # Replace with actual Corretto JDK root
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
mvn -version
```

For gRPC examples install `grpcurl`: https://github.com/fullstorydev/grpcurl
For AWS later also install Terraform, AWS CLI v2 and PowerShell 7 (see infra/README.md).
Internet access is needed to fetch Maven dependencies/container images. Use your
organization's approved Maven proxy/trust settings; never disable TLS verification.

## 2. Run locally with Docker

```bash
docker compose up --build -d
docker compose ps
docker compose logs --tail=100 -f
```

The build runs tests. One container exposes localhost HTTP8080 and gRPC9090. Compose
explicitly activates the unauthenticated `local` profile and binds published ports
to 127.0.0.1. Do not reuse this profile in AWS. Press Ctrl+C to stop following logs.

```bash
docker compose down
```

There is no database. Compose mounts `./xml-assets` read-only at `/opt/xml-assets`.
Cache entries disappear with the process.
After code changes rerun `docker compose up --build -d`. After changing Compose
values recreate the container with `docker compose up -d --force-recreate`.

## 3. Or run natively

From the project root:

```bash
mvn -B -ntp verify
java -jar target/app.jar --spring.profiles.active=local
```

The same command works in PowerShell and Bash. IntelliJ: open pom.xml as Maven,
select JDK25 for project and Maven runner, run `Application` with active profile
`local`, and run Maven generate-sources if protobuf classes are not visible.
Native servers bind their configured interfaces; use your host firewall for local
access. Stop with Ctrl+C; the HTTP and gRPC servers shut down gracefully.

## External XSD and XSLT assets

Assets live outside the application classpath at the project root:

- `xml-assets/order-v1/order-input.xsd`
- `xml-assets/order-v1/order-output.xsd`
- `xml-assets/order-v1/order-to-normalized.xsl`

Native execution defaults to `./xml-assets` relative to the working directory.
Set `XML_ASSETS_DIR` to an absolute folder when starting from another directory:

```bash
XML_ASSETS_DIR=/path/to/xml-assets java -jar target/app.jar --spring.profiles.active=local
```

PowerShell:

```powershell
$env:XML_ASSETS_DIR = 'C:\projects\xml-assets'
java -jar target/app.jar --spring.profiles.active=local
```

Compose uses a read-only bind mount. To keep assets in the repository's parent folder,
change the volume `source` to `../xml-assets`; leave its container `target` unchanged.
The folder must exist and be readable by container user 10001. Missing or invalid
assets fail application startup. Schemas/stylesheets compile once at startup; edits
require `docker compose restart app` (or a native process restart). No hot reload is
implemented. Restart also clears cached results, preventing stale mappings.

The Docker image includes an immutable asset snapshot at `/opt/xml-assets` for AWS.
ECS can use that image directly without a host bind mount. Rebuild/publish the image
and redeploy when mappings change; deploy a new profile version for contract changes.
The configured path is operator-owned; request profiles cannot select arbitrary files.
External XSD imports, XSLT includes and network reads remain disabled.

## 4. Sample HTTP POST requests

Windows PowerShell (use curl.exe, not the old PowerShell curl alias):

```powershell
curl.exe -i http://localhost:8080/actuator/health/readiness
curl.exe -i http://localhost:8080/api/v1/profiles

curl.exe -i -X POST http://localhost:8080/api/v1/profiles/order-v1/transform `
  -H "Content-Type: application/xml" `
  -H "Accept: application/xml" `
  --data-binary "@samples/order.xml"

curl.exe -i -X POST http://localhost:8080/api/v1/profiles/order-v1/validate `
  -H "Content-Type: application/xml" --data-binary "@samples/order.xml"
```

Bash/macOS/Linux:

```bash
curl -i -X POST http://localhost:8080/api/v1/profiles/order-v1/transform \
  -H 'Content-Type: application/xml' \
  -H 'Accept: application/xml' \
  --data-binary @samples/order.xml

curl -i -X POST http://localhost:8080/api/v1/profiles/order-v1/validate \
  -H 'Content-Type: application/xml' --data-binary @samples/order.xml
```

Sample input:

```xml
<Order xmlns="urn:example:order:v1">
  <OrderId>ORD-1001</OrderId>
  <CustomerName>Sample Customer</CustomerName>
  <Amount>125.50</Amount>
  <Currency>USD</Currency>
</Order>
```

Transform returns HTTP200 and normalized XML. Validate returns HTTP200 with
`{"valid":true,"profile":"order-v1"}` (JSON field order may vary). Sending
`samples/invalid-order.xml` to validate returns HTTP422: its amount is negative.
Open `samples/requests.http` in an IDE HTTP client for editable requests.

## 5. Sample gRPC requests

Protobuf uses `bytes xml`; grpcurl represents bytes as base64 in JSON. This preserves
the original document bytes/encoding. It does NOT mean base64 XML is required by HTTP.
The .proto is provided explicitly; reflection is not enabled.

PowerShell helper (prints decoded XML for Transform):

```powershell
.\scripts\Invoke-Grpc.ps1 -Method Transform
.\scripts\Invoke-Grpc.ps1 -Method Validate
```

Bash, with Python3 used only to generate the JSON request:

```bash
python3 -c 'import base64,json,pathlib; print(json.dumps({"profile":"order-v1","xml":base64.b64encode(pathlib.Path("samples/order.xml").read_bytes()).decode()}))' \
  | grpcurl -plaintext -max-time 10 \
      -import-path src/main/proto -proto transformation.proto \
      -d @ localhost:9090 xml.v1.TransformationService/Transform
```

The reply's `xml` field is base64. Replace Transform with Validate for a boolean reply.
Clients should set deadlines (the examples use 10 seconds). A deadline stops the RPC
but does not promise immediate interruption of already-running XSLT CPU work.

## 6. Authentication outside local development

Without the explicit local profile, startup requires JWT configuration:

```dotenv
JWT_ISSUER=https://your-idp.example.com/issuer
JWT_JWK_SET_URI=https://your-idp.example.com/.well-known/jwks.json
JWT_AUDIENCE=xml-transform-api
```

Provide these as environment variables. A `.env` file is not automatically loaded by
a native Java process. Your identity provider issues the JWT; this service does not.
Use access tokens with the expected issuer/audience, expiry and scope `xml:transform`.
The verified `tenant_id` claim, or subject if absent, identifies the cache partition.
Configure your IdP claim mapping accordingly (some providers use client_id rather
than aud for certain access tokens; such tokens will not satisfy this sample policy).

HTTP: `Authorization: Bearer <token>`. gRPC: metadata `authorization: Bearer <token>`.
For the PowerShell gRPC helper set `GRPC_BEARER_TOKEN` in the process environment.
In AWS use TLS, e.g. `-Target xml.dev.example.com:443 -Tls`; do not use -plaintext.
Metrics also require the scope outside local mode. Health status endpoints are
unauthenticated for infrastructure probes. No payloads/tokens are intentionally logged.
The included gRPC health method is internal: the AWS ALB route does not expose it.

JWT signature, issuer, audience, expiry and tenant/subject are checked. Local mode
is rejected without the `local` profile. Prevent operators from activating that
profile in deployed environments through deployment controls.

## 7. Performance and caching

| Cache/control | Default |
|---|---|
| Compiled input/output XSDs | Caffeine, up to 4 entries; warm at startup |
| Compiled XSLT Templates | Caffeine, up to 2 entries; warm at startup |
| Optional transformed-result cache | OFF |
| Result cache when enabled | 16 MiB weighted budget; 60-second TTL |
| Cache key | Verified tenant + profile version + SHA-256 of input |
| Input limit | 1 MiB |
| Output limit | 2 MiB |
| XML nesting depth | 128 |
| Concurrent transformation/validation work | 8; excess rejected |

Enable result caching explicitly with RESULT_CACHE_ENABLED=true, or edit the Compose
value and recreate the container. It retains transformed XML in process memory until
expiry/eviction/restart; assess your data handling requirements before enabling it.
It is per instance, not shared across replicas and not durable. The weight is an
estimate including output bytes/key overhead, not an exact JVM heap measurement.

Only immutable compiled artifacts are reused. Validator, Transformer and DOM objects
are request-local. Invalid results are not cached; result bytes are defensively copied.
There is no public cache-clear endpoint. Change profile version/redeploy after changing
mappings. Avoid unbounded client-chosen profile registrations or client-supplied XSLT.

Actuator Prometheus metrics include `xml.operation`, `xml.requests.failed`,
`xml.requests.rejected` and Caffeine cache metrics. Metric names are normalized in
Prometheus format; inspect `/actuator/prometheus` locally. Load-test realistic XML
before choosing heap, instance count or throughput targets; none is claimed here.

## 8. Errors and health

| Condition | HTTP | gRPC |
|---|---:|---|
| Malformed/prohibited XML | 400 | INVALID_ARGUMENT |
| Input XSD violation | 422 | INVALID_ARGUMENT |
| Unknown profile | 404 | NOT_FOUND |
| XML input limit exceeded | 413 | RESOURCE_EXHAUSTED |
| Processing slots exhausted | 503 + Retry-After | RESOURCE_EXHAUSTED |
| Missing/invalid JWT | 401 | UNAUTHENTICATED |
| Insufficient scope | 403 | PERMISSION_DENIED |
| Transformation/output validation failure | 500 | INTERNAL |

Global HTTP handling lives in `http/ApiErrors.java`, extending Spring MVC's
`ResponseEntityExceptionHandler`. It maps domain failures, framework errors (such as
405/415), and unexpected exceptions. `SecurityErrors` applies the same response to
JWT authentication/authorization failures before the controller runs. Framework
headers such as `Allow` are retained; busy responses include `Retry-After: 1`.

All handled HTTP failures use `application/problem+json`, even for XML requests:

```json
{
  "type": "about:blank",
  "title": "Unprocessable Entity",
  "status": 422,
  "detail": "XML does not match the input schema",
  "code": "SCHEMA_INVALID",
  "correlationId": "demo-123"
}
```

The exact reason phrase may vary with the framework. Clients should branch on
`status` and `code`. Send optional header `X-Correlation-ID: demo-123`; it is echoed
in the response header and error body. Only 1–64 ASCII letters, digits, hyphens and
underscores are accepted; other values are replaced with a generated UUID.

Global gRPC handling lives in `grpc/GrpcErrors.java`. It wraps authentication and
service callbacks and sanitizes `observer.onError`/call-close errors. Failures have a
safe status description plus trailing metadata `error-code` and `correlation-id`.
Supply optional request metadata `correlation-id` to correlate the request. Unknown
exceptions become INTERNAL; unexpected descriptions and arbitrary error trailers
are not forwarded. Endpoint methods contain no duplicated exception mapping.

Safe public messages are defined in `core/ErrorCatalog.java`, independent of exception
messages. Unexpected failures log the code, correlation ID and exception class, not
XML, JWTs, exception messages or stack traces that might contain document contents.
Future asynchronous work must report failures through `observer.onError`; exceptions
on detached background threads cannot be caught by the request interceptor.

Errors rejected before application dispatch (TLS, malformed HTTP/gRPC framing, proxy
limits) and responses already committed may retain transport-specific error formats.
Application handlers do not promise to intercept JVM fatal errors or startup failures.

Try an error response:

```bash
curl -i http://localhost:8080/api/v1/profiles/order-v1/validate \
  -H 'Content-Type: application/xml' -H 'X-Correlation-ID: demo-123' \
  --data-binary @samples/invalid-order.xml
```

- `/actuator/health/liveness`: process/application state, independent of remote IdP.
- `/actuator/health/readiness`: Spring readiness plus gRPC server running.
- gRPC `/grpc.health.v1.Health/Check`: status0 when ready, UNAVAILABLE when not ready.

Troubleshooting: check port conflicts on 8080/9090; JDK selected by Maven; local profile;
namespace in XML; token issuer/aud/scope; access to the IdP JWKS URL. Do not turn off
JWT or XML validation to make AWS readiness or API requests succeed.

## 9. Tests

```bash
mvn -B -ntp verify
```

Includes Mockito service/cache/controller/gRPC tests, real XML/XSD/XSLT/security
cases, concurrent engine calls, RSA JWT validation and live HTTP/gRPC parity/auth
tests on random ports. Tests use synthetic documents and no live AWS/IdP account.
The Mockito subclass mock maker avoids dynamic agent attachment for these tests.
Tests execute during Docker builds as well. See VERIFICATION.md for executed checks.

## 10. AI coding agents and AWS later

Read `docs/AI-USAGE.md` to use AGENTS.md, CLAUDE.md, Copilot instructions, custom
implementation/testing agents and the reusable transformation prompt. No AI API key
or runtime dependency is added to this service.

Read `infra/README.md` for the Terraform deployment flow. It creates one Fargate
service, one ECR repository, one HTTPS ALB with HTTP and gRPC target groups, and a
Route 53 alias in an existing network. It does not deploy until you explicitly apply.
An AWS account, existing VPC/subnets, ACM certificate, hosted zone and IdP settings
are required. The local compose file is for development only.
