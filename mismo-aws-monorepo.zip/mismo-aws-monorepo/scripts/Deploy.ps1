# PowerShell 7+, Terraform, AWS CLI v2, Git and Docker Buildx required.
[CmdletBinding()]
param(
    [ValidateSet('Bootstrap','Publish','Plan','Apply','Deploy','Verify')]
    [string]$Mode = 'Plan',
    [string]$RepoPath,
    [string]$BuildConfig
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'Use PowerShell 7 (pwsh).' }
$packageRoot = Split-Path $PSScriptRoot -Parent
$registryDir = Join-Path $packageRoot 'terraform/registry'
$stackDir = Join-Path $packageRoot 'terraform/stack'
$keys = @('orchestrator','auth','order')
if (!$BuildConfig) { $BuildConfig = Join-Path $packageRoot 'services.build.json' }
function Invoke-Checked {
    param([string]$Exe, [string[]]$Arguments)
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Exe failed with exit code $LASTEXITCODE" }
}
function Get-TfOutputs([string]$Directory) {
    return ((Invoke-Checked 'terraform' @("-chdir=$Directory",'output','-json') | Out-String) | ConvertFrom-Json -AsHashtable)
}
function Assert-CleanCommit([string]$Repository, [string]$ExpectedCommit) {
    $dirty = (Invoke-Checked 'git' @('-C',$Repository,'status','--porcelain','--untracked-files=all') | Out-String).Trim()
    $head = (Invoke-Checked 'git' @('-C',$Repository,'rev-parse','HEAD') | Out-String).Trim()
    if ($dirty -or $head -ne $ExpectedCommit) { throw 'Source changed or has uncommitted files. Commit/stash changes and retry.' }
}
foreach ($tool in @('terraform','aws')) { Get-Command $tool -ErrorAction Stop | Out-Null }
$env:AWS_PAGER = ''
Invoke-Checked 'aws' @('sts','get-caller-identity')
Invoke-Checked 'terraform' @("-chdir=$registryDir",'init')
if ($Mode -eq 'Bootstrap') {
    Invoke-Checked 'terraform' @("-chdir=$registryDir",'apply')
    exit 0
}
$registry = Get-TfOutputs $registryDir
$region = $registry.aws_region.value
$account = (Invoke-Checked 'aws' @('sts','get-caller-identity','--query','Account','--output','text') | Out-String).Trim()
if ($account -ne $registry.aws_account_id.value) { throw 'AWS_PROFILE does not match the registry account.' }
if ($Mode -in @('Publish','Deploy')) {
    foreach ($tool in @('git','docker')) { Get-Command $tool -ErrorAction Stop | Out-Null }
    if (!$RepoPath) { throw '-RepoPath is required for Publish/Deploy.' }
    $repo = (Resolve-Path -LiteralPath $RepoPath).Path
    $gitRoot = (Invoke-Checked 'git' @('-C',$repo,'rev-parse','--show-toplevel') | Out-String).Trim()
    if ((Resolve-Path -LiteralPath $gitRoot).Path -ne $repo) { throw 'RepoPath must be the Git root.' }
    $sha = (Invoke-Checked 'git' @('-C',$repo,'rev-parse','HEAD') | Out-String).Trim()
    Assert-CleanCommit $repo $sha
    $build = Get-Content -LiteralPath $BuildConfig -Raw | ConvertFrom-Json -AsHashtable
    if ((($build.Keys | Sort-Object) -join ',') -cne (($keys | Sort-Object) -join ',')) {
        throw 'Build config must contain exactly orchestrator, auth and order.'
    }
    $paths = @{}
    foreach ($key in $keys) {
        foreach ($field in @('context','dockerfile','module')) {
            if (!$build[$key].ContainsKey($field) -or [string]::IsNullOrWhiteSpace($build[$key][$field])) { throw "Missing $key.$field." }
        }
        $paths[$key] = @{
            context = (Resolve-Path -LiteralPath (Join-Path $repo $build[$key].context)).Path
            dockerfile = (Resolve-Path -LiteralPath (Join-Path $repo $build[$key].dockerfile)).Path
        }
    }
    $tag = "$($sha.Substring(0,12))-$([DateTime]::UtcNow.ToString('yyyyMMddHHmmss'))-$([guid]::NewGuid().ToString('N').Substring(0,6))"
    $taggedImages = @{}
    # Build all three before publishing any image in this release.
    foreach ($key in $keys) {
        $taggedImages[$key] = "$($registry.repository_urls.value[$key]):$tag"
        Invoke-Checked 'docker' @('buildx','build','--platform','linux/amd64','--load','--build-arg',"SERVICE=$($build[$key].module)",'--label',"org.opencontainers.image.revision=$sha",'-f',$paths[$key].dockerfile,'-t',$taggedImages[$key],$paths[$key].context)
        Assert-CleanCommit $repo $sha
    }
    $registryHost = ($registry.repository_urls.value.orchestrator -split '/')[0]
    $password = (Invoke-Checked 'aws' @('ecr','get-login-password','--region',$region) | Out-String).Trim()
    try {
        $password | & docker login --username AWS --password-stdin $registryHost
        if ($LASTEXITCODE -ne 0) { throw 'Docker login to ECR failed.' }
    } finally { $password = $null }
    $images = [ordered]@{}
    foreach ($key in $keys) {
        Invoke-Checked 'docker' @('push',$taggedImages[$key])
        $digest = (Invoke-Checked 'aws' @('ecr','describe-images','--region',$region,'--repository-name',$registry.repository_names.value[$key],'--image-ids',"imageTag=$tag",'--query','imageDetails[0].imageDigest','--output','text') | Out-String).Trim()
        if ($digest -notmatch '^sha256:[0-9a-f]{64}$') { throw "Could not resolve $key digest." }
        $images[$key] = "$($registry.repository_urls.value[$key])@$digest"
    }
    # Replace the release selection only after all pushes/digest resolutions succeed.
    $manifest = @{ image_uris = $images } | ConvertTo-Json -Depth 5
    $temporary = Join-Path $stackDir 'images.pending.json'
    $manifest | Set-Content -LiteralPath $temporary -Encoding utf8
    Move-Item -LiteralPath $temporary -Destination (Join-Path $stackDir 'images.auto.tfvars.json') -Force
    Write-Host "Published all three services from commit $sha (tag $tag)."
    Write-Host $manifest
    if ($Mode -eq 'Publish') { exit 0 }
}
Invoke-Checked 'terraform' @("-chdir=$stackDir",'init')
if ($Mode -in @('Plan','Deploy')) {
    if (!(Test-Path (Join-Path $stackDir 'images.auto.tfvars.json'))) { throw 'Run Publish first, or supply all three digest URIs in images.auto.tfvars.json.' }
    Invoke-Checked 'terraform' @("-chdir=$stackDir",'validate')
    Invoke-Checked 'terraform' @("-chdir=$stackDir",'plan','-out=release.tfplan')
    if ($Mode -eq 'Plan') { exit 0 }
}
if ($Mode -in @('Deploy','Apply')) {
    if (!(Test-Path (Join-Path $stackDir 'release.tfplan'))) { throw 'Run Plan first.' }
    if ($Mode -eq 'Apply') { Invoke-Checked 'terraform' @("-chdir=$stackDir",'show','release.tfplan') }
    if ((Read-Host 'Review the plan. Type deploy to apply it and incur AWS charges') -cne 'deploy') { throw 'Cancelled; published images remain in ECR.' }
    Invoke-Checked 'terraform' @("-chdir=$stackDir",'apply','release.tfplan')
}
# Stable can mean rolled back; compare all actual task revisions with the intended ones.
$outputs = Get-TfOutputs $stackDir
foreach ($key in $keys) {
    Invoke-Checked 'aws' @('ecs','wait','services-stable','--region',$outputs.aws_region.value,'--cluster',$outputs.cluster_name.value,'--services',$outputs.service_names.value[$key])
    $actual = (Invoke-Checked 'aws' @('ecs','describe-services','--region',$outputs.aws_region.value,'--cluster',$outputs.cluster_name.value,'--services',$outputs.service_names.value[$key],'--query','services[0].taskDefinition','--output','text') | Out-String).Trim()
    if ($actual -ne $outputs.task_definition_arns.value[$key]) { throw "$key is not running the requested revision. Check ECS rollback events and logs." }
}
Write-Host "Verified all three ECS services. API: $($outputs.application_url.value)"
