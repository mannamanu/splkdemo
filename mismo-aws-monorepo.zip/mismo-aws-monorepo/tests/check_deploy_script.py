"""Offline Linux test: python3 tests/check_deploy_script.py /path/to/pwsh.
Uses real Git and PowerShell; AWS/Docker/Terraform are subprocess test doubles.
No cloud operations or image builds occur. Does not test Windows process behavior.
"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[1]
pwsh = sys.argv[1] if len(sys.argv) > 1 else 'pwsh'
with tempfile.TemporaryDirectory(prefix='mismo-monorepo-test-') as tmp:
    t = Path(tmp)
    package = t / 'package'
    shutil.copytree(root, package, ignore=shutil.ignore_patterns('.terraform', '*.tfstate*', '*.tfvars.json', '*.tfplan'))
    repo = t / 'repo'
    repo.mkdir()
    (repo / 'Dockerfile').write_text('FROM scratch\n')
    subprocess.run(['git', 'init', '-q', str(repo)], check=True)
    subprocess.run(['git', '-C', str(repo), 'add', '.'], check=True)
    subprocess.run(['git', '-C', str(repo), '-c', 'user.name=Test', '-c', 'user.email=test@example.invalid', 'commit', '-qm', 'fixture'], check=True)
    bin_dir = t / 'bin'
    bin_dir.mkdir()
    mock = r'''#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
name = Path(sys.argv[0]).name
a = sys.argv[1:]
with open(os.environ['TEST_COMMAND_LOG'], 'a') as f: f.write(json.dumps([name, a])+'\n')
keys = ['orchestrator','auth','order']
base = '123456789012.dkr.ecr.us-east-1.amazonaws.com/mismo-dev/'
def value(x): return {'value':x}
if name == 'terraform':
    directory = Path(a[0].split('=',1)[1])
    if 'output' in a:
        if directory.name == 'registry':
            data = dict(aws_region='us-east-1', aws_account_id='123456789012', name='mismo-dev', repository_urls={k:base+k for k in keys}, repository_names={k:'mismo-dev/'+k for k in keys})
        else:
            data = dict(aws_region='us-east-1', cluster_name='mismo-dev', application_url='https://mismo.example.com', service_names={k:'mismo-dev-'+k for k in keys}, task_definition_arns={k:'arn:task/'+k+':1' for k in keys})
        print(json.dumps({k:value(v) for k,v in data.items()}))
    elif 'plan' in a:
        (directory/'release.tfplan').write_text('mock plan')
    elif not any(x in a for x in ['init','validate','apply','show']): sys.exit(21)
elif name == 'aws':
    if a[:2] == ['sts','get-caller-identity']:
        print('123456789012' if '--query' in a else '{"Account":"123456789012"}')
    elif a[:2] == ['ecr','get-login-password']: print('synthetic-secret')
    elif a[:2] == ['ecr','describe-images']:
        key = a[a.index('--repository-name')+1].split('/')[-1]
        print('sha256:'+dict(orchestrator='a',auth='b',order='c')[key]*64)
    elif a[:3] == ['ecs','wait','services-stable']: pass
    elif a[:2] == ['ecs','describe-services']:
        key = a[a.index('--services')+1].split('-')[-1]
        print('arn:task/'+key+(':0' if os.environ.get('TEST_ROLLBACK')==key else ':1'))
    else: sys.exit(22)
elif name == 'docker':
    if a[0] == 'login': assert sys.stdin.read().strip() == 'synthetic-secret'
    elif a[0] == 'push' and '/auth:' in a[1] and os.environ.get('TEST_PUSH_FAIL'): sys.exit(23)
    elif a[0] not in ['push','buildx']: sys.exit(24)
'''
    for name in ['aws', 'docker', 'terraform']:
        p = bin_dir / name
        p.write_text(mock)
        p.chmod(0o755)
    env = dict(os.environ, PATH=str(bin_dir)+os.pathsep+os.environ['PATH'], TEST_COMMAND_LOG=str(t/'commands.jsonl'))
    script = package / 'scripts/Deploy.ps1'
    def run(mode, success=True, extra=None, stdin=''):
        result = subprocess.run([pwsh, '-NoProfile', '-File', str(script), '-Mode', mode, '-RepoPath', str(repo)], env=dict(env, **(extra or {})), input=stdin, text=True, capture_output=True)
        if (result.returncode == 0) != success:
            raise AssertionError(result.stdout+'\n'+result.stderr)
        assert 'synthetic-secret' not in result.stdout+result.stderr
        return result
    run('Publish')
    manifest_path = package/'terraform/stack/images.auto.tfvars.json'
    before = manifest_path.read_bytes()
    images = json.loads(before)['image_uris']
    assert set(images) == {'orchestrator','auth','order'}
    for k, char in [('orchestrator','a'),('auth','b'),('order','c')]:
        assert images[k].endswith('@sha256:'+char*64)
    commands = [json.loads(x) for x in (t/'commands.jsonl').read_text().splitlines()]
    builds = [i for i,(tool,args) in enumerate(commands) if tool=='docker' and args[0]=='buildx']
    pushes = [i for i,(tool,args) in enumerate(commands) if tool=='docker' and args[0]=='push']
    assert len(builds)==len(pushes)==3 and max(builds)<min(pushes)
    run('Publish', success=False, extra={'TEST_PUSH_FAIL':'1'})
    assert manifest_path.read_bytes()==before, 'Partial push must preserve prior release manifest'
    run('Plan')
    run('Apply', stdin='deploy\n')
    run('Verify', success=False, extra={'TEST_ROLLBACK':'auth'})
    (repo/'dirty.txt').write_text('uncommitted')
    run('Publish', success=False)
    print('PASS: three-image publish/order/digests, failed-push preservation, plan/apply, rollback detection, dirty-checkout rejection; no secrets in output.')
