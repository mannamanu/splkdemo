# MISMO monorepo deployment: three services on one ECS cluster

This replaces the earlier single-service deployment template with ONE shared stack:

| Resource | Count / purpose |
|---|---|
| ECS cluster | 1 for the environment |
| ECR repositories | 3: orchestrator, auth, order |
| ECS services/task definitions | 3; each scales and deploys independently |
| Application Load Balancer | 1, forwards only to orchestrator |
| API Route 53 record | 1 alias to the ALB |
| Private Cloud Map namespace | 1, automatically backed by a private DNS zone |
| Private discovery services | 2: auth and order |
| Task security groups, logs, IAM roles | Separate for each service |

```mermaid
flowchart TD
  Client[API client] -->|HTTPS| ALB[ALB: Route 53 API hostname]
  subgraph ECS[One ECS cluster]
    O[Orchestrator]
    A[AuthService]
    R[OrderService]
  end
  ALB --> O
  O -->|Private DNS, HTTP 8080| A
  O -->|Private DNS, HTTP 8080| R
  O -->|gRPC| T[Separately hosted Temporal]
```

The diagram shows intended network paths, not implemented workflow/business logic.
The default API ALB is INTERNAL. Auth/Order have no ALB and no public IP or public
DNS record. All containers listen on 8080 on separate task network interfaces.

## What this package does and does not do

It builds all three images from ONE clean Git checkout, publishes three immutable
ECR tags, selects image digests, and creates a Terraform plan. ECS rolls out the
three services independently. This is NOT an atomic three-service transaction:
mixed old/new versions can coexist, and one service may roll back while others
succeed. Keep APIs backward compatible and inspect every service's revision.

It does not provision the existing VPC, NAT/endpoints, ACM certificate, API hosted
zone, Temporal server/database or application Java code. It does not require Git
credentials in AWS, and it does not push commits or deploy anything on download.
No AWS account credentials or actual repository URL were supplied to generate it.

## 1. Prerequisites

Install Git, Docker Desktop (Linux containers), AWS CLI v2, Terraform >=1.10 <2,
and PowerShell 7. Java/Maven on the host are unnecessary for Docker builds.

- https://git-scm.com/downloads
- https://docs.docker.com/desktop/
- https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
- https://developer.hashicorp.com/terraform/install
- https://learn.microsoft.com/powershell/scripting/install/installing-powershell

```powershell
aws configure sso --profile my-dev
aws sso login --profile my-dev
$env:AWS_PROFILE = 'my-dev'
aws sts get-caller-identity
docker version
terraform version
pwsh --version
```

Use your approved deployment role. It must manage ECR, ECS, ELB, Cloud Map, Route 53,
security groups, logs and the included IAM roles, including iam:PassRole. ECS may
need its service-linked role created on first use. No application task is given
AWS API permissions by default; secret-read permissions belong to execution roles.

## 2. Prepare the existing AWS network and dependencies

Fill in your account ID, region, VPC ID and private task subnets across at least
two availability zones. Enable VPC DNS support and DNS hostnames. Supply ALB
subnets in two AZs; these can be the same private subnets for an internal ALB.

Private tasks need NAT or the appropriate ECR API/ECR Docker interface endpoints,
S3 gateway endpoint (image layers), CloudWatch Logs endpoint and Secrets Manager
endpoint if used. Endpoints must allow HTTPS from task networks/security groups.
These are existing-network prerequisites, not resources created here. DNS lookup
must reach the VPC resolver. Outbound task traffic is initially unrestricted IPv4;
narrow it to approved destinations when integrating with your network policy.

Provide an ISSUED ACM certificate in the deployment region, covering the API
hostname, and an existing Route 53 hosted zone. Internal API access needs VPC
routing (VPN/Direct Connect/etc.) and DNS resolution. Use a private API hosted zone
associated with the VPC when appropriate. Public ACM certificates require a
publicly validatable owned domain even for internal ALBs; for private-only names
use an appropriate imported/private certificate with client trust configured.

`discovery_namespace` creates a NEW private namespace/zone, e.g. mismo-dev.internal.
Choose a suffix not already owned by an existing private zone in this VPC. Do not
use the same suffix as an overlapping existing API zone. It is distinct from
`hosted_zone_id`, which is used only for the orchestrator API record.

For public API access set internal_alb=false, provide public ALB subnets with
internet gateway routes and a public hosted zone, and choose approved client CIDRs.
Auth/Order remain private. HTTPS is terminated at ALB; backend HTTP is plaintext
inside the VPC. If internal encryption is required, add service-to-service TLS or
Service Connect TLS before production. No authentication gateway/WAF is included.

### Temporal prerequisite

You do not have Temporal Cloud: supply a reachable, separately deployed self-hosted
Temporal frontend with persistent storage, a created namespace and matching client
TLS/auth settings. Its DNS/NLB/RDS are NOT created here. Permit gRPC (normally TCP
7233) from the orchestrator task security group to that frontend; Terraform outputs
that security group ID. An internal dependency SG may need a separate rule.

The previous Cloud-only Java sample enforces TLS and a nonempty API key. Adapt that
code for your self-hosted server; changing only TEMPORAL_TARGET is insufficient.
This package deliberately does not invent TLS environment names that your code
has not implemented. Do not deploy a development SQLite Temporal server to production
or use localhost/host.docker.internal as an AWS endpoint. Unreachable Temporal will
make the original orchestrator readiness probe DOWN and prevent a healthy rollout.

## 3. Prepare the monorepo

Replace the example URL/branch:

```powershell
git clone --branch main https://github.com/YOUR-ORG/YOUR-REPO.git C:\work\mismo
cd C:\work\mismo
git status
```

Expected default module layout:

- pom.xml (Maven reactor parent)
- orchestrator-service/pom.xml
- auth-service/pom.xml
- order-service/pom.xml
- Dockerfile at repo root

Copy the supplied Dockerfile.corretto into your repository as Dockerfile, merge
.dockerignore.example into its root .dockerignore, and commit these changes. The
Dockerfile compiles and runs on Amazon Corretto 25, builds `-pl SERVICE -am verify`,
and expects the selected module to produce `target/app.jar`. Adjust this copy path
if your Maven build produces a differently named executable JAR. Tests run during
the build. Pin approved base-image digests for repeatable production builds.

Keep this extracted deployment package outside the checkout (e.g.
C:\work\mismo-aws-monorepo), or commit its source and merge its .gitignore rules
if storing it in the repo. Script builds require a clean Git checkout. Ignored
files can still be copied by Docker: exclude secrets, .env, Terraform state/plans,
certificates/private keys and local credentials from each actual build context.

Edit `services.build.json` for your actual monorepo paths. Keys MUST remain
orchestrator/auth/order. `module` is the Maven -pl selector, while `context` and
`dockerfile` are paths relative to the Git root. All three may share one Dockerfile.
For `services/auth-service/pom.xml`, for example, use module `services/auth-service`.
Keep context `.` when the parent POM or sibling modules are needed. Custom Dockerfiles
must accept the relevant build layout and meet the runtime contract below.

## 4. Wire application URLs and health probes

Terraform automatically supplies ONLY to the orchestrator:

```dotenv
AUTH_SERVICE_URL=http://auth.mismo-dev.internal:8080
ORDER_SERVICE_URL=http://order.mismo-dev.internal:8080
```

The suffix follows your discovery_namespace. These are environment variable names
chosen by this package, NOT automatic Temporal or Spring Boot integrations. Merge
`examples/application-downstream.yml` into your application configuration and bind
your HTTP clients to services.auth.base-url and services.order.base-url, or adapt
the client code to read the environment names directly. Calls from Temporal belong
in Activities, not deterministic Workflow code. The earlier health-only sample has
no business calls/workers; this infrastructure does not add them.

Every image must contain curl, run as UID/GID10001, listen on SERVER_PORT=8080 and
expose `/actuator/health/liveness` without authentication inside the task. Orchestrator
also exposes `/actuator/health/readiness` for the ALB. Cloud Map tracks ECS container
health (liveness here); it does not independently test HTTP readiness. Handle startup
races, timeouts and failures in clients. Only retry non-idempotent operations with
an appropriate idempotency strategy.

Private DNS returns task IP addresses; it is not an HTTP load balancer or proxy.
The supplied Corretto Dockerfile limits standard JVM DNS cache TTL to 10 seconds
and negative caching to 1 second. Review separate HTTP-client/Netty DNS caches and
connection lifetimes when using a custom image/client so task IP changes are honored.
DNS and ALB health may fail open if every endpoint is unhealthy; neither is an
authorization boundary. The SGs enforce ALB -> orchestrator and orchestrator ->
auth/order on port 8080; there is no other task ingress rule.

## 5. Set Terraform inputs (once per environment)

Run from the extracted deployment package root in PowerShell 7:

```powershell
Copy-Item terraform/registry/terraform.tfvars.example terraform/registry/terraform.tfvars
Copy-Item terraform/stack/terraform.tfvars.example terraform/stack/terraform.tfvars
notepad terraform/registry/terraform.tfvars
notepad terraform/stack/terraform.tfvars
```

Use the SAME name/account/region in both roots. Replace all placeholder IDs and
hostnames. Set per-service environment variables and resource sizing in `services`.
Default 512 CPU units/1024 MiB and one task per service are DEV starting points.
Adjust based on measured load; use 2+ tasks for availability where appropriate.
No autoscaling policy is included; desired_count is managed by Terraform.

Use only nonsecrets in environment. For secret values, use per-service secret_arns
maps of environment name -> existing full Secrets Manager secret ARN. Each secret
contains the whole desired value. Add customer-managed KMS key ARNs when needed,
and permit the execution role in the KMS key policy. Terraform does not retrieve
secret values. Environment names cannot overlap generated URL/port keys or secrets.
Auth/Order need no Temporal settings for this design. Rotating an injected secret
requires task replacement; restart/deploy after rotation.

## 6. Bootstrap three ECR repositories

```powershell
pwsh -File scripts/Deploy.ps1 -Mode Bootstrap
```

Terraform previews and prompts before creating all three repositories in a separate
registry state. No service is deployed yet. Never switch old single-service state
files into this package; see migration below.

## 7. Publish, review and deploy the whole monorepo

```powershell
pwsh -File scripts/Deploy.ps1 -Mode Publish -RepoPath 'C:\work\mismo'
pwsh -File scripts/Deploy.ps1 -Mode Plan
pwsh -File scripts/Deploy.ps1 -Mode Apply
```

Publish builds all three first, then pushes each with the same unique Git-based
release tag. Only after every push/digest lookup succeeds does it write
`terraform/stack/images.auto.tfvars.json`. A failed push may leave some ECR images
but leaves the prior release selection intact. It creates no application resources.

Plan validates and saves release.tfplan. Apply displays that exact saved plan,
asks you to type `deploy`, applies it, waits for ECS and verifies ALL three task
revisions. A stable service on an older rolled-back revision is treated as failure.

Or combine the three steps (still asks after showing the plan):

```powershell
pwsh -File scripts/Deploy.ps1 -Mode Deploy -RepoPath 'C:\work\mismo'
```

No repeated `-Service` commands, independent folders, or three ALBs are necessary.
To use an alternate build layout file pass `-BuildConfig 'C:\path\services.build.json'`.
The script uses the checked-out commit; it never pulls, resets or switches branches.
Do not edit the source checkout during a build. Sequential/concurrent Terraform
changes from different terminals against the same state are not supported by the script.

Services roll out concurrently, and upstream clients must tolerate downstream
startup/replacement. API backwards compatibility is required during rolling updates.
Initial deployment may have no prior stable revision to roll back to.

## 8. Verify and troubleshoot

```powershell
pwsh -File scripts/Deploy.ps1 -Mode Verify
terraform -chdir=terraform/stack output
aws logs tail /ecs/mismo-dev/orchestrator --since 10m --follow --region us-east-1
aws logs tail /ecs/mismo-dev/auth --since 10m --region us-east-1
aws logs tail /ecs/mismo-dev/order --since 10m --region us-east-1
curl.exe -i https://mismo.dev.example.com/actuator/health/readiness
```

Use your actual names/region and connect through the VPC network for internal APIs.
Auth/Order cannot be called directly from your laptop with these SGs. Test discovery
from orchestrator code or an explicitly authorized diagnostic path inside the VPC.
This package does not enable ECS Exec or add a public diagnostic endpoint.

- ECR/log/secret initialization errors: check NAT/endpoints, IAM, KMS and routes.
- Orchestrator readiness DOWN: inspect Temporal connectivity/auth/namespace.
- Downstream DNS failure: VPC DNS flags, suffix, Cloud Map registration/task health.
- Service calls still use localhost: wire the generated environment variables into clients.
- Old IP after rollout: HTTP client resolver/cache and connection lifetime.
- ECS stable but script fails: a service rolled back; inspect revision and events.
- Terraform DNS collision: use a fresh API hostname/discovery suffix, or plan a careful import.

## 9. Update, rollback, migrate and manage state

Commit changes and repeat Publish/Plan/Apply or Deploy. All images are pinned by
digest. For rollback, restore known-good entries in images.auto.tfvars.json and run
Plan/Apply. Keep all three keys even when rolling back only one service. Preserve
release manifests/digests in your approved release records; no ECR auto-expiry policy
is included so deployment/rollback images are not unexpectedly deleted.

If the earlier single-service package was never applied, start this package with
new state. If it WAS deployed, do NOT reuse/overwrite its state. For the first shared
stack use a fresh name/hostname/discovery suffix, validate the new stack, then plan
DNS cutover and explicit old-resource cleanup. Existing resources require deliberate
Terraform imports/moved blocks; this package contains no automatic state migration.

Each environment has two states: registry and shared stack. For a first isolated
local trial Terraform uses local state; protect/back it up. For team use create an
existing encrypted, versioned S3 state bucket and configure a backend in BOTH roots:

```hcl
terraform {
  backend "s3" {}
}
```

Initialize each with a distinct key (registry.tfstate and stack.tfstate):

```powershell
terraform -chdir=terraform/registry init -migrate-state `
  -backend-config='bucket=YOUR-STATE-BUCKET' `
  -backend-config='key=mismo/dev/registry.tfstate' `
  -backend-config='region=us-east-1' `
  -backend-config='encrypt=true' -backend-config='use_lockfile=true'
```

Repeat for stack using `key=mismo/dev/stack.tfstate`. Use separate keys/configuration
for QA/PROD. Do not alternate environment names within the same state. Commit provider
lockfiles; keep actual tfvars, state, generated image manifests and saved plans private.

## 10. Cleanup and costs

Apply creates billable ECS tasks, an ALB, ECR, logs and DNS/Cloud Map resources.
Existing networking and Temporal/database resources may also incur charges. Nothing
has been deployed by generating this package. Destroy shared stack only after
reviewing the plan and preserving logs you need:

```powershell
terraform -chdir=terraform/stack plan -destroy
terraform -chdir=terraform/stack destroy
```

This removes the three services, API record and private discovery namespace/zone;
AWS may take time to deregister tasks before deleting discovery resources. It does
not delete your existing VPC, certificate, API hosted zone or Temporal/database.
ECR is retained in separate registry state, with force_delete=false; deal explicitly
with its images before deleting that root. Never delete state as a cleanup method.

## Verification and references

See VERIFICATION.md for executed checks and limitations. Validate locally before apply:

```powershell
terraform -chdir=terraform/registry init
terraform -chdir=terraform/registry validate
terraform -chdir=terraform/stack init
terraform -chdir=terraform/stack validate
terraform -chdir=terraform/stack test
```

The supplied Terraform tests mock AWS and do not create real resources.

- https://docs.aws.amazon.com/AmazonECS/latest/developerguide/service-discovery.html
- https://docs.aws.amazon.com/AmazonECS/latest/developerguide/networking-connecting-services.html
- https://docs.aws.amazon.com/AmazonECR/latest/userguide/vpc-endpoints.html
- https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/routing-to-elb-load-balancer.html
- https://docs.aws.amazon.com/corretto/latest/corretto-25-ug/docker-install.html
