# Verification

Checked 2026-09-28 UTC. No AWS resources were created or changed.

Passed:
- Terraform 1.14.0 syntax parsing/formatting (`terraform fmt -check -recursive`).
- PowerShell 7.5.3 syntax parsing.
- Executed the included offline `tests/check_deploy_script.py` using real Git and
  PowerShell on Linux with simulated AWS, Docker and Terraform subprocesses.
  Verified all three builds precede publishing, all three image digests are selected,
  a failed second push preserves the old manifest, Plan/Apply flows complete,
  rolled-back service revisions are rejected, dirty Git checkouts are rejected,
  and the synthetic login secret is absent from captured output.
- Inspected generated resource topology and source-only ZIP integrity.

Not verified:
- Terraform AWS-provider schema validation and mocked plan tests. Official provider
  installation completed, but subsequent validation reported cached-package checksum
  mismatches in this environment. Testing an alternate provider version encountered
  the same issue. Verification was not disabled or bypassed. The delivered lock files
  retain the official initialized AWS provider 6.66.0 selection/checksums.
- Real AWS plan/apply, ECR push, Docker build, native Windows behavior, Route 53/Cloud Map
  resolution, TLS, Temporal connectivity or health checks of actual deployed services.
- Your repository layout/application code, since it has not been provided.

Before deploying, run README validation commands on your machine and review the
real Terraform plan with your own values. The included stack tests mock AWS; they
should not create resources. If a provider checksum fails, investigate the official
installation/cache instead of weakening verification.

To reproduce the offline PowerShell behavior checks on Linux:

    python3 tests/check_deploy_script.py /path/to/pwsh

A passing simulated test establishes script control flow, not real cloud success.
