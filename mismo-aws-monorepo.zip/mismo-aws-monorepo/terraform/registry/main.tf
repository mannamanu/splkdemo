locals { services = toset(["orchestrator", "auth", "order"]) }
resource "aws_ecr_repository" "service" {
  for_each             = local.services
  name                 = "${var.name}/${each.key}"
  image_tag_mutability = "IMMUTABLE"
  force_delete         = false
  image_scanning_configuration { scan_on_push = true }
  encryption_configuration { encryption_type = "AES256" }
}
output "repository_urls" { value = { for key, repo in aws_ecr_repository.service : key => repo.repository_url } }
output "repository_names" { value = { for key, repo in aws_ecr_repository.service : key => repo.name } }
output "aws_region" { value = var.aws_region }
output "aws_account_id" { value = var.aws_account_id }
output "name" { value = var.name }
