data "aws_vpc" "selected" { id = var.vpc_id }
data "aws_subnet" "selected" {
  for_each = toset(concat(var.task_subnet_ids, var.alb_subnet_ids))
  id       = each.value
}
resource "aws_security_group" "alb" {
  name_prefix = "${var.name}-alb-"
  vpc_id      = var.vpc_id
}
resource "aws_security_group" "task" {
  for_each    = var.services
  name_prefix = "${var.name}-${each.key}-"
  vpc_id      = var.vpc_id
}
resource "aws_vpc_security_group_ingress_rule" "https" {
  for_each          = toset(var.allowed_client_cidrs)
  security_group_id = aws_security_group.alb.id
  cidr_ipv4         = each.value
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
}
resource "aws_vpc_security_group_egress_rule" "alb_to_orchestrator" {
  security_group_id            = aws_security_group.alb.id
  referenced_security_group_id = aws_security_group.task["orchestrator"].id
  ip_protocol                  = "tcp"
  from_port                    = 8080
  to_port                      = 8080
}
resource "aws_vpc_security_group_ingress_rule" "orchestrator" {
  security_group_id            = aws_security_group.task["orchestrator"].id
  referenced_security_group_id = aws_security_group.alb.id
  ip_protocol                  = "tcp"
  from_port                    = 8080
  to_port                      = 8080
}
resource "aws_vpc_security_group_ingress_rule" "downstream" {
  for_each                     = toset(["auth", "order"])
  security_group_id            = aws_security_group.task[each.key].id
  referenced_security_group_id = aws_security_group.task["orchestrator"].id
  ip_protocol                  = "tcp"
  from_port                    = 8080
  to_port                      = 8080
}
resource "aws_vpc_security_group_egress_rule" "tasks" {
  for_each          = var.services
  security_group_id = aws_security_group.task[each.key].id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
  description       = "Dependencies through existing VPC routes; tighten to approved endpoints as needed"
}
resource "aws_service_discovery_private_dns_namespace" "app" {
  name        = var.discovery_namespace
  vpc         = var.vpc_id
  description = "Private DNS for ${var.name} downstream services"
  lifecycle {
    precondition {
      condition     = data.aws_vpc.selected.enable_dns_support && data.aws_vpc.selected.enable_dns_hostnames
      error_message = "The existing VPC must enable DNS support and DNS hostnames."
    }
  }
}
resource "aws_service_discovery_service" "downstream" {
  for_each = toset(["auth", "order"])
  name     = each.key
  dns_config {
    namespace_id   = aws_service_discovery_private_dns_namespace.app.id
    routing_policy = "MULTIVALUE"
    dns_records {
      type = "A"
      ttl  = 10
    }
  }
  health_check_custom_config { failure_threshold = 1 }
}
