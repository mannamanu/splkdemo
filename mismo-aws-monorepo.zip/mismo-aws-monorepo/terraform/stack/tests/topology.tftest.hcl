mock_provider "aws" {
  mock_data "aws_partition" { defaults = { partition = "aws" } }
}
override_data {
  target = data.aws_vpc.selected
  values = { enable_dns_support = true, enable_dns_hostnames = true }
}
override_data {
  target = data.aws_subnet.selected["subnet-aaa"]
  values = { vpc_id = "vpc-aaa", availability_zone = "us-east-1a" }
}
override_data {
  target = data.aws_subnet.selected["subnet-bbb"]
  values = { vpc_id = "vpc-aaa", availability_zone = "us-east-1b" }
}
variables {
  aws_region           = "us-east-1"
  aws_account_id       = "123456789012"
  name                 = "mismo-test"
  vpc_id               = "vpc-aaa"
  task_subnet_ids      = ["subnet-aaa", "subnet-bbb"]
  alb_subnet_ids       = ["subnet-aaa", "subnet-bbb"]
  allowed_client_cidrs = ["10.0.0.0/8"]
  certificate_arn      = "arn:aws:acm:us-east-1:123456789012:certificate/00000000-0000-0000-0000-000000000000"
  hosted_zone_id       = "ZTEST"
  domain_name          = "mismo.example.com"
  image_uris = {
    orchestrator = "123456789012.dkr.ecr.us-east-1.amazonaws.com/mismo-test/orchestrator@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    auth         = "123456789012.dkr.ecr.us-east-1.amazonaws.com/mismo-test/auth@sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
    order        = "123456789012.dkr.ecr.us-east-1.amazonaws.com/mismo-test/order@sha256:cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"
  }
}
run "shared_private_topology" {
  command = plan
  assert {
    condition     = length(aws_ecs_service.app) == 3 && length(aws_ecs_task_definition.app) == 3
    error_message = "Deploy three separate ECS services and task definitions."
  }
  assert {
    condition     = length(aws_ecs_service.app["orchestrator"].load_balancer) == 1 && length(aws_ecs_service.app["auth"].load_balancer) == 0 && length(aws_ecs_service.app["order"].load_balancer) == 0
    error_message = "Only orchestrator may attach to the ALB."
  }
  assert {
    condition     = length(aws_service_discovery_service.downstream) == 2 && length(aws_ecs_service.app["orchestrator"].service_registries) == 0
    error_message = "Only downstream services need private discovery."
  }
  assert {
    condition     = aws_lb.app.internal && alltrue([for s in aws_ecs_service.app : !s.network_configuration[0].assign_public_ip])
    error_message = "Default ALB and tasks must be private."
  }
  assert {
    condition     = local.downstream_urls.AUTH_SERVICE_URL == "http://auth.mismo-dev.internal:8080" && local.downstream_urls.ORDER_SERVICE_URL == "http://order.mismo-dev.internal:8080"
    error_message = "DNS URLs must match registered service names."
  }
}
run "reject_incomplete_release" {
  command = plan
  variables { image_uris = {} }
  expect_failures = [var.image_uris]
}
run "reject_reserved_environment" {
  command = plan
  variables {
    services = { orchestrator = { environment = { AUTH_SERVICE_URL = "http://wrong" } }, auth = {}, order = {} }
  }
  expect_failures = [var.services]
}
