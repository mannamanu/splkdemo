variable "vpc_id" { type = string }
variable "task_subnet_ids" {
  type = list(string)
  validation {
    condition     = length(var.task_subnet_ids) >= 2
    error_message = "Supply private task subnets in at least two availability zones."
  }
}
variable "alb_subnet_ids" {
  type = list(string)
  validation {
    condition     = length(var.alb_subnet_ids) >= 2
    error_message = "Supply ALB subnets in at least two availability zones."
  }
}
variable "internal_alb" {
  type    = bool
  default = true
}
variable "allowed_client_cidrs" {
  type = list(string)
  validation {
    condition     = length(var.allowed_client_cidrs) > 0 && alltrue([for cidr in var.allowed_client_cidrs : can(cidrnetmask(cidr))])
    error_message = "Specify the IPv4 CIDRs allowed to reach HTTPS."
  }
}
variable "certificate_arn" {
  type        = string
  description = "Existing issued ACM certificate in the deployment region, covering domain_name."
}
variable "hosted_zone_id" { type = string }
variable "domain_name" { type = string }

variable "discovery_namespace" {
  type        = string
  default     = "mismo-dev.internal"
  description = "New private DNS namespace, unique in this VPC; no existing hosted zone is adopted."
  validation {
    condition     = can(regex("^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$", var.discovery_namespace)) && length(var.discovery_namespace) <= 200
    error_message = "Use a lowercase DNS suffix without a trailing dot."
  }
}
variable "image_uris" {
  type        = map(string)
  description = "Exactly orchestrator/auth/order -> digest-pinned ECR images."
  validation {
    condition     = toset(keys(var.image_uris)) == toset(["orchestrator", "auth", "order"]) && alltrue([for uri in values(var.image_uris) : can(regex("^[0-9]{12}\\.dkr\\.ecr\\.[a-z0-9-]+\\.amazonaws\\.com(\\.cn)?/.+@sha256:[0-9a-f]{64}$", uri))])
    error_message = "Supply all three service keys with ECR @sha256 image URIs."
  }
}
variable "services" {
  type = map(object({
    desired_count       = optional(number, 1)
    cpu                 = optional(number, 512)
    memory              = optional(number, 1024)
    environment         = optional(map(string), {})
    secret_arns         = optional(map(string), {})
    secret_kms_key_arns = optional(list(string), [])
  }))
  default = { orchestrator = {}, auth = {}, order = {} }
  validation {
    condition     = toset(keys(var.services)) == toset(["orchestrator", "auth", "order"])
    error_message = "services must contain exactly orchestrator, auth and order."
  }
  validation {
    condition     = alltrue([for s in values(var.services) : s.desired_count >= 1 && floor(s.desired_count) == s.desired_count])
    error_message = "Each desired_count must be a positive integer."
  }
  validation {
    condition = alltrue([for s in values(var.services) : contains(lookup({
      "256"  = [512, 1024, 2048]
      "512"  = [1024, 2048, 3072, 4096]
      "1024" = [2048, 3072, 4096, 5120, 6144, 7168, 8192]
      "2048" = [4096, 5120, 6144, 7168, 8192, 9216, 10240, 11264, 12288, 13312, 14336, 15360, 16384]
    }, tostring(s.cpu), []), s.memory)])
    error_message = "Use a supported Fargate CPU/memory pair: 256/512/1024/2048 CPU units with matching memory MiB."
  }
  validation {
    condition     = alltrue(flatten([for s in values(var.services) : [for arn in values(s.secret_arns) : can(regex("^arn:[^:]+:secretsmanager:[^:]+:[0-9]{12}:secret:[^:]+$", arn))]]))
    error_message = "secret_arns values must be complete Secrets Manager ARNs without JSON-key/version selectors."
  }
  validation {
    condition     = alltrue([for s in values(var.services) : length(setintersection(toset(concat(keys(s.environment), keys(s.secret_arns))), toset(["SERVER_PORT", "AUTH_SERVICE_URL", "ORDER_SERVICE_URL"]))) == 0 && length(setintersection(toset(keys(s.environment)), toset(keys(s.secret_arns)))) == 0])
    error_message = "Do not override generated SERVER_PORT/AUTH_SERVICE_URL/ORDER_SERVICE_URL or duplicate names between environment and secrets."
  }
}
