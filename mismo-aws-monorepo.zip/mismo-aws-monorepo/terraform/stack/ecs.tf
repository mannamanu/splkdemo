data "aws_partition" "current" {}
locals {
  downstream_urls = {
    AUTH_SERVICE_URL  = "http://auth.${var.discovery_namespace}:8080"
    ORDER_SERVICE_URL = "http://order.${var.discovery_namespace}:8080"
  }
  task_trust = jsonencode({
    Version   = "2012-10-17"
    Statement = [{ Effect = "Allow", Principal = { Service = "ecs-tasks.amazonaws.com" }, Action = "sts:AssumeRole" }]
  })
}
resource "aws_ecs_cluster" "app" { name = var.name }
resource "aws_cloudwatch_log_group" "app" {
  for_each          = var.services
  name              = "/ecs/${var.name}/${each.key}"
  retention_in_days = 30
}
resource "aws_iam_role" "execution" {
  for_each           = var.services
  name               = "${var.name}-${each.key}-exec"
  assume_role_policy = local.task_trust
}
resource "aws_iam_role_policy_attachment" "execution" {
  for_each   = var.services
  role       = aws_iam_role.execution[each.key].name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}
resource "aws_iam_role_policy" "secrets" {
  for_each = { for key, service in var.services : key => service if length(service.secret_arns) > 0 }
  role     = aws_iam_role.execution[each.key].id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = concat(
      [{ Effect = "Allow", Action = ["secretsmanager:GetSecretValue"], Resource = values(each.value.secret_arns) }],
      length(each.value.secret_kms_key_arns) > 0 ? [{ Effect = "Allow", Action = ["kms:Decrypt"], Resource = each.value.secret_kms_key_arns }] : []
    )
  })
}
resource "aws_iam_role" "task" {
  for_each           = var.services
  name               = "${var.name}-${each.key}-task"
  assume_role_policy = local.task_trust
  # No AWS API permissions for application code by default.
}
resource "aws_ecs_task_definition" "app" {
  for_each                 = var.services
  family                   = "${var.name}-${each.key}"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = tostring(each.value.cpu)
  memory                   = tostring(each.value.memory)
  execution_role_arn       = aws_iam_role.execution[each.key].arn
  task_role_arn            = aws_iam_role.task[each.key].arn
  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "X86_64"
  }
  container_definitions = jsonencode([{
    name         = each.key
    image        = var.image_uris[each.key]
    essential    = true
    user         = "10001:10001"
    portMappings = [{ containerPort = 8080, hostPort = 8080, protocol = "tcp" }]
    environment  = [for key, value in merge(each.value.environment, { SERVER_PORT = "8080" }, each.key == "orchestrator" ? local.downstream_urls : {}) : { name = key, value = value }]
    secrets      = [for key, value in each.value.secret_arns : { name = key, valueFrom = value }]
    stopTimeout  = 60
    healthCheck = {
      command     = ["CMD-SHELL", "curl --fail --silent --max-time 3 http://localhost:8080/actuator/health/liveness || exit 1"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 60
    }
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.app[each.key].name
        awslogs-region        = var.aws_region
        awslogs-stream-prefix = "app"
      }
    }
  }])
}
resource "aws_ecs_service" "app" {
  for_each                           = var.services
  name                               = "${var.name}-${each.key}"
  cluster                            = aws_ecs_cluster.app.id
  task_definition                    = aws_ecs_task_definition.app[each.key].arn
  desired_count                      = each.value.desired_count
  launch_type                        = "FARGATE"
  platform_version                   = "1.4.0"
  wait_for_steady_state              = true
  health_check_grace_period_seconds  = each.key == "orchestrator" ? 120 : null
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200
  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }
  network_configuration {
    subnets          = var.task_subnet_ids
    security_groups  = [aws_security_group.task[each.key].id]
    assign_public_ip = false
  }
  dynamic "load_balancer" {
    for_each = each.key == "orchestrator" ? [1] : []
    content {
      target_group_arn = aws_lb_target_group.app.arn
      container_name   = each.key
      container_port   = 8080
    }
  }
  dynamic "service_registries" {
    for_each = each.key == "orchestrator" ? [] : [each.key]
    content { registry_arn = aws_service_discovery_service.downstream[service_registries.value].arn }
  }
  depends_on = [aws_lb_listener.https, aws_iam_role_policy_attachment.execution, aws_iam_role_policy.secrets, aws_vpc_security_group_ingress_rule.orchestrator, aws_vpc_security_group_ingress_rule.downstream, aws_vpc_security_group_egress_rule.alb_to_orchestrator, aws_vpc_security_group_egress_rule.tasks]
  timeouts {
    create = "20m"
    update = "20m"
  }
}
