output "application_url" { value = "https://${var.domain_name}" }
output "cluster_name" { value = aws_ecs_cluster.app.name }
output "service_names" { value = { for key, s in aws_ecs_service.app : key => s.name } }
output "task_definition_arns" { value = { for key, task in aws_ecs_task_definition.app : key => task.arn } }
output "task_security_group_ids" { value = { for key, sg in aws_security_group.task : key => sg.id } }
output "downstream_urls" { value = local.downstream_urls }
output "log_groups" { value = { for key, log in aws_cloudwatch_log_group.app : key => log.name } }
output "aws_region" { value = var.aws_region }
