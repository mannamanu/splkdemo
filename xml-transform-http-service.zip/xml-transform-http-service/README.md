# XML transformation service — HTTP only

One Spring Boot 4.0.8 application, Maven and JDK 25. Docker compiles/runs with Amazon
Corretto 25. No gRPC, Protocol Buffers, Temporal, database or AI runtime is required.

This is an enterprise-oriented starter with production JWT defaults, XML security
controls, bounded processing/cache settings, health/metrics, tests and an AWS
Terraform baseline. It is not a claim of production certification or load capacity.

## What the sample does

XSD **validates** document structure and values. XSLT **transforms** the document.
The included `order-v1` profile converts `samples/order.xml` to the shape shown in
`samples/expected-output.xml`, validating both input and output. These are small
synthetic order schemas, not the full MISMO specification. Transformation output is
XML; validation returns JSON over HTTP.

| Transport | Endpoint / method | Behavior |
|---|---|---|
| HTTP GET | `/api/v1/profiles` | List allowed profiles |
| HTTP POST | `/api/v1/profiles/order-v1/validate` | Validate raw XML against input XSD |
| HTTP POST | `/api/v1/profiles/order-v1/transform` | Validate, transform with XSLT, validate output |

Source map:

- `src/main/java/com/example/xml/core`: shared engine, errors, limits and caches.
- `http`: Spring MVC controller and status mapping.
- `security`: JWT decoder/validators and HTTP policy.
- `observability`: numeric readiness/liveness gauges.
- `monitoring`: example Prometheus scrape configuration.
- `xml-assets/order-v1`: input XSD, output XSD and XSLT.
- `src/test/java`: Mockito unit tests, XML tests and real transport integration tests.
- `samples`: XML documents and HTTP requests; `scripts`: image publisher and JDK selector.
- `infra`: ECR/ECS/ALB/Route 53 Terraform; `docs`: architecture and AI usage.

## 1. Obtain the code and prerequisites

Extract this ZIP and open a terminal in `xml-transform-http-service`, containing pom.xml.
No remote Git repository was created. If you publish it, clone YOUR real URL:

```bash
git clone https://github.com/YOUR-ORG/xml-transform-http-service.git
cd xml-transform-http-service
```

For Docker: install/start Docker Desktop with Linux containers (or Docker Engine
and Compose v2 on Linux). Host Java/Maven are not needed for this path.
https://docs.docker.com/get-started/get-docker/

For native execution: install Amazon Corretto JDK25 and Maven 3.9.11+ (3.9.x).
https://docs.aws.amazon.com/corretto/latest/corretto-25-ug/downloads-list.html
https://maven.apache.org/install.html

```bash
java --version
javac -version
mvn -version
```

Java/javac and Maven's Java version must all report 25. If JDK21 is still installed,
select the JDK25 home in your terminal/IDE without uninstalling it. PowerShell example:

```powershell
$env:JAVA_HOME = 'C:\Java\jdk-25' # Replace with actual Corretto JDK root
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
mvn -version
```

For AWS later also install Terraform, AWS CLI v2 and PowerShell 7 (see infra/README.md).
Internet access is needed to fetch Maven dependencies/container images. Use your
organization's approved Maven proxy/trust settings; never disable TLS verification.

## 2. Run locally with Docker

```bash
docker compose up --build -d
docker compose ps
docker compose logs --tail=100 -f
```

The build runs tests. One container exposes localhost HTTP8080. Compose
explicitly activates the unauthenticated `local` profile and binds published ports
to 127.0.0.1. Do not reuse this profile in AWS. Press Ctrl+C to stop following logs.

```bash
docker compose down
```

There is no database. Compose mounts `./xml-assets` read-only at `/opt/xml-assets`.
Cache entries disappear with the process.
After code changes rerun `docker compose up --build -d`. After changing Compose
values recreate the container with `docker compose up -d --force-recreate`.

## 3. Or run natively

From the project root:

```bash
mvn -B -ntp verify
java -jar target/app.jar --spring.profiles.active=local
```

The same command works in PowerShell and Bash. IntelliJ: open pom.xml as Maven,
select JDK25 for project and Maven runner, run `Application` with active profile
`local`.
Native servers bind their configured interfaces; use your host firewall for local
access. Stop with Ctrl+C; the HTTP server shuts down gracefully.

## External XSD and XSLT assets

Assets live outside the application classpath at the project root:

- `xml-assets/order-v1/order-input.xsd`
- `xml-assets/order-v1/order-output.xsd`
- `xml-assets/order-v1/order-to-normalized.xsl`

Native execution defaults to `./xml-assets` relative to the working directory.
Set `XML_ASSETS_DIR` to an absolute folder when starting from another directory:

```bash
XML_ASSETS_DIR=/path/to/xml-assets java -jar target/app.jar --spring.profiles.active=local
```

PowerShell:

```powershell
$env:XML_ASSETS_DIR = 'C:\projects\xml-assets'
java -jar target/app.jar --spring.profiles.active=local
```

Compose uses a read-only bind mount. To keep assets in the repository's parent folder,
change the volume `source` to `../xml-assets`; leave its container `target` unchanged.
The folder must exist and be readable by container user 10001. Missing or invalid
assets fail application startup. Schemas/stylesheets compile once at startup; edits
require `docker compose restart app` (or a native process restart). No hot reload is
implemented. Restart also clears cached results, preventing stale mappings.

The Docker image includes an immutable asset snapshot at `/opt/xml-assets` for AWS.
ECS can use that image directly without a host bind mount. Rebuild/publish the image
and redeploy when mappings change; deploy a new profile version for contract changes.
The configured path is operator-owned; request profiles cannot select arbitrary files.
External XSD imports, XSLT includes and network reads remain disabled.

## 4. Sample HTTP POST requests

Windows PowerShell (use curl.exe, not the old PowerShell curl alias):

```powershell
curl.exe -i http://localhost:8080/actuator/health/readiness
curl.exe -i http://localhost:8080/api/v1/profiles

curl.exe -i -X POST http://localhost:8080/api/v1/profiles/order-v1/transform `
  -H "Content-Type: application/xml" `
  -H "Accept: application/xml" `
  --data-binary "@samples/order.xml"

curl.exe -i -X POST http://localhost:8080/api/v1/profiles/order-v1/validate `
  -H "Content-Type: application/xml" --data-binary "@samples/order.xml"
```

Bash/macOS/Linux:

```bash
curl -i -X POST http://localhost:8080/api/v1/profiles/order-v1/transform \
  -H 'Content-Type: application/xml' \
  -H 'Accept: application/xml' \
  --data-binary @samples/order.xml

curl -i -X POST http://localhost:8080/api/v1/profiles/order-v1/validate \
  -H 'Content-Type: application/xml' --data-binary @samples/order.xml
```

Sample input:

```xml
<Order xmlns="urn:example:order:v1">
  <OrderId>ORD-1001</OrderId>
  <CustomerName>Sample Customer</CustomerName>
  <Amount>125.50</Amount>
  <Currency>USD</Currency>
</Order>
```

Transform returns HTTP200 and normalized XML. Validate returns HTTP200 with
`{"valid":true,"profile":"order-v1"}` (JSON field order may vary). Sending
`samples/invalid-order.xml` to validate returns HTTP422: its amount is negative.
Open `samples/requests.http` in an IDE HTTP client for editable requests.

## 5. Authentication outside local development

Without the explicit local profile, startup requires JWT configuration:

```dotenv
JWT_ISSUER=https://your-idp.example.com/issuer
JWT_JWK_SET_URI=https://your-idp.example.com/.well-known/jwks.json
JWT_AUDIENCE=xml-transform-api
```

Provide these as environment variables. A `.env` file is not automatically loaded by
a native Java process. Your identity provider issues the JWT; this service does not.
Use access tokens with the expected issuer/audience, expiry and scope `xml:transform`.
The verified `tenant_id` claim, or subject if absent, identifies the cache partition.
Configure your IdP claim mapping accordingly (some providers use client_id rather
than aud for certain access tokens; such tokens will not satisfy this sample policy).

HTTP: `Authorization: Bearer <token>`. In AWS use your Route 53 hostname over HTTPS.
Metrics also require the scope outside local mode. Health status endpoints are
unauthenticated for infrastructure probes. No payloads/tokens are intentionally logged.

JWT signature, issuer, audience, expiry and tenant/subject are checked. Local mode
is rejected without the `local` profile. Prevent operators from activating that
profile in deployed environments through deployment controls.

## 6. Performance and caching

| Cache/control | Default |
|---|---|
| Compiled input/output XSDs | Caffeine, up to 4 entries; warm at startup |
| Compiled XSLT Templates | Caffeine, up to 2 entries; warm at startup |
| Optional transformed-result cache | OFF |
| Result cache when enabled | 16 MiB weighted budget; 60-second TTL |
| Cache key | Verified tenant + profile version + SHA-256 of input |
| Input limit | 1 MiB |
| Output limit | 2 MiB |
| XML nesting depth | 128 |
| Concurrent transformation/validation work | 8; excess rejected |

Enable result caching explicitly with RESULT_CACHE_ENABLED=true, or edit the Compose
value and recreate the container. It retains transformed XML in process memory until
expiry/eviction/restart; assess your data handling requirements before enabling it.
It is per instance, not shared across replicas and not durable. The weight is an
estimate including output bytes/key overhead, not an exact JVM heap measurement.

Only immutable compiled artifacts are reused. Validator, Transformer and DOM objects
are request-local. Invalid results are not cached; result bytes are defensively copied.
There is no public cache-clear endpoint. Change profile version/redeploy after changing
mappings. Avoid unbounded client-chosen profile registrations or client-supplied XSLT.

Actuator Prometheus metrics include `xml.operation`, `xml.requests.failed`,
`xml.requests.rejected` and Caffeine cache metrics. Metric names are normalized in
Prometheus format; inspect `/actuator/prometheus` locally. Load-test realistic XML
before choosing heap, instance count or throughput targets; none is claimed here.

## 7. Errors and health

| Condition | HTTP |
|---|---:|
| Malformed/prohibited XML | 400 |
| Input XSD violation | 422 |
| Unknown profile | 404 |
| XML input limit exceeded | 413 |
| Processing slots exhausted | 503 + Retry-After |
| Missing/invalid JWT | 401 |
| Insufficient scope | 403 |
| Unexpected transformation failure | 500 |

Global HTTP handling lives in `http/ApiErrors.java`, extending Spring MVC's
`ResponseEntityExceptionHandler`. It maps domain failures, framework errors (such as
405/415), and unexpected exceptions. `SecurityErrors` applies the same response to
JWT authentication/authorization failures before the controller runs. Framework
headers such as `Allow` are retained; busy responses include `Retry-After: 1`.

All handled HTTP failures use `application/problem+json`, even for XML requests:

```json
{
  "type": "about:blank",
  "title": "Unprocessable Entity",
  "status": 422,
  "detail": "XML does not match the input schema",
  "code": "SCHEMA_INVALID",
  "correlationId": "demo-123"
}
```

The exact reason phrase may vary with the framework. Clients should branch on
`status` and `code`. Send optional header `X-Correlation-ID: demo-123`; it is echoed
in the response header and error body. Only 1–64 ASCII letters, digits, hyphens and
underscores are accepted; other values are replaced with a generated UUID.

Safe public messages are defined in `core/ErrorCatalog.java`, independent of exception
messages. Unexpected failures log the code, correlation ID and exception class, not
XML, JWTs, exception messages or stack traces that might contain document contents.
Errors rejected before application dispatch (TLS, malformed HTTP framing, proxy
limits) and responses already committed may retain transport-specific error formats.
Application handlers do not promise to intercept JVM fatal errors or startup failures.

Try an error response:

```bash
curl -i http://localhost:8080/api/v1/profiles/order-v1/validate \
  -H 'Content-Type: application/xml' -H 'X-Correlation-ID: demo-123' \
  --data-binary @samples/invalid-order.xml
```

- `/actuator/health/liveness`: process/application state, independent of remote IdP.
- `/actuator/health/readiness`: Spring readiness state. XML assets must compile before startup completes.

Troubleshooting: check port conflicts on 8080; JDK selected by Maven; local profile;
namespace in XML; token issuer/aud/scope; access to the IdP JWKS URL. Do not turn off
JWT or XML validation to make AWS readiness or API requests succeed.

## 8. Tests

```bash
mvn -B -ntp verify
```

Includes Mockito service/cache/controller tests, real XML/XSD/XSLT/security
cases, concurrent engine calls, RSA JWT validation and live HTTP health/metrics/auth
tests on random ports. Tests use synthetic documents and no live AWS/IdP account.
The Mockito subclass mock maker avoids dynamic agent attachment for these tests.
Tests execute during Docker builds as well. See VERIFICATION.md for executed checks.

## 9. AI coding agents and AWS later

Read `docs/AI-USAGE.md` to use AGENTS.md, CLAUDE.md, Copilot instructions, custom
implementation/testing agents and the reusable transformation prompt. No AI API key
or runtime dependency is added to this service.

Read `infra/README.md` for the Terraform deployment flow. It creates one Fargate
service, one ECR repository, one HTTPS ALB with one HTTP target group, and a
Route 53 alias in an existing network. It does not deploy until you explicitly apply.
An AWS account, existing VPC/subnets, ACM certificate, hosted zone and IdP settings
are required. The local compose file is for development only.

## 10. Health checks and metrics

All endpoints share port 8080. No second management port is required.

| Endpoint | Purpose | Production authentication |
|---|---|---|
| `/actuator/health` | Overall health, including built-in contributors | Public status only |
| `/actuator/health/liveness` | Should this process be restarted? | Public status only |
| `/actuator/health/readiness` | Should traffic be routed to this instance? | Public status only |
| `/actuator/metrics` | Available metric names (JSON) | JWT + xml:transform scope |
| `/actuator/metrics/xml.application.ready` | Current readiness gauge (JSON) | JWT + xml:transform scope |
| `/actuator/prometheus` | Prometheus scrape output | JWT + xml:transform scope |

Local commands (use `curl.exe` in Windows PowerShell):

```bash
curl -i http://localhost:8080/actuator/health/liveness
curl -i http://localhost:8080/actuator/health/readiness
curl http://localhost:8080/actuator/metrics
curl http://localhost:8080/actuator/metrics/xml.application.ready
curl http://localhost:8080/actuator/prometheus
```

Production metrics example (token issued by your IdP):

```bash
curl -H "Authorization: Bearer $ACCESS_TOKEN" \
  https://xml.example.com/actuator/prometheus
```

Readiness reports 503 while Spring refuses traffic; liveness can remain 200 during
that state. Docker/ECS container health checks use liveness. The AWS ALB uses readiness.
Liveness deliberately avoids remote dependencies. Missing/invalid XSD/XSLT prevents
startup; compiled assets are held in memory, so deleting files after startup does not
change readiness until restart. Readiness is a routing signal, not a request firewall.

| Prometheus metric | Meaning |
|---|---|
| `xml_application_ready` | 1 accepting traffic, 0 refusing traffic |
| `xml_application_live` | 1 correct Spring liveness, 0 broken |
| `xml_processing_active` | XML operations holding processing slots |
| `xml_processing_available` | Remaining processing slots |
| `xml_operation_seconds_count`, `_sum`, `_bucket` | Operation count, duration and histogram |
| `xml_requests_failed_total` | Domain/unexpected failures in admitted XML operations, by code |
| `xml_requests_rejected_total` | Processing capacity rejections, reason=busy |
| `http_server_requests_seconds_count`, `_sum`, `_bucket` | HTTP traffic, latency and status |
| `jvm_memory_used_bytes`, `jvm_threads_live_threads` | JVM memory and threads |
| `process_cpu_usage` | Process CPU usage |
| `cache_gets_total`, `cache_size` | Caffeine cache statistics |

Operation/failure series appear after matching work occurs. Requests rejected by
security/controllers before entering TransformationService are represented in HTTP
metrics rather than the XML failure counter. Metric labels never include document
contents, tokens, correlation IDs or tenant IDs. Result caching is disabled by default.

A scrape-config example is in `monitoring/prometheus.yml`. Run an existing Prometheus
server with that file to scrape a native app at localhost:8080. For a Prometheus
container on the same Compose network, change the target to app:8080. No monitoring
server is bundled or required to run the application. In AWS, configure your collector
for per-task discovery so it scrapes every replica; ALB load balancing is not per-task
metrics discovery. Use HTTPS and a refreshed Bearer token file for secured scraping.

Example PromQL:

```promql
sum(rate(http_server_requests_seconds_count{application="xml-transform-http-service",uri!~"/actuator.*"}[5m]))
histogram_quantile(0.95, sum by (le, operation) (rate(xml_operation_seconds_bucket[5m])))
xml_application_ready
up{job="xml-transform-http-service"}
```

A stopped process cannot export a zero health gauge: use the collector's `up` metric
or a missing-series alert to detect scrape failure. Choose alert thresholds after
load testing your actual mappings.

## 11. Select JDK 25 when JDK 21 is installed

Install Amazon Corretto 25 first, then use the helper in your current terminal:

```powershell
. .\scripts\Use-Jdk25.ps1 -JdkHome 'C:\Program Files\Amazon Corretto\jdk25.0.4_10'
mvn -version
```

Use your actual installation directory. The leading dot and space dot-source the
script, preserving JAVA_HOME/PATH in the current session. It validates Java 25 and
leaves your JDK21 installation intact. Docker uses its own Corretto25 toolchain.
