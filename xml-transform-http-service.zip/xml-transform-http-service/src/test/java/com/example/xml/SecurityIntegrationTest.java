package com.example.xml;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.security.oauth2.jwt.*;
import java.net.URI;
import java.net.http.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,properties={"app.security.mode=jwt","app.security.issuer=https://issuer.example","app.security.jwk-set-uri=https://issuer.example/jwks"})
class SecurityIntegrationTest {
 @TestConfiguration static class TestTokens {
  @Bean @Primary JwtDecoder testDecoder() {
   return token -> {
    if(!token.equals("allowed") && !token.equals("no-scope")) throw new JwtException("Invalid test token");
    return Jwt.withTokenValue(token).header("alg","RS256").subject("user").claim("scope",token.equals("allowed") ? "xml:transform" : "read").build();
   };
  }
 }
 @Autowired Environment env;
 @Test void httpRequiresTokenAndScope() throws Exception {
  var url=URI.create("http://localhost:"+env.getProperty("local.server.port")+"/api/v1/profiles");
  var client=HttpClient.newHttpClient();
  var missing = client.send(HttpRequest.newBuilder(url).header("X-Correlation-ID", "auth-test").GET().build(), HttpResponse.BodyHandlers.ofString());
  assertEquals(401, missing.statusCode());
  assertTrue(missing.body().contains("\"code\":\"UNAUTHENTICATED\""));
  assertTrue(missing.body().contains("\"correlationId\":\"auth-test\""));
  assertEquals("Bearer", missing.headers().firstValue("WWW-Authenticate").orElseThrow());
  var invalid = client.send(HttpRequest.newBuilder(url).header("Authorization", "Bearer broken").GET().build(), HttpResponse.BodyHandlers.ofString());
  assertEquals(401, invalid.statusCode());
  assertFalse(invalid.body().contains("Invalid test token"));
  assertEquals(403,client.send(HttpRequest.newBuilder(url).header("Authorization","Bearer no-scope").GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
  assertEquals(200,client.send(HttpRequest.newBuilder(url).header("Authorization","Bearer allowed").GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
 }

 @Test void healthIsPublicButMetricsRequireScope() throws Exception {
  var client=HttpClient.newHttpClient();
  String base="http://localhost:"+env.getProperty("local.server.port");
  assertEquals(200, client.send(HttpRequest.newBuilder(URI.create(base+"/actuator/health/readiness")).GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
  for (String path : new String[]{"/actuator/metrics", "/actuator/prometheus"}) {
   var url=URI.create(base+path);
   assertEquals(401, client.send(HttpRequest.newBuilder(url).GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
   assertEquals(403, client.send(HttpRequest.newBuilder(url).header("Authorization","Bearer no-scope").GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
   assertEquals(200, client.send(HttpRequest.newBuilder(url).header("Authorization","Bearer allowed").GET().build(),HttpResponse.BodyHandlers.discarding()).statusCode());
  }
 }
}
