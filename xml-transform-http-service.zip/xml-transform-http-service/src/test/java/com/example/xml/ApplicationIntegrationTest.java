package com.example.xml;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.availability.*;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT,
 properties={"spring.profiles.active=local"})
class ApplicationIntegrationTest {
 @Autowired Environment env;
 @Autowired ConfigurableApplicationContext context;
 private final HttpClient client=HttpClient.newHttpClient();
 private URI uri(String path) { return URI.create("http://localhost:"+env.getProperty("local.server.port")+path); }
 private HttpResponse<String> get(String path) throws Exception {
  return client.send(HttpRequest.newBuilder(uri(path)).GET().build(),HttpResponse.BodyHandlers.ofString());
 }
 @Test void transformReturnsXmlAndEmitsMetrics() throws Exception {
  var request=HttpRequest.newBuilder(uri("/api/v1/profiles/order-v1/transform"))
   .header("Content-Type","application/xml").POST(HttpRequest.BodyPublishers.ofFile(Path.of("samples/order.xml"))).build();
  var response=client.send(request,HttpResponse.BodyHandlers.ofString());
  assertEquals(200,response.statusCode());
  assertTrue(response.body().contains("urn:example:normalized:v1"));
  assertTrue(response.body().contains("ORD-1001"));
  var scrape=get("/actuator/prometheus"); assertEquals(200,scrape.statusCode());
  assertTrue(scrape.body().contains("xml_operation_seconds_count"));
  assertTrue(scrape.body().contains("xml_operation_seconds_bucket"));
  assertTrue(scrape.body().contains("http_server_requests_seconds_count"));
  assertTrue(scrape.body().contains("jvm_memory_used_bytes"));
  assertTrue(scrape.body().contains("xml_processing_available"));
 }
 @Test void healthAndMetricsAreAvailable() throws Exception {
  for (String path : new String[]{"/actuator/health", "/actuator/health/liveness", "/actuator/health/readiness"}) {
   var response=get(path); assertEquals(200,response.statusCode());
   assertTrue(response.body().contains("UP")); assertFalse(response.body().contains("components"));
  }
  var names=get("/actuator/metrics"); assertEquals(200,names.statusCode());
  assertTrue(names.body().contains("xml.application.ready"));
  assertTrue(get("/actuator/metrics/xml.application.ready").body().contains("1.0"));
 }
 @Test void readinessRefusalReturns503AndZeroGaugeWithoutBreakingLiveness() throws Exception {
  try {
   AvailabilityChangeEvent.publish(context, ReadinessState.REFUSING_TRAFFIC);
   assertEquals(503,get("/actuator/health/readiness").statusCode());
   assertEquals(200,get("/actuator/health/liveness").statusCode());
   assertTrue(get("/actuator/metrics/xml.application.ready").body().contains("0.0"));
  } finally { AvailabilityChangeEvent.publish(context, ReadinessState.ACCEPTING_TRAFFIC); }
 }

 @Test void schemaFailureEmitsFailureCounter() throws Exception {
  var request=HttpRequest.newBuilder(uri("/api/v1/profiles/order-v1/validate"))
   .header("Content-Type","application/xml").POST(HttpRequest.BodyPublishers.ofFile(Path.of("samples/invalid-order.xml"))).build();
  var response=client.send(request,HttpResponse.BodyHandlers.ofString());
  assertEquals(422,response.statusCode()); assertTrue(response.body().contains("SCHEMA_INVALID"));
  assertTrue(get("/actuator/prometheus").body().lines().anyMatch(line ->
    line.startsWith("xml_requests_failed_total{") && line.contains("code=\"SCHEMA_INVALID\"") && !line.endsWith(" 0.0")));
 }
}
