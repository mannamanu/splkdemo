# Verification

HTTP-only revision, 2026-10-02.

Executed with Amazon Corretto 25.0.4 and Maven 3.9.11:

- Maven verify: 34 tests, zero failures/errors/skips. Final run used cached dependencies
  offline and built an executable Spring Boot JAR.
- Real HTTP transformation, authentication and authorization tests on random ports.
- Liveness/readiness/overall health return public status-only responses.
- A readiness refusal returns 503 and readiness gauge 0 while liveness remains healthy.
- Actuator JSON metrics and Prometheus output are reachable locally; both require
  authentication and scope outside the local profile.
- Transformation emits operation/HTTP/JVM metrics and histogram buckets. Invalid XML
  schema requests produce HTTP422 and the corresponding Prometheus failure counter.
- Mockito cache/service/controller tests; XML security, depth/size/concurrency limits,
  external assets, RSA JWT signature/issuer/audience/expiry validation retained.
- Safe global HTTP errors, correlation IDs, framework headers and Retry-After covered.
- Packaged JAR checked: no gRPC or Protocol Buffers entries.
- YAML configuration parsed and source ZIP integrity checked.

Build downloads used the execution environment's trusted proxy/CA configuration.
Tests needed local socket access. No tests were disabled; TLS verification remained
on. Environment-specific build settings and downloaded toolchains are not included.

Not executed:

- Docker build/Compose runtime or a Prometheus server scrape.
- Terraform provider-backed validate/plan/apply, ECR publication, or any AWS deployment.
- PowerShell helper execution on Windows, live identity-provider requests, load/soak
  tests, vulnerability audit or production capacity certification.

See README.md for local execution, probes, metrics and authentication. See
infra/README.md for AWS prerequisites and deployment commands.
