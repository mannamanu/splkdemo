# Use the AI coding instructions

These Markdown files guide an IDE coding assistant; they are not an AI runtime and
need no API key in this application. The service never sends XML to an AI provider.

- AGENTS.md: shared repository rules for assistants that support it.
- .github/copilot-instructions.md: repository-wide Copilot context.
- .github/agents/xml-implementation.agent.md: implementation role.
- .github/agents/test-engineer.agent.md: testing role.
- .github/prompts/add-transformation.prompt.md: reusable task prompt.
- CLAUDE.md: entry point for Claude-compatible tooling.

Open the repository root in VS Code/IntelliJ with your configured coding assistant.
Custom-agent UI support varies by IDE/plugin version. If your UI does not discover
these files, explicitly attach AGENTS.md, the role Markdown, relevant Java files,
schemas and samples to your request. No special agent runtime is required.

Example implementation request:

“Follow AGENTS.md and the XML implementation agent. Add invoice-v1 using the input
XSD, output XSD and field mapping attached. Reuse the HTTP adapter and the
bounded caches. Add success/schema-failure/security tests and sample HTTP POST
requests. Run Maven verify; do not publish or deploy.”

Example test request:

“Follow the test-engineer agent. Review cache tenant isolation and oversized XML
handling. Add tests for actual uncovered behavior without weakening production
constraints. Use Mockito where isolation is appropriate and report test results.”

Use synthetic/redacted documents, never real borrower/account records or tokens.
