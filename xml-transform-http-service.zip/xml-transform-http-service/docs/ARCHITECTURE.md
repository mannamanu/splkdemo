# Architecture and extension points

One executable JAR starts embedded Tomcat on port 8080. HTTP controllers invoke
TransformationService and the secure XML engine. No additional service or database
is required. Actuator health and metrics share the HTTP port.

Transform: authenticate -> bound input -> reserve processing slot -> optional result
cache lookup -> hardened XML parse -> input XSD validation -> XSLT transformation ->
bounded output -> output XSD validation -> bytes. Invalid results are never cached.
Validate performs input parsing/schema validation without transformation/result caching.
The GET profiles endpoint lists the server-owned profile identifier.

Schemas and Templates are immutable/thread-safe reusable artifacts. DocumentBuilder,
Validator, Transformer and DOM instances are request-local. Caffeine loads are atomic
per key. The result cache returns defensive byte-array copies. Its weight includes
output bytes plus an approximate key/entry overhead; it is not a strict JVM heap cap.
JVM/container limits and load testing are still required.

Only order-v1 is implemented. To add real MISMO/DU profiles, provide the actual XSDs
and mappings, add versioned external assets under xml-assets and replace the fixed XmlArtifacts
selection with an explicit profile registry. Never interpret profile as a file path.
Bundled XSD imports/XSLT includes are currently denied; if required, implement a
configured-directory-only allowlisted resolver and add tests. Do not enable broad external access.

Processing limits protect the supplied trusted, small stylesheet. Java XSLT does not
provide a safe hard thread-cancellation mechanism. An HTTP client timeout does not guarantee interruption of already-running CPU work. Do not
accept user-supplied stylesheets; isolate compute if future mappings require hard
execution limits or large documents. HTTP body reads are capped even without Content-Length.
Tomcat connection/thread bounds and a shared semaphore limit accepted processing.
External gateway rate limits are an additional production control, not implemented here.

Auth: production JWT signature, issuer, audience, expiry and tenant/subject checks;
required scope xml:transform. HTTP uses Spring Security and a validated JWT decoder. Tenant comes from a verified tenant_id claim or subject,
never an untrusted request header. Local mode requires the explicit local profile.

HTTP health endpoints are unauthenticated status-only; metrics require JWT scope in
production. Readiness follows Spring availability. AvailabilityMetrics exports numeric
liveness/readiness gauges; XML operations export latency, rejection, failure and
processing-slot metrics. HTTP and JVM metrics come from Actuator/Micrometer.

AWS starter: one ECS task exposes one HTTP target group behind one HTTPS ALB.
Route 53 aliases the ALB. TLS ends at the ALB; backend traffic is plaintext within
private subnets/security groups. End-to-end TLS/mTLS, WAF, autoscaling, alarms, audit
retention and workload sizing require platform-specific production configuration.

Global errors: HTTP MVC advice and security-filter handlers share a safe problem
factory and stable ErrorCatalog. A highest-precedence correlation filter runs before
security. Correlation IDs are untrusted labels with a strict syntax/length bound, not identity.
Infrastructure-level failures before dispatch are outside these handlers.

Assets resolve from XML_ASSETS_DIR (default ./xml-assets), are confined to that real
filesystem directory, and compile at startup. Runtime caches never reread changed
assets. Docker carries an image snapshot; local Compose overrides it read-only.
