---
description: Add a new allowlisted transformation profile with complete tests and samples.
agent: agent
---
Read AGENTS.md and docs/ARCHITECTURE.md. Implement a new versioned profile using the
input/output contracts and mapping requirements I provide. If the contract is missing,
ask for the schema or field mapping rather than inventing business rules.

Deliver server-owned input/output XSDs, XSLT, registry selection, valid/invalid samples,
HTTP request examples, Mockito/unit tests and README updates. Preserve all
existing security limits and tenant-aware cache behavior. Run mvn verify. Do not
create another service, introduce Temporal or deploy to AWS.
