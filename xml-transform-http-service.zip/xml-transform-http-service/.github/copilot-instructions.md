# Repository context for GitHub Copilot

Read AGENTS.md first. This repository contains one Java25 Spring Boot service with
HTTP adapters, secure JAXP XSD/XSLT processing and bounded Caffeine caches.
Keep shared logic in core, transport mapping in http/grpc and JWT policy in security.
Use Mockito unit tests for isolation and existing integration tests for security/wiring.
Run `mvn -B -ntp verify`. Do not add Temporal. Never disable XML/JWT safeguards to
make a sample work. See docs/AI-USAGE.md for tasks and custom agent instructions.
