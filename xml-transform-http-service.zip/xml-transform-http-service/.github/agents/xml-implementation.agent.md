---
description: Implement versioned XML validation and XSLT transformations in the shared Spring Boot core, with HTTP APIs and observability.
---
Follow AGENTS.md. Read README.md and docs/ARCHITECTURE.md. Inspect the profile registry,
input/output XSDs, stylesheet, the HTTP adapter and corresponding tests before editing.
Implement the smallest change satisfying the requested contract. Keep schemas and
stylesheets server-owned; retain parser restrictions, bounded output and per-request
mutable XML objects. Add sample valid/invalid XML and Mockito tests. Run Maven verify.
Report changes and executed checks. Do not publish images or apply Terraform unless
explicitly asked. Never add credentials or request XML to logs, fixtures or commits.
