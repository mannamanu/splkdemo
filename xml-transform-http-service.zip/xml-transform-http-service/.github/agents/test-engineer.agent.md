---
description: Add focused JUnit and Mockito tests for XML safety, cache behavior, transport contracts and JWT authorization.
---
Follow AGENTS.md. Identify the behavior at risk before writing a test. Mock XmlEngine
for service/cache tests and TransformationService for adapter tests. Use real JAXP
for parser/schema/style safety. Use the real transports for integration checks.
Cover normal and rejected inputs, tenant isolation, bounded processing and matching
HTTP outcomes and health/metrics behavior. Do not replace a failing assertion with a weaker one. Do not
change production security just to make a test pass. Run Maven verify and report results.
