data "aws_partition" "current" {}
data "aws_subnet" "selected" {
  for_each = toset(concat(var.alb_subnet_ids, var.task_subnet_ids))
  id       = each.value
}
resource "aws_security_group" "alb" {
  name_prefix = "${var.name}-alb-"
  vpc_id      = var.vpc_id
}
resource "aws_security_group" "task" {
  name_prefix = "${var.name}-task-"
  vpc_id      = var.vpc_id
}
resource "aws_vpc_security_group_ingress_rule" "https" {
  for_each          = var.allowed_client_cidrs
  security_group_id = aws_security_group.alb.id
  cidr_ipv4         = each.value
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
}
resource "aws_vpc_security_group_ingress_rule" "task" {
  for_each                     = toset(["8080"])
  security_group_id            = aws_security_group.task.id
  referenced_security_group_id = aws_security_group.alb.id
  ip_protocol                  = "tcp"
  from_port                    = tonumber(each.value)
  to_port                      = tonumber(each.value)
}
resource "aws_vpc_security_group_egress_rule" "alb" {
  for_each                     = toset(["8080"])
  security_group_id            = aws_security_group.alb.id
  referenced_security_group_id = aws_security_group.task.id
  ip_protocol                  = "tcp"
  from_port                    = tonumber(each.value)
  to_port                      = tonumber(each.value)
}
resource "aws_vpc_security_group_egress_rule" "task" {
  security_group_id = aws_security_group.task.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
  description       = "Existing network routes to ECR/logs/JWKS; narrow per enterprise network policy"
}
resource "aws_lb" "app" {
  name                       = var.name
  internal                   = var.internal_alb
  load_balancer_type         = "application"
  security_groups            = [aws_security_group.alb.id]
  subnets                    = var.alb_subnet_ids
  enable_http2               = true
  drop_invalid_header_fields = true
  lifecycle {
    precondition {
      condition     = alltrue([for s in data.aws_subnet.selected : s.vpc_id == var.vpc_id]) && length(toset([for id in var.alb_subnet_ids : data.aws_subnet.selected[id].availability_zone])) >= 2 && length(toset([for id in var.task_subnet_ids : data.aws_subnet.selected[id].availability_zone])) >= 2
      error_message = "Use subnets in the selected VPC; both lists must span at least two AZs."
    }
  }
}
resource "aws_lb_target_group" "http" {
  name_prefix          = "xmlh-"
  port                 = 8080
  protocol             = "HTTP"
  target_type          = "ip"
  vpc_id               = var.vpc_id
  deregistration_delay = 30
  health_check {
    path     = "/actuator/health/readiness"
    matcher  = "200"
    interval = 30
    timeout  = 5
  }
  lifecycle { create_before_destroy = true }
}
resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.app.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = var.certificate_arn
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.http.arn
  }
}
resource "aws_route53_record" "app" {
  zone_id = var.hosted_zone_id
  name    = var.domain_name
  type    = "A"
  alias {
    name                   = aws_lb.app.dns_name
    zone_id                = aws_lb.app.zone_id
    evaluate_target_health = true
  }
}
resource "aws_cloudwatch_log_group" "app" {
  name              = "/ecs/${var.name}"
  retention_in_days = 30
}
resource "aws_ecs_cluster" "app" { name = var.name }
locals {
  trust = jsonencode({ Version = "2012-10-17", Statement = [{ Effect = "Allow", Principal = { Service = "ecs-tasks.amazonaws.com" }, Action = "sts:AssumeRole" }] })
}
resource "aws_iam_role" "execution" {
  name               = "${var.name}-exec"
  assume_role_policy = local.trust
}
resource "aws_iam_role_policy_attachment" "execution" {
  role       = aws_iam_role.execution.name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}
resource "aws_iam_role" "task" {
  name               = "${var.name}-task"
  assume_role_policy = local.trust
}
resource "aws_ecs_task_definition" "app" {
  family                   = var.name
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "1024"
  memory                   = "2048"
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn
  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "X86_64"
  }
  container_definitions = jsonencode([{
    name         = "app", image = var.image_uri, essential = true, user = "10001:10001"
    portMappings = [{ containerPort = 8080, hostPort = 8080, protocol = "tcp" }]
    environment = [
      { name = "SPRING_PROFILES_ACTIVE", value = "prod" },
      { name = "JWT_ISSUER", value = var.jwt_issuer },
      { name = "JWT_JWK_SET_URI", value = var.jwt_jwk_set_uri },
      { name = "JWT_AUDIENCE", value = var.jwt_audience },
      { name = "RESULT_CACHE_ENABLED", value = tostring(var.result_cache_enabled) }
    ]
    stopTimeout = 60
    healthCheck = {
      command  = ["CMD-SHELL", "curl -fsS --max-time 3 http://localhost:8080/actuator/health/liveness || exit 1"]
      interval = 30, timeout = 5, retries = 3, startPeriod = 60
    }
    logConfiguration = { logDriver = "awslogs", options = { awslogs-group = aws_cloudwatch_log_group.app.name, awslogs-region = var.aws_region, awslogs-stream-prefix = "app" } }
  }])
}
resource "aws_ecs_service" "app" {
  name                              = var.name
  cluster                           = aws_ecs_cluster.app.id
  task_definition                   = aws_ecs_task_definition.app.arn
  desired_count                     = var.desired_count
  launch_type                       = "FARGATE"
  platform_version                  = "1.4.0"
  wait_for_steady_state             = true
  health_check_grace_period_seconds = 120
  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }
  network_configuration {
    subnets          = var.task_subnet_ids
    security_groups  = [aws_security_group.task.id]
    assign_public_ip = false
  }
  load_balancer {
    target_group_arn = aws_lb_target_group.http.arn
    container_name   = "app"
    container_port   = 8080
  }
  depends_on = [aws_lb_listener.https, aws_iam_role_policy_attachment.execution, aws_vpc_security_group_ingress_rule.task, aws_vpc_security_group_egress_rule.alb, aws_vpc_security_group_egress_rule.task]
  timeouts {
    create = "20m"
    update = "20m"
  }
}
output "http_url" { value = "https://${var.domain_name}" }
output "cluster_name" { value = aws_ecs_cluster.app.name }
output "task_definition_arn" { value = aws_ecs_task_definition.app.arn }
