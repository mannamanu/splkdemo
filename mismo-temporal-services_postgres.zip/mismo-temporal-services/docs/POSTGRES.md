# PostgreSQL setup and switching from the SQLite starter

## What changed

The complete Maven source, XML endpoint, workflow, activities, and sample request are included. Infrastructure changes are:

- PostgreSQL 16.6 container with a persistent named volume.
- Temporal Server 1.28.0 via its matching `auto-setup` image, replacing the CLI `start-dev` server. This preserves the server generation used by the original starter while changing its database.
- PostgreSQL execution/history database: `temporal`.
- PostgreSQL visibility database: `temporal_visibility`.
- Separate Temporal UI 2.39.0, still at http://localhost:8233.
- Health-gated startup: PostgreSQL -> Temporal schema setup/server/default namespace -> orchestrator/UI.
- No SQLite database, SQLite mount, or `server start-dev` command in the new Compose configuration.

`DB=postgres12` is Temporal's PostgreSQL driver/schema family name; the database container runs PostgreSQL **16.6**, not PostgreSQL 12. Elasticsearch is disabled because SQL visibility uses PostgreSQL.

## Fresh start

```bash
cp .env.example .env
docker compose config --quiet
docker compose up --build -d
docker compose ps
docker compose logs -f temporal
```

Local demo `.env` entries:

```dotenv
API_KEY=local-client-key-change-me
INTERNAL_API_KEY=local-internal-key-change-me
VALID_ACCOUNTS=ACC1001,ACC1002
POSTGRES_PASSWORD=local-postgres-password-change-me
```

The database credential is not an HTTP API key. PostgreSQL and Temporal share it for the local database connection. Spring services connect to Temporal over gRPC and never receive the PostgreSQL password. Do not add `spring.datasource.*` properties or PostgreSQL JDBC dependencies for this change.

The Compose project name is `mismo-temporal-postgres`; Docker normally creates the volume `mismo-temporal-postgres_postgres-data`. PostgreSQL port 5432 is private to the Compose network. API, Temporal gRPC and UI ports bind to host loopback only.

## Existing SQLite installation

This is an infrastructure switch to **new history**, not an automatic migration of existing workflows.

1. Finish any in-flight work on the old installation. Save needed history for audit before cutting over.
2. From the **old SQLite project directory**, run `docker compose down` (without `-v`). Its original `mismo-temporal_temporal-data` volume is retained. Alternatively use the old compose file explicitly with the old project name.
3. Extract this revised project into a separate directory, copy its `.env.example` to `.env`, and bring up the new stack using the commands above.
4. Run the smoke tests and send new requests. The previous workflow IDs/results and deduplication records do not exist in the new PostgreSQL environment. Do not replay business requests with side effects casually.

A SQLite file cannot be mounted as a PostgreSQL database. Do not copy rows between different Temporal persistence schemas. Retain the old environment for history lookup if necessary. Moving active/retained executions requires a separate supported migration/cutover design.

## Bootstrap details

The official `temporalio/auto-setup:1.28.0` image includes Temporal's SQL schema tool and versioned schema files. On local startup it:

1. Waits for PostgreSQL.
2. Sets up/upgrades the history database with the PostgreSQL v12 schema family.
3. Creates and sets up/upgrades `temporal_visibility`.
4. Starts Temporal and registers `default` with 72-hour completed-workflow retention.

The PostgreSQL image creates the `temporal` database and `temporal` user on first initialization. That user is a local bootstrap superuser. `auto-setup` is convenient for local use, not a production privilege model. AWS should separate schema-migration permissions from runtime permissions.

`NUM_HISTORY_SHARDS=4` is a local sizing choice. Do not change it against an existing database as if it were an ordinary runtime setting.

## Verify databases and request flow

```bash
bash scripts/verify-postgres.sh
bash scripts/smoke-test.sh
```

If you changed the client API key, export it before the smoke scripts:

```bash
export API_KEY='your-client-api-key'
```

Inspect databases/schemas manually (the official Postgres image permits local socket access inside its container):

```bash
docker compose exec postgres psql -U temporal -d postgres -c '\l'
docker compose exec postgres psql -U temporal -d temporal -c '\dt'
docker compose exec postgres psql -U temporal -d temporal_visibility -c '\dt'
docker compose exec postgres psql -U temporal -d temporal -c 'SELECT curr_version FROM schema_version;'
docker compose exec temporal temporal operator namespace describe --address temporal:7233 --namespace default
```

For an optional **local-only test that briefly stops the stack**:

```bash
bash scripts/verify-persistence.sh
```

It submits a request, stops PostgreSQL/Temporal/the worker/UI, starts them again with their volumes preserved, resubmits the identical request, and checks that the workflow ID and returned result match. Run it only when no other requests are in flight.

## Backup and reset

```bash
docker compose exec -T postgres pg_dump -U temporal -d temporal -Fc > temporal-history.dump
docker compose exec -T postgres pg_dump -U temporal -d temporal_visibility -Fc > temporal-visibility.dump
```

These are separate logical backups; a coordinated restore must consider consistency between the two stores. Use tested coordinated backups/PITR for production. Backups contain workflow payloads, including XML/JSON from this starter.

`docker compose down` preserves PostgreSQL data. **`docker compose down -v` permanently deletes this stack's local PostgreSQL volume and history.** No supplied start or test script deletes volumes.

Changing `POSTGRES_PASSWORD` in `.env` does not change an existing database role's password. Rotate the database role password and configuration together, or deliberately reinitialize disposable local data. Never delete a volume just to silence a credential mismatch when the data matters.

## Troubleshooting

- Port already allocated: stop the old SQLite stack; both versions use 8080, 7233 and 8233.
- PostgreSQL healthy but Temporal not ready: inspect `docker compose logs temporal postgres` for credentials, schema or namespace errors.
- New password rejected: an existing data volume retains its original role password.
- UI empty: check the `default` namespace and remember the PostgreSQL environment starts with fresh history.
- Dependency startup race: wait for both Spring services to finish starting before the first smoke request.

## Upgrades and AWS

Versions are pinned for reproducibility, not a promise of current security-patch status. Upgrade PostgreSQL, Temporal Server/schema and UI through a tested release process. See `docs/AWS.md` for RDS PostgreSQL and Temporal Cloud options.

Official references:
- https://docs.temporal.io/temporal-service/persistence
- https://github.com/temporalio/docker-compose/blob/main/docker-compose-postgres.yml (archived reference for this pinned server generation)
- https://docs.temporal.io/self-hosted-guide/deployment (current deployment guidance)
