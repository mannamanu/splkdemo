# MISMO services — Spring Boot, Java 25, Maven, Temporal

Three independently deployable Spring Boot applications plus a shared XML/security library. Spring Boot 4.0.8, Java 25, Temporal Java SDK 1.39.0. No preview Java features.

## What is implemented

1. `orchestrator-service`: synchronous `POST /api/orders`, starts or reconnects to a Temporal workflow and waits for its XML result.
2. `auth-service`: validates exactly one demo account identifier in the XML, checks it matches the request account, and checks a configurable enabled-account list.
3. `order-service`: converts XML into a namespace-preserving JSON tree. Repeated elements, element order, mixed text, attributes, namespaces and string values (including leading zeros) are preserved. Comments, processing instructions, lexical CDATA boundaries, and XML declaration are not carried into JSON.

This is a runnable starter, not a finished MISMO business integration. No MISMO version/XSD, target JSON contract, real identity provider, or response XSD was supplied. The request example uses the MISMO namespace with a **demo account extension**. The sample response is an `OrderResponse` XML envelope containing the escaped transformed JSON. It is not a certified MISMO response or a JSON-to-MISMO business mapping.

## Run locally with Docker

Requires Docker Engine/Desktop and Compose v2. A host Java or Maven installation is not required; each image builds and tests with Java 25 and Maven.

```bash
cp .env.example .env
docker compose up --build -d
docker compose logs -f orchestrator-service
```

Allow the first Maven/container build to finish. Health: http://localhost:8080/actuator/health/readiness . Temporal UI: http://localhost:8233 . Internal services are reachable only on the Compose network; they do not publish host ports.

```bash
curl --max-time 55 -i http://localhost:8080/api/orders \
  -H 'Content-Type: application/xml' \
  -H 'X-Api-Key: local-client-key-change-me' \
  -H 'X-Account-Id: ACC1001' \
  -H 'Idempotency-Key: order-1001' \
  --data-binary @samples/request.xml
```

Windows PowerShell: use `curl.exe` and either put the command on one line or use PowerShell backticks for line continuation.

```xml
<OrderResponse>
  <Status>SUCCESS</Status>
  <TransformedPayload format="json">{...escaped JSON tree...}</TransformedPayload>
</OrderResponse>
```

Extract the element's text content with an XML parser to recover the JSON. JSON is deliberately XML-escaped, rather than wrapped in fragile CDATA.

```bash
bash scripts/smoke-test.sh
docker compose down
```

`down` preserves Temporal history in the named volume; `down -v` removes that local history. Local Temporal uses the CLI development server with a persistent SQLite database. It is not the production Temporal deployment.

## Build without Docker

Install JDK 25 and Maven 3.9.11 or later; `JAVA_HOME` must point to JDK 25.

```bash
mvn -B -ntp verify
```

Executable artifacts: `<service>/target/app.jar`. Start local Temporal on 7233 first, then use three shells:

```bash
API_KEY=local-internal-key-change-me VALID_ACCOUNTS=ACC1001,ACC1002 SERVER_PORT=8081 java -jar auth-service/target/app.jar
API_KEY=local-internal-key-change-me SERVER_PORT=8082 java -jar order-service/target/app.jar
API_KEY=local-client-key-change-me INTERNAL_API_KEY=local-internal-key-change-me java -jar orchestrator-service/target/app.jar
```

## Architecture

```mermaid
sequenceDiagram
  participant C as Caller
  participant O as Orchestrator API / worker
  participant T as Temporal server
  participant A as AuthService
  participant R as OrderService
  C->>O: POST MISMO XML
  O->>T: Start workflow / await result
  T-->>O: Workflow and activity tasks
  O->>A: Validate XML account
  A-->>O: Authorized or denied
  alt Authorized
    O->>R: Transform XML
    R-->>O: JSON
  end
  O->>T: Record activity results and workflow result
  T-->>O: Completed result
  O-->>C: XML response on original request
```

The worker is embedded in the orchestrator application. Temporal server stores execution history; your services execute application code. HTTP calls happen only inside activities, never in workflow code. The application does not require a business database for this sample. See `docs/AWS.md` for future hosting and state storage.

## Synchronous contract and time budgets

The caller holds one HTTP connection open. Internally Temporal is durable and asynchronous. Restart recovery can resume a workflow, but cannot resurrect the caller's broken TCP connection.

| Budget | Value |
|---|---:|
| Downstream connect / request | 2 / 5 seconds |
| Activity attempt | 8 seconds |
| Activity total including queue/retries | 18 seconds each |
| Retry attempts | At most 3, 1–2 second backoff |
| HTTP wait for result | 40 seconds after start RPC |
| Workflow total execution | 45 seconds |

A start RPC adds its own duration; this is not a hard 40-second end-to-end HTTP SLA. Align gateway/client timeouts with the complete budget. Load, worker starvation, and outages may cause timeout responses. If your gateway permits less time, reduce all relevant budgets together.

A `504 WAIT_TIMEOUT` does not cancel the workflow. Retry with **identical account, idempotency key, and exact body bytes** to retrieve the same run/result. `503` can also mean start outcome is uncertain; use the identical retry. `X-Workflow-Id` is returned when the workflow call has been attempted.

The workflow ID hashes account + key + XML. Changed XML (including whitespace) produces a different workflow even with the same key: this is **content-addressed deduplication**, not strict key-only conflict detection. Duplicate protection lasts only as long as Temporal retains the execution. Completed failures are returned again; use a new key for an intentional fresh attempt. No order is persisted and no external business side effects occur in this starter. Add a durable idempotency store and transactional uniqueness before implementing order creation or charging; Temporal activities can execute more than once.

| HTTP | Meaning |
|---|---|
| 200 | Valid account, transformation completed |
| 400 | Malformed/unsafe XML, invalid or missing required header/account field |
| 401 | Missing/invalid API key |
| 403 | Account disabled/unknown or different from XML account |
| 413 | XML body exceeds 128 KiB |
| 502 | Dependency or workflow execution failed |
| 503 | Temporal unavailable or uncertain start outcome |
| 504 | HTTP result wait expired; workflow might still be running |

## Configuration

| Variable | Service | Default / purpose |
|---|---|---|
| `API_KEY` | Each | Required, minimum 16 chars; client key on orchestrator, internal key on other services |
| `INTERNAL_API_KEY` | Orchestrator | Required; sent to AuthService/OrderService |
| `VALID_ACCOUNTS` | Auth | Comma-separated enabled accounts; empty means deny all |
| `SERVER_PORT` | Each | 8080 |
| `AUTH_SERVICE_URL` | Orchestrator | http://localhost:8081 |
| `ORDER_SERVICE_URL` | Orchestrator | http://localhost:8082 |
| `TEMPORAL_TARGET` | Orchestrator | localhost:7233 |
| `TEMPORAL_NAMESPACE` | Orchestrator | default |
| `TEMPORAL_TASK_QUEUE` | Orchestrator | mismo-orders-v1 |
| `TEMPORAL_TLS` | Orchestrator | false locally; true for Cloud |
| `TEMPORAL_API_KEY` | Orchestrator | Empty locally; injected secret for Cloud |

Use the same built images across DEV/QA/PROD, with environment-specific settings, secrets, and Temporal namespaces. Keys are read at startup; rotate by redeploying.

## Security and integration boundaries

The shared API key authenticates a trusted integration caller, **not the individual account holder**. A holder of this key can claim any enabled account. AuthService is a demo eligibility check, not proof that the XML originated with that account. Replace this with validated OIDC/JWT account claims or an mTLS client-to-account mapping, then compare the trusted identity to the XML. Do not trust an account header supplied directly by an untrusted caller.

The XML parser rejects DOCTYPE/external entities, limits depth to 100 and input to 128 KiB, and requires a MISMO MESSAGE root/namespace. It does not perform XSD or business validation. Add licensed/approved local MISMO schemas and a versioned field mapping, keeping external schema resolution disabled. Replace `Xml.account` with the actual account location and expected namespace. Do not treat a generic tree conversion as an agreed downstream JSON contract.

Raw XML and transformed JSON are stored in Temporal history. Use synthetic data locally. For real borrower/account data, add a Temporal payload codec with approved key management/access controls or an encrypted S3 reference pattern before ingestion. This starter has no payload encryption codec. API/service credentials are not passed as workflow inputs. Application code avoids logging XML or tokens. Health endpoints expose status only; readiness currently indicates application startup, not comprehensive downstream availability.

## Verification

See `docs/VERIFICATION.md` for the checks performed on this delivered version. Tests include unsafe/malformed/oversized XML, namespaces and repeated elements, account mismatch/unknown account, workflow call order, no transformation after denial, and bounded retry behavior. Docker builds run `verify`, so build/test errors stop the image build.

## References

- Spring Boot requirements: https://docs.spring.io/spring-boot/4.0/system-requirements.html
- Temporal Java releases: https://github.com/temporalio/sdk-java/releases/tag/v1.39.0
- Temporal Java client and Cloud connection: https://docs.temporal.io/develop/java/client/temporal-client
- Local Temporal persistence: https://docs.temporal.io/cli/command-reference/server
- ECS Service Connect: https://docs.aws.amazon.com/AmazonECS/latest/developerguide/service-connect.html
