# Moving the same images to AWS

Recommended starting topology: an Application Load Balancer fronts the orchestrator on ECS Fargate; AuthService and OrderService are private ECS services. Use ECS Service Connect for private names. Temporal Cloud hosts the Temporal server; the orchestrator contains both the HTTP API and the Temporal worker. This project prepares portable containers and configuration, not a provisioned AWS environment or complete infrastructure-as-code deployment.

## State and database ownership

| Deployment | Execution history owner | Database you manage |
|---|---|---|
| Local Compose | Temporal development server | SQLite named volume, configured here |
| ECS + Temporal Cloud | Temporal Cloud | None for Temporal; application databases only if your business needs them |
| ECS/EKS + self-hosted Temporal | Your Temporal cluster | Supported production persistence/visibility stores, capacity planning, backups and upgrades |

Do not deploy the CLI `start-dev` server or its SQLite volume to AWS production. Cloud connections use TLS and the Temporal namespace endpoint/API key; no Postgres connection belongs in your application Dockerfile when using Temporal Cloud.

## Deployment steps

1. Create an ECR repository for each service. Build the image once per service (`docker build --build-arg SERVICE=orchestrator-service -t <registry>/orchestrator-service:<version> .`), and repeat for auth/order. Run tests, scan dependencies/images, then push to ECR. Pin image digests for releases.
2. Create an ECS cluster with private subnets across availability zones, task execution roles for ECR/CloudWatch/Secrets Manager, and appropriate task roles. These services themselves make no AWS API calls in this starter. NAT or other approved egress is needed to reach a public Temporal Cloud endpoint.
3. Create separate task definitions/services, with named TCP container port `http` / 8080. Choose task sizing using load tests (1 vCPU/2 GiB is an initial measurement point, not a sizing guarantee). Use at least two replicas for availability in a production design.
4. Configure Service Connect names `auth-service:8080` and `order-service:8080`; set the corresponding downstream URLs on orchestrator. Enable service-to-service transport protection appropriate to your environment. Keep AuthService and OrderService off public load balancers.
5. Put orchestrator behind an HTTPS ALB listener. Route to port 8080; use `/actuator/health/readiness` for the initial target check. Restrict inbound traffic with security groups. Set the ALB/client timeout above the complete synchronous budget, e.g. 60 seconds after testing. An upstream gateway with a smaller timeout requires a shorter workflow budget or a different request contract.
6. Inject keys using ECS Secrets Manager references; do not put literal secrets into task definition JSON or images. Supply the following orchestrator variables:

```text
TEMPORAL_TARGET=<namespace endpoint from Temporal Cloud>
TEMPORAL_NAMESPACE=<full namespace identifier>
TEMPORAL_TLS=true
TEMPORAL_TASK_QUEUE=mismo-orders-v1
TEMPORAL_API_KEY=<Secrets Manager reference>
API_KEY=<Secrets Manager reference>
INTERNAL_API_KEY=<Secrets Manager reference>
AUTH_SERVICE_URL=http://auth-service:8080
ORDER_SERVICE_URL=http://order-service:8080
```

Auth/order use `API_KEY` pointing to the same internal credential. Auth also receives the configured account list until the real account store is integrated. Configure each environment independently; do not share namespaces/keys between DEV, QA and PROD.

7. Send stdout/stderr to CloudWatch with explicit retention; add request latency/error metrics and Temporal queue/backlog/failure monitoring. Actuator health is included; full tracing, metrics export, and dependency-aware readiness are extension work.
8. Run the supplied smoke test through the deployment's allowed endpoint. Load test concurrency and measure the latency distribution under retries and worker restarts. Set ECS termination grace and deployment overlap so in-flight work can finish; Temporal retries incomplete activities if a process terminates. Upgrade workflow code with replay compatibility/worker versioning; do not change workflow logic in place without checking existing histories.

## Production completion work

Before accepting real MISMO borrower data, implement the actual caller-to-account identity mapping, MISMO XSD/version/response contract, business JSON field mapping, encryption for Temporal payloads, audit requirements, dependency-aware readiness, capacity limits/rate limits, and durable business idempotency if side effects are introduced. No AWS resources have been created by this package.

For independent API/worker scaling later, split the current orchestrator into an API process (WorkflowClient) and a worker process (WorkerFactory); both connect to the same namespace/task queue. This avoids tying HTTP replica count directly to workflow activity concurrency.
