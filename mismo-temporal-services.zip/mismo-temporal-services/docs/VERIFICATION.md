# Verification of delivered source

Verified on 2026-09-18.

## Passed

- Maven reactor build and packaging for all four modules using Java 25 (Azul Zulu 25.0.4.1) and Maven 3.9.11, with all 15 tests passing.
- Java 25 class-file target confirmed (major version 69).
- Seven XML tests: malformed, external-entity/DOCTYPE, wrong namespace, oversized request, duplicate account, preservation of namespaces/attributes/repeated elements/text/leading zeros, response escaping.
- Three account tests: enabled matching account, unknown account rejection, header/XML mismatch rejection.
- Four Temporal workflow tests: validation before transformation, denial stops processing with no retry, transient error recovery, bounded retries.
- One controller/Temporal test: identical HTTP request input reuses the completed workflow result without another transformation.
- Three real Spring Boot service processes plus a real Temporal CLI 1.4.1 development server passed the included five-case HTTP smoke script: success, identical retry, account mismatch, malformed XML, missing API key. This process-level integration run used the installed JDK 17 with a temporary command-line Java-version override, without changing the delivered POM.
- Referenced Docker image tags resolved in the registry: maven:3.9.11-eclipse-temurin-25, eclipse-temurin:25-jre, temporalio/temporal:1.4.1.

## Environment limitations

The downloaded Java 25 installations suffered truncated module files across execution steps in this environment. Java 25 verification succeeded by extracting and running in the same step and using Maven Surefire in-process (`-DforkCount=0`). This is a verification-environment workaround; it is not baked into the project or Dockerfile. The normal delivered command remains `mvn verify` on an intact JDK 25 installation.

Docker/Compose was not installed here, so container startup and Compose networking were not executed. AWS deployment, AWS connectivity, real MISMO schema conformance, external identity-provider integration, load testing and production hardening were not validated.

The delivered source targets Java 25 throughout. No JDK 17 artifacts, dependencies, local credentials, or runtime workarounds are included in the archive.
